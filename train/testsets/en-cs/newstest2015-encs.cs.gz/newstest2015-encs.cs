Petr Čech: Přestup na poslední chvíli?
Možné je všechno
Dnešek je posledním dnem, kdy lze ještě proskočit transferním oknem a udělat velký přestup.
Další šance přijde až v zimě.
Petr Čech, momentálně náhradní brankář Chelsea, teď ale nesedí nad novou profesionální smlouvou v Madridu, Monaku ani Paříži.
Sedí ve smíchovském NH Hotelu, hovoří s českými novináři a chystá se s českou reprezentací na herní generálku s Američany a následně také na ostrý start kvalifikace o Euro 2016 proti Nizozemsku.
V brance Chelsea dostává v nové sezoně Premier League přednost Thibaut Courtois, Čech se poprvé za deset let v londýnském klubu dostal do pozice náhradníka.
Před časem se spekulovalo, že by o Čecha mohl mít zájem Real Madrid.
Ten v úvodu sezony ztratil španělský Superpohár v soubojích s Atlétikem a nezvládl ani vstup do ligové sezony, když prohrál 2:4 v San Sebastiánu.
Spekulovalo se také o zájmu Paris SG.
Ten do sezony francouzské ligy odstatoval dvěma výhrami a dvěma remízami, v neděli rozstřílel St. Etienne 5:0.
Relativně nejvíc tlačí bota klub AS Monaco.
Ten má v lize zatím bilanci 1-1-2 a o víkendu se rozešel s Lille smírně 1:1.
Na bulvárních anglických webech dnes vyskočily zprávy, že by Čecha mohli chtít v Queens Park Rangers.
Podle anglických bookmakerů ale Čechův odchod z Chelsea na poslední chvíli není příliš pravděpodobný.
Skybet na něj vypsal kurz 4:1.
Petře, je možné, že ještě během zbývajících několika hodin změníte dres?
Já s tím nepočítám, ale ve fotbale není nikdy nic stoprocentní.
Třeba během dne přijde nabídka, která nepůjde odmítnout.
Jak by taková nabídka musela vypadat?
(směje se) "No tak to ještě nevím, jak taková nabídka, co ji nelze odmítnout, vlastně vypadá.
Muselo by dojít ke shodě všech stran Především by záleželo na postoji Chelsea, jestli by případnou nabídku klub řešil, nebo ne.
Je vůbec technicky realizovatelné takový přestup udělat, když jste teď v Praze?
Nebylo by potřeba, abyste někde v novém působišti případný nový kontrakt podepsal?
Tak nad tím jsem neuvažoval.
Ale v takové situaci je dneska spousta hráčů, všichni jsou někde na reprezentačních srazech a určitě se dneska ještě spousta přestupů uzavře.
Takže nějak realizovatelné by to jistě bylo.
Kolik je na planetě klubů, které by si vás mohly dovolit?
No tak to vážně nevím.
A vy tedy na odchod netlačíte?
Situace, kdy jsem v prvních třech zápasech nové sezony nechytal, je pro mě po patnácti letech kariéry nová.
Nicméně není důvod panikařit, balit se a někam odcházet.
Já se chci toho souboje o pozici brankáře Chelsea nadále účastnit a je na trenérovi, koho vybere, jaká rozhodnutí v průběhu následujících týdnů udělá.
Jakou roli ve vašem rozhodování hraje rodina?
V úvahu beru všechny faktory.
Podstatné je pro mě pochopitelně sportovní hledisko, ale dívám se na to i z osobní stránky, do které potřeby rodiny samozřejmě patří.
Je možné, že byste chytal i za jiný klub v Anglii?
To je otázka, o níž jsem si myslel, že se mě nikdy týkat nebude.
Ale ve fotbale je možné všechno.
Nechci nic vylučovat.
Neznám odpověď.
Předsedové vlády Indie a Japonska na setkání v Tokiu
Nový indický předseda vlády Narendra Modi je v Tokiu na setkání se svým japonským protějškem Shinzo Abem. Na své první větší návštěvě od květnového vítězství ve volbách má projednat ekonomické a bezpečnostní závazky.
Modi je na pětidenní cestě do Japonska, aby tam upevnil ekonomické vazby s třetí největší světovou ekonomikou.
Na seznamu jsou v první řadě plány na rozsáhlejší spolupráci v oblasti jaderné energetiky.
Podle zpravodajů Indie také doufá, že se oba národy dohodnout na spolupráci v otázkách obrany.
Policie v Karratě po motocyklové honičce zatkla dvacetiletého mladíka
Motorku zastavili poté, co se zónou s maximální povolenou rychlostí 70 km/h řítila 125 km/h a zajela do buše, aby policistům unikla.
Hlídkující dopravní policie se ráno v Karratě pokusila u krajnice zastavit modrou motorku, když si všimli, že při výjezdu z čerpací stanice na Bathgate Road jede 125 km/h.
Podle policie řidič nezastavil a pokračoval po Burgess Road a poté zahnul do buše, takže ho policisté ztratili z dohledu.
Motorka a osoba, která odpovídala popisu řidiče, poté byly spatřeny v domě ve Walcott Way v Bulgaře.
Karrathská policie obvinila dvacetiletého mladíka z neuposlechnutí výzvy k zastavení a neopatrného řízení.
Před soudem v Karratě stane 23. září.
Motocykl byl na tři měsíce zabaven.
George Webster obviněn ze znásilnění v hotelech v Nairn a Pitlochry
Muž bude postaven před soud kvůli obvinění ze znásilnění žen ve dvou hotelích.
George Webster, 28, byl s obviněním seznámen během slyšení u Nejvyššího soudu v Glasgow.
Údajně měl 7. června 2013 ve Scotland's Hotel v Pitlochry v hrabství Perthshire znásilnit ženu.
Podle tvrzení ji Webster napadl, zatímco „nebyla při vědomí, spala a nebyla ve stavu dát svůj souhlas.“
Dále je Webster stíhán pro znásilnění další ženy v hotelu Golf View v Nairn na Skotské vysočině ze 4. května 2014.
Soudkyně Lady Rae stanovila datum přelíčení na 17. listopadu u Nejvyššího soudu v Edinburghu.
Obnovení velmi amerického ideálu, že pracovní práva jsou zároveň lidská práva
Kongresmeni Keith Ellison a John Lewis navrhli zákon, který má organizování v odborech chránit jako občanské právo.
„Podle toho, jak fungují odbory, fungují pracovní místa pro střední třídu,“ říká Ellison, demokratický senátor za Minnesotu, který je spolupředsedající Kongresového výboru.
Proto jsem tak hrdý, že mohu společně se vzorem občasných práv Johnem Lewisem představit zákon posilující postavení zaměstnanců.
Tato průlomová legislativa dá pracovníkům stejné právní možnosti, jak se bránit diskriminaci při organizování v odborech, jako u jiných forem diskriminace - a zastaví protiodborové síly
Upravit zákon o pracovních vztazích tak, aby umožňoval všem zaměstnancům, kteří čelí diskriminaci, pokud se chtějí zapojit do odborů, soudit se u civilního soudu - a vysoudit odškodnění nebo náhradu škody - je správná a nutná iniciativa.
Určitě to ale není radikální iniciativa - alespoň ne podle amerických standardů.
Nejlepším způsobem, jak pochopit, co Ellison, Lewis a další navrhovatelé v zákonu předkládají, je znovu navázat na americký ideál.
I přes odborové boje, které v proběhly v nedávných letech - ve Wisconsinu, Michiganu a dalších státech - Američani kdysi podporovali země na celém světě, aby přijaly, rozšířily a respektovaly pracovní práva.
Byly doby, a miliony Američanů je stále pamatují, kdy země jedním dechem prosazovala demokracii, svobodu slova, svobodu tisku a právo na shromažďování.
Když Spojené státy po druhé světové válce obsadily Japonsko, generál Douglas MacArthur a jeho poradci podporovali zemi, aby přijala ústavu navrženou tak, aby zajistila, že vojenská autokracie Hideki Toja bude nahrazena demokracií.
Byli přesvědčení, že zaměstnanci a jejich odbory hrají roli ve formování nového Japonska, zahrnuli do nich jazyk a otevřeně uznali, že „právo zaměstnanců shromažďovat se, kolektivně vyjednávat a jednat je zaručeno.“
Když Spojené státy po druhé světové válce obsadily Německo, generál Dwight David Eisenhower a jeho poradci vybízeli Němce, aby vytvořili ústavu, která zajistí, že fašismus Adolfa Hitlera bude nahrazen silnou demokracií.
Němci si uvědomovali, že zaměstnanci se budou v novém národu potřebovat organizovat a prosazovat, a proto zahrnuli klauzuli, která otevřeně říká: „Právo vytvářet spolky, které zabezpečí a zlepší pracovní a ekonomické podmínky bude každému jednotlivci a každému povolání nebo profesi garantováno.
Ujednání, která budou toto právo omezovat nebo budou usilovat o jeho poškození, budou zrušena. Opatření vedoucí ke splnění takového účelu jsou nezákonná.
Když bývalá první dáma Eleanor Rooseveltová předsedala Mezinárodní komisi pro lidská práva, která navrhla Všeobecnou deklaraci lidských práv, která byla v roce 1948 přijata Spojenými národy jako celosvětová smlouva, zahrnuli do ní navrhovatelé a Rooseveltová garanci, že „každý má právo v rámci ochrany svých zájmů vytvářet odbory a vstupovat do nich.“
Američané celé generace přijímali základní premisu, že pracovní práva jsou lidská práva.
Když země radila jiným zemím, jak vytvářet občanskou a demokratickou společnost, vysvětlovali Američané, že právo vytvářet pracovní odbory - a jejich účast v kolektivním vyjednávání s firmami a vládními agenturami v pozici rovnocenného partnera - musí být chráněno.
Nyní, když jsou tato práva v Americe napadána, je rozhodně nutné, vrátit se k americkému ideálu, že pracující lidé musí mít právo se ve svobodné a otevřené společnosti organizovat a s prosazovat.
Jak před padesáti lety řekl reverend Martin Luther King Jr.:
Historie je velká učitelka.
Dnes každý ví, že odbory sílu národa nezmenšily, ale rozšířily ji.
Zvýšily životní standard milionů lidí, vytvořily trh pro průmysl a výrobu pozvedly na netušenou úroveň.
Ti, kdo odbory napadají, tyto jednoduché pravdy zapomínají, historie si je ale pamatuje.
Historie nezapomíná a my bychom také neměli.
Formální uznání pracovních práv jako lidských - a rozšíření ochrany občanských práv tak, aby bránily diskriminaci v organizování odborů - má velké zpoždění.
Keith Ellison a John Lewis obnovují ideály, které pozvedly Ameriku a učinily z ní skutečný příslib demokracie.
Soudce dočasně zablokoval zákon, který mohl zavřít všechny potratové kliniky v Louisianě
Federální soudce v neděli dočasně zablokoval louisianský zákon, který by podle advokátů pravděpodobně zavřel všech pět klinik provádějících potraty ve státě.
Nařízení uzákoněné podpisem louisianského guvernéra Bobbyho Jindala v červnu, které má v platnost vstoupit 1. září, by po lékařích provádějících potraty vyžadovalo, aby měli právo přijmout pacientku v nemocnici vzdálené do 30 mil od výkonu jejich praxe.
Usnesení soudce znamená, že lékaři mohou dočasně v provádění legálních potratů pokračovat a mezitím si musí toto povolení opatřit.
„Navrhující strana bude moci zákonně provozovat svou činnost a mezitím si získá povolení,“ stojí v usnesení federálního soudce Johna deGravellese.
Slyšení bude naplánované během jednoho měsíce, aby soudce mohl vydat trvalejší usnesení týkající se zákona.
Aktivisté za práva na potrat usnesení, které je poslední v sérii podobných opatření, uvítali a řekli, že lékařům poskytne více času na získání povolení.
„Dnešní rozhodnutí zajišťuje ženám v Louisianě, že budou v bezpečí před záludným zákonem, který je má připravit o zdraví a jejich práva,“ prohlásila Nancy Northupová, prezidentka a výkonná ředitelka Centra pro reprodukční práva, která se jménem tří z pěti klinik žalobou domáhala zablokování zákona.
Nebylo hned jasné, zda se rozhodnutí týká i lékařů ze dvou klinik, které nebyly mezi žalujícími, a také žádají o udělení tohoto povolení.
Louisiana je mezi jedenácti státy, které schválily podobné zákony, přičemž soudy v Alabamě a Mississippi taková opatření ustanovením prohlásily za protiústavní.
Klíčové části texaského zákona, které by uzavřely většinu zbývajících klinik ve státě zablokoval federální soudce v pátek.
Bojovníci za práva žen na potrat společně se Sdružením amerických porodníků a gynekologů a Americkou lékařskou asociací tvrdí, že nutnost mít toto povolení klade na lékaře požadavky, které z lékařského hlediska nejsou nutné.
Odpůrci potratů oponovali tím, že opatření mají za cíl chránit zdraví žen a někteří také uvítali fakt, že kvůli opatřením by byly kliniky uzavřeny.
Centrum pro reprodukční práva uvedlo, že v Louisianě má povolení pouze jeden lékař provádějící potraty.
Pokud by všichni lékaři ve státě byli přinuceni přestat s prováděním potratů, tento lékař by ze strachu o své bezpečí také přestal zákrok provádět, řekla skupina.
Louisianské úřady v reakci uvedly, že by netrestaly lékaře, kteří potraty provádějí, zatímco čekají na vyřízení žádosti o udělení práv.
Kvůli pozdní diagnóze a špatné dostupnosti léčby zabíjí na venkově rakovina vaječníků častěji
Angelina Jolie a její bratr James zveřejnili video s holdem své zesnulé matce, která zemřela na rakovinu vaječníků v roce 2007.
U žen na australském venkově hrozí vyšší riziko, že zemřou na rakovinu vaječníků, než u jejich protějšků ve městě.
Výzkumníci analyzovali lékařské záznamy více než 1100 Australanek diagnostikovaných v roce 2005 s rakovinou vaječníků a zjistili, že pouze 35 % pět let po diagnóze žilo.
Vedoucí výzkumu Susan Jordanová z QIMR Berghofer Medical Research Institute uvedla, že u žen ve venkovských a odlehlých oblastech státu byla asi o dvacet procent vyšší pravděpodobnost, že během studie zemřou než u žen v městských oblastech.
MALÁ STUDIE: Nové léky mohou zpomalit rakovinu plic a vaječníků
Výzkumníci ženy sledovali během sedmi let léčby.
Doktorka Jordanová řekla, že šance na přežití ovlivnil věk žen v době diagnózy, typ karcinomu vaječníků, další existující nemoci a socio-ekonomický status.
Nejnižší míra přežití se vyskytovala u starších žen, u kterých byla rakovina diagnostikována v pokročilejším stádiu.
U žen ve venkovských a odlehlých oblastech státu byla asi o dvacet procent vyšší pravděpodobnost, že během studie zemřou než u žen v městských oblastech.
Přestože studie nebyla navržena tak, aby určila, proč byla u žen žijících mimo město vyšší pravděpodobnost, že zemřou na rakovinu vaječníků, doktorka Jordanová tvrdí, že faktory mohou být pozdní diagnóza a špatná dostupnost léčby.
„Nemoc umí nejlépe léčit gynekoonkologové, kteří obvykle sídlí ve větších městech,“ řekla.
I přes zlepšení lékařských služeb na dálku, které mají překonat bariéru v podobě vzdálenosti, doktorka navrhla, že by pomohlo posílení přepravní služby, které specialistům umožní léčit ženy blíž k jejich domovům, a programy na podporu lidí, kteří se léčí daleko od své rodiny a přátel.
Doktorka Jordanová prohlásila, že studie odhalila, že dlouhodobé přežití žen s rakovinou vaječníků je bez ohledu na zeměpisnou polohou nízké, což zdůrazňuje nutnost lepší léčby a preventivních programů.
Výzkum financovaný Rio Tinto Ride to Conquer cancer dnes zveřejní Medical Journal of Australia.
V březnu 2012 byla ve svých 33 letech mladá maminka Elisha Neaveová z města Gold Coast diagnostikována s agresivní formou rakovinu vaječníků.
Zahradní centra litují snížení počtu vlastníků domů
Podle studie HTA, kterou zveřejnil Financial Times, pokles spojený s mimořádným úbytkem vlastníků domů mladších 35 let by mohl vést k tomu, že až dnešní mladá generace spotřebitelů dosáhne „hlavní věkové skupiny zahrádkářů“, zahradní centra přijdou až o deset milionů liber ročně.
Podle zprávy utratí za své zahrady lidé, kteří si bydlení pronajímají, v průměru 55 % částky, kterou utratí lidé bydlící ve svém.
Jako další faktory ohrožující odvětví, které vydělává odhadem pět miliard liber ročně, uvádí nárůst počtu lidí žijících ve velmi urbanizovaných oblastech, kde nejsou zahrady, oblibu dláždění místo předzahrádek používané jako parkovací plocha a zmenšující se velikost zahrad.
V oblasti Velkého Londýna, kde podíl vlastněných domů klesl během šesti let z 61 % na 43 %, připadají na jednu domácnost nejnižší výdaje na zahradnické produkty v Británii.
HTA a Královská zahradnická společnost uvedly, že bydlení v podnájmu nebo nedostatek prostoru neznamená, že by lidé nemohli pěstovat rostliny.
Guy Barter, hlavní zahradnický poradce pro RHS, řekl: „U nájemníků je velmi oblíbené pěstování rostlin v květináčích - když se přestěhují, mohou si rostliny vzít s sebou.“
Zpráva HTA odhalila, že „zlatý věk“ zahradnického maloobchodního sektoru byl mezi lety 1997 a 2005 a byl výsledkem vyššího podílu vlastníků domů a ekonomické prosperity trvající od 80. do poloviny 90. let.
Také na tento rok předpověděl vyšší odbyt díky lepšímu počasí, které přišlo po nepříznivých podmínkách v březnu a dubnu.
Když východní diktátor káže o demokracii.
Poté co Putin na srazu své mládežnické organizace, která mi ze všeho nejvíce připomíná Hitlerjugend, zachrastil atomovými zbraněmi a v podstatě všem dal najevo, že jejich názory jsou mu ukradené, udělil nám dnes přednášku o demokracii.
Já mám ale takový pocit, že současný režim v Rusku vykazuje mnoho rysů fašistického státu.
Velké národy mají jedno společné a to je to, že je dokáže ovládnou jak vypjatý nacionalismus, tak i to že komplex méněcennosti dokáží transformovat v imperialistické choutky.
Čas plyne na východě zřejmě jinak, než na západě.
Zatímco západní svět si myslel, že doba válek o nadvládu nad Evropou je už dávno pryč , na východě si naopak myslí, že přehlíženi byli již dlouho a je třeba získat si zpět svou mezinárodní pozici.
Taková nálada a frustrace vládla v Německu v třicátých letech, těsně před uchopením moci nacisty a pak následoval výbuch nacionalismu nepodobný dnešní situaci v Rusku.
A pak ten zcela shodný kult silného vůdce, mlácení novinářů, likvidace nepohodlných politických oponentů, diskriminace menšin a homosexuálů, to je tedy věru dosti podobné.
Vladimírovi Putinovi a určitě i velké části Rusů se asi stýská po době, kdy Rusko vládlo půlce světa a druhá část se před nimi třásla.
Asi si to západní politici zavinili sami, možná málo Vladimíra poplácávali po ramenou, možná ho nepozvali tam kam toužil a možná ho začali podceňovat a on se prostě jen zachoval jako typický ruský mužik.
Udělal si pořádek doma, tvářil se, že on vlastně nikam ani nechtěl a brousil doma nože.
Teď se rozhodl, že dobude zpět ztracené pozice.
Začne pomalu, má čas.
Vůdcem je asi na doživotí, tak kam by spěchal.
Pošlapal Kavkazany, teď pošlape Ukrajince, pak jsou na řadě trpaslíci z Pobaltí.
Ti už ruského medvěda štípou v kožichu dost dlouho.
Toho už si určitě všimne i Čína, která si nějak moc vyskakuje a určitě si dělá zálusk na dálný východ.
A Ti Němci toho Vladimíra taky pěkně štvou, jak se mají dobře a to jsem jim dali v 45 tak na zadek.
Co takhle udělat jednu novou Novorosiju v Karlových Varech.
To by byla základnička a našich je tam spousta a jak je tam utiskují i daču už chtěli leckterému z nich zbourat.
Vždyť naši veteráni doteďka vzpomnají, jak se v tom Československu měli.
Nu vot vždyť ten jejich premiér Gospodin Sobotka, ten je tak měký, dá se loupat jako cibule a sním celá ta jejich EU.
To by tak hrálo,aby si na veliké Rusko vyskakovali.
Je třeba jim připomenout, kde je jejich místo.
A jako rozbušky použijeme naše soukmenovce, kteří bydlí na jejich území.
Rusů je všude dost a když se řekne, že je tam utiskují, tak je tam prostě utiskují a to my tak nenecháme, my je ochráníme.
A zase bude Rus vládnout , vždyť k čemu jinému je zrozen.
Evropa je přeci dobrá jen jako předložka, na které může hrdý Ivan tančit kozáčka.
Turecko si předvolalo amerického diplomata kvůli špionážní zprávě
Turecký ministr zahraničí si zavolal nejvýše postaveného amerického diplomata v zemi, aby vysvětlil zprávu o americké a britské špionážní aktivitě v Turecku.
Náměstek předsedy vlády Bulent řekl, že americký charge d'affaires a turečtí státní úředníci o zprávě jednali v pondělí.
Německý magazín Der Spiegel a internetový magazín The Intercept uvedly, že podle dokumentů poskytnutých bývalým analytikem americké Národní bezpečnostní agentury bylo Turecko prioritním cílem amerických a britských zpravodajských služeb.
Podle tureckých sdělovacích prostředků bagatelizoval turecký prezident Recep Tayyip Erdogan důležitost zprávy a prohlásil, že všechny významné státy se navzájem sledují.
Starší zpráva, podle které se na Ankaru zaměřila i německá zpravodajská služba, vyvolala u turecké vlády rozhořčenější reakci.
Seriál Hra o trůny představil další triky čtvrté řady
Tvůrci Hry o trůny momentálně natáčejí epizody páté řády kultovního seriálu.
Zároveň se pochlubili tím, jak vznikaly triky čtvrté řady.
Nejviditelnější jsou počítačové úpravy seriálového prostředí a masové scény, kdy se z hloučku vojáků stane obří armáda slavné Daenerys.
Ředitel policie v Magalufu obviněn z korupce
Stěžovatelé v pátek předložili úřadu mallorského státního prokurátora důkazy o vydírání ze strany policistů a státních úředníků radnice v samosprávní oblasti Calvia.
Ředitel policie v Calvia na prázdninovém ostrově Mallorca byl zatčen po obvinění vznesených podnikateli a majiteli barů v nechvalně proslulé večírkové čtvrti v Magalufu.
Vrchní inspektor José Antonio Navarro byl vzat do vyšetřovací vazby poté, co proti němu vzneslo obvinění z korupce několik podnikatelů z Punta Ballena, ulice, ve které se nachází většina barů a nočních podniků v Magalufu.
Podle internetového deníku Mallorca Diario předložili v pátek stěžovatelé prokurátorovi mallorského úřadu pro potírání korupce důkazy o vydírání ze strany policistů a státních úředníků radnice v samosprávní oblasti Calvia.
Dva další místní policisté byli zatčeni španělskou státní policií kvůli spojitosti s obviněním z korupce a společně s Navarrem je vyslechne soudce.
Španělský celostátní deník ABC citoval nespokojené majitele nočních podniků, podle kterých má zvýhodňování ze strany veřejných činitelů vážné dopady na jejich podnikání.
„Už dávno to není o vydělávání peněz, ale o přežití,“ řekl u soudu jeden z podnikatelů.
Nezahrávejte si s naším živobytím.
Nemáme co ztratit.
Magaluf se dostal na hlavní stránky časopisů na celém světě poté, co se na YouTube objevilo video osmnáctileté britské turistky, která během turné po barech poskytla orální sex 24 mužům.
Ostrovní úřady se od té doby snaží dohlížet na opilce a výtržníky v řadách účastníků prázdninových večírků v Magafulu snižováním počtu nechvalně známých alkoholových turné po barech.
Navíc klub Playhouse, kde došlo k události s poskytováním orálního sexu, byl nucen na rok zavřít a společně s organizátory turné po barech společností Carnage zaplatit pokutu 55 000 euro (73 000 dolarů).
Turistický resort Magaluf, který je oblíbený především u Britů, byl také svědkem mnoha nehod pod vlivem alkoholu včetně módní vlny známé jako „balconing“, při kterém lidé skáčou z jednoho balkonu na druhý nebo z balkonu do hotelového bazénu.
První jarní den poznamenán deštěm a bouřkami, které měly dopad na let na letišti v Adelaide
JARO přineslo jihu Jižní Austrálie ledové překvapení, přišlo se silným deštěm a prudkým větrem, které vážně zasáhly letiště v Adelaide.
Dalších 5 mm srážek má ve městě připadnout až do devíti hodin večer a dalších 6,6 mm připadne během noci na neděli.
Poslední déšť se představil společně s několika krátkými přeháňkami spojenými s bouřkou a poryvy větru, které začaly před osmou hodinou večer a během asi deseti minut přinesly téměř 4 mm srážek.
Poté, co po zimě minulý týden přišlo několik časných dávek jara, klesly v pondělí teploty ve městě opět na pouhých 15,8 °C.
Má se za to, že bouřkové počasí přispělo ke zpožděnému příletu Virgin Airlines z Melbourne do Adelaide.
Letadlo mělo přistát chvíli po 19:30, na krátké vzdálenosti ho ale zasáhla změna rychlosti nebo směru větru a bylo nuceno přistání odložit.
Poryvy větru na letišti v Adelaide v tu dobu dosahovaly na zemi rychlosti okolo 50 km/h.
Letová data ukazovala, že letadlo muselo od druhého přistání upustit a nakonec dosedlo asi ve 20:40.
Zpoždění letadla následně způsobilo zpoždění dalších letů včetně letu společnosti Emirates z Dubaje a letu společnosti Qantas ze Sydney.
Podle předpovědi dosáhnou v úterý teploty v Adelaide maximálně 16 °C a mohou se objevit jedna nebo dvě přeháňky.
Izraelské děti se po válce v Gaze vrací do školy
Tisíce izraelských dětí z oblastí v blízkosti pásma Gazy se v pondělí vrátily do školy poté, co strávily léto v protibombových krytech, zatímco během padesátidenní války mezi Izraelem a Hamásem na jejich domovy útočily rakety a minomety. Školy v Gaze však zůstávají zavřené, zatímco se území vzpamatovává z bojů.
Začátek školy přinesl do komunit na jihu Izraele poznamenaných útoky pocit radosti a vzrušení, ale známky bojů jsou stále patrné.
V Ašdodu, městě na jihu země, zaměstnanci školky, kterou zasáhla raketa, odstranili ze zdi pozůstatky po střepinách a pozvolna očekávají návrat dětí.
„Máme trochu strach, ale jinak se těšíme,“ řekla Ronit Bartová, obyvatelka kibucu Saad a učitelka angličtiny na místní škole.
Hodně dětí z této oblasti se už opravdu potřebuje vrátit ke každodenní rutině.
Její jedenáctiletá dcera Shani Bartová prozradila, že „je to trochu zvláštní“ chodit najednou znova do školy.
„Prožili jsme si pár těžkých chvil a vůbec jsme neopustili dům,“ řekla.
Kibuc, který se nachází blízko hranic s Gazou, navštívil prezident Reuven Rivlin, aby obyvatelům nabídl svou podporu.
Dokud zastavení palby minulý týden válku neukončilo, tisíce obyvatel hraničních osad jako je Saad zůstaly uvnitř svých domů nebo své domovy opustily a vydaly se do bezpečnějších oblastí dál od Gazy, aby unikly raketám a minometům.
Mnoho obyvatel Nachal Oz, vesnice blízko hranice s Gazou, ve které střela z palestinského minometu zabila čtyřletého chlapce, s návratem váhá.
Ministr školství uvedl, že asi dvanáct rodin se stále nevrátilo.
Jejich děti byly dočasně umístěny do náhradních škol.
Předseda vlády Benjamin Netanjahu navštívil školu v Sderotu, městě na hranici s Gazou, které bylo palestinskou palbou silně zasaženo.
Nabádal děti, aby pilně studovaly, a dodal: „Zajistíme vám vzdělání a bezpečí.“
Izrael a Hamás se minulé úterý dohodly na časově neomezeném míru.
Zastavení palby sice vedlo k okamžitému ukončení bojů, nevyřešilo však klíčové problémy jako požadavek Hamásu na ukončení izraelsko-egyptské blokády Gazy a znovuotevření letišť a přístavů v Gaze.
Izrael požaduje odzbrojení Hamásu a navrácení těl dvou vojáků padlých ve válce.
Očekává se, že nové kolo nepřímých jednání začne později v tomto měsíci v Egyptě.
Podle odhadů Palestinců a OSN ve válce zemřelo více než 2 100 Palestinců, z nichž tři čtvrtiny tvořili civilisté a nejméně 494 dětí.
Izrael tato čísla zpochybňuje a odhaduje, že alespoň polovina zabitých byli radikálové, přestože pro tato tvrzení nemá jasné důkazy.
Na izraelské straně zemřelo 66 vojáků a šest civilistů včetně thajského dělníka.
Hamás a další radikálové z Gazy vystřelili během bojů na izraelská města především na jihu země 4 591 raket a střel z minometů.
Izraelská armáda zase podnikla víc než 5 000 vzdušných náletů a dalších útoků.
Izraelské útoky poškodily nebo zničily tisíce domů v Gaze a odhadem 250 000 lidí se ukrylo ve stovce škol OSN, které se přeměnily v provizorní přístřeší.
Kvůli desítkám tisíc lidí, které stále zůstávají v úkrytech, a kvůli trvajícím bojům odložili minulý týden školští úředníci začátek školního roku.
„Doufám, že školu brzo otevřou, abychom si mohli dokončit vzdělání stejně jako židovské děti a ostatní děti na světě,“ řekl Mohammad Amara, třináctiletý chlapec ze školy v největším městě Gazy.
Vrba na srazu: Za Váchou si stojím.
A Lafatu trápí teplota
Česká fotbalová reprezentace se dnes před polednem v Praze sešla před středečním přípravným zápasem s USA a následným úvodním utkáním kvalifikace mistrovství Evropy proti Nizozemsku.
Z třiadvacetičlenného kádru má problémy sparťanský útočník David Lafata, kterého trápí teplota.
David tady ještě není, ale Sparta měla minulý týden nějaké problémy, šlo o více hráčů a David ještě asi trošku ty problémy má.
Ale chceme, aby tady byl a byl co nejdříve v pořádku," řekl novinářům trenér Pavel Vrba.
"Jestli to budou dva nebo tři dny, nebo už zítra bude fit, to se uvidí podle jeho zdravotního stavu, o kterém rozhodne náš doktor," dodal.
Ostatní hráči jsou v pořádku.
"Samozřejmě někdo má nějakou bolístku, ale není to takové, že by nemohli trénovat nebo se zúčastnit zápasu ve středu s USA," prohlásil český trenér.
V neděli večer Vrba povolal jako posledního hráče sparťanského záložníka Lukáše Váchu.
Připustil, že to nebylo snadné rozhodování, v úvahu připadali i jiní středopolaři.
Rozhodl jsem se na základě toho, že Lukáš je perspektivní hráč, kterému je 25 let.
Rozhodování to bylo hodně složité, ale já si za tím stojím," podotkl Vrba k Váchovi.
A co Šural?
Uvidíme, co bude s Latatou
Není vyloučeno, že v případě zdravotních problémů by se nominace ještě mohla změnit.
O víkendu se skvělým výkonem blýskl například liberecký Josef Šural, který dal hattrick.
Samozřejmě jsou hráči, kteří v poslední době ukazují formu.
Uvidíme, jak na tom bude David Lafata.
V případě, když nebude moci ve středu být k dispozici, netvrdím, že nemůžu donominovat někoho z hráčů, kteří v české lize zaujali," podotkl Vrba.
Dnes odpoledne čeká reprezentaci trénink na Strahově, v úterý pak klasický předzápasový trénink před duelem s USA na Letné, který bude otevřený pro fanoušky a po němž bude následovat autogramiáda.
Utkání s Američany se hraje ve středu od 20:15 a národní tým v něm bude usilovat o premiérové vítězství pod Vrbou.
V předešlých třech přípravných zápasech uhrál dvě remízy a jednou prohrál.
Kvalifikační souboj s Nizozemskem je pak na programu 9. září od 20:45.
Pešice jede na Nizozemce do Itálie
Vrba je rád, že má na rozdíl od předešlých srazů více času na trénink.
Je výhoda, když máte hráče osm dní a můžete s nimi nacvičovat určité věci, na které jsme třeba předtím neměli tolik času.
Teď se budeme moci soustředit jen na to, abychom se co nejlépe připravili na Nizozemsko," pochvaloval si Vrba.
Nizozemci se ještě před utkáním v Praze představí ve čtvrtek v Itálii a duel bude osobně sledovat bývalý dočasný reprezentační kouč Josef Pešice.
Dá nám informace, které ze zápasu jsou.
Ale nebude to jen o něm, budeme mít zápas i natočený a budeme si ho rozebírat.
K Nizozemsku přichází nový trenér, uvidíme, jaké změny tam budou," řekl Vrba k bronzovým medailistům z nedávného světového šampionátu.
Podle velmi sledovaných statistik ceny bytů v zimním období vzrostly nejvíc za posledních sedm let.
Podle indexu hodnoty bytů v australském hlavním městě RP Data CoreLogic Hedonic vzrostly v srpnu ceny bydlení o 1,1 %, uvedla v pondělí agentura.
Zvýšení vedlo k celkovému nárůstu za červen, červenec a srpen na 4,2 %, nejvyšší zvýšení za zimní měsíce od roku 2007.
Roční nárůst cen se vyšplhal na 10,9 %, více než dvojnásobek za jeden rok do srpna 2013, zisk však nebyl v zemi rovnoměrně rozložen.
Ředitel výzkumu RP Data Tim Lawless uvedl, že na trhu vedou Sydney a Melbourne.
Čísla RP Data ukazují, že ceny bytů v Sydney minulý rok vzrostly o 16,1 %, zatímco ceny v Melbourne o 11,7 %.
Mezi další nejsilnější trhy patřily Adelaide, Brisbane a Darwin s nárůstem cen v průměru mezi pěti a šesti procenty.
Na druhé straně stupnice se umístila Canberra, kterou poškodilo státem nařízené snížení výdajů a kde ceny během roku vzrostly pouze o 1,4 %.
Lawless řekl, že když nyní začalo jaro, zvýší se v následujících měsících počet nemovitostí na prodej, což bude pro trh „opravdovou zkouškou“.
„Vzhledem k přetrvávající vysoké míře aukčních výprodejů, obecně vysoké rychlosti prodeje a nízké úrokové míře, je pravděpodobné, že hodnota bydlení se během příštích tří měsíců ještě zvýší,“ uvedl.
Lenny Henry: Můj otec mě nikdy neobjal.
Nikdy mi neřekl „Mám tě rád“
Henry se v roce 1958 narodil jako jedno ze sedmi dětí jamajských přistěhovalců v Dudley v Midlands.
Se svým otcem, který zemřel, když bylo Henrymu 19, a který pracoval v továrně, měli chladnější vztah.
Henry zkouší komedii, Rudy's Rare Records, která se částečně zakládá na imaginárním rozhovoru s jeho otcem a která je součástí sérií Radio 4.
Soundtrack je směsicí reggae a rapu a melodie je optimistická.
Henry si ale musel poradit s několika nepříjemnými vzpomínkami z dětství.
Po smrti matky si Henry prošel „důkladnou“ terapií a teď přemýšlí o svém vztahu s otcem.
Věděl toho o něm hrozně málo.
Nikdy jste neviděli jeho obličej, jenom jste slyšeli jeho hlas: „Přestaň s tím rámusem.
Nech sestru na pokoji.
Uhni!
Chci se dívat na kriket.
Mí starší bratři Seymour a Hilton - když jsem byl dítě, byli už dospělí - s ním chodili do baru a probírali věci jako je tvar sklenice s pivem nebo krása úderu v kriketu.
Já jsem s ním nikdy takhle nemluvil.
Většinu mého života to byl vážný chlápek v koutě, co si čte noviny.
Nedávno Henry navštívil v Dudley slévárnu, a přestože podmínky byly lepší než v otcově době, nahlédl do toho, jaký pro něj musel život být.
Dneska už je tam o něco víc světla, ale pořád je to temný, zakouřený, pochmurný labyrint, kde vybuchují plameny a je tam hodně kouře a sazí.
Táta si vždycky vlezl do vany a jenom tam ležel, pak bylo slyšet, jak si pomalu začíná zpívat pro sebe, protože ze sebe smývá slévárnu.
Když jsem šel kolem, uvědomil jsem si, že tohle roky dělal, aby uživil rodinu, a začal jsem si ho víc vážit.
I přesto Henry prožil dětství bez rodičovské lásky.
Táta nikdo nikoho neobjal, neřekl „mám tě rád.“
Až když byla máma nemocná a umírala, začali jsme si říkat „mám tě rád, mám tě rád, mám tě rád.“
Jeho dcera Billie, kterou má s Dawn Frenchovou, mu umožnila zažít lásku, která mu jako dítěti chyběla.
Můžeš už přestat s tím „mám tě rád“?
Neobjímej mě pořád!
Tati, je mi 22!
S Dawn Frenchovou.
Proč bychom neměli být přátelé?
Je to skvělá máma
S Frenchovou, se kterou byl ženatý 25 let, jsou stále dobří přátelé.
Dawn je hodná.
Proč bychom s Dawn neměli být přátelé?
Je to skvělá máma.
Henryho vlastní matka měla cukrovku.
Byla to jedna z věcí, která ji zabila.
Takže když jsem měl hodně, hodně velkou nadváhu a začínaly se projevovat příznaky cukrovky, doktor mi řekl: „Musíš udělat radikální změnu.“
Takže jsem začal chodit do velkého fitness centra a taky jsem musel držet drastickou dietu, abych se zbavil příznaků.
Je to hodně těžké.
A únavné.
Nikdo nechce jíst samou mrkev.
Změna ve směru ubírání Henryho kariéry se možná odráží v jeho elegantní, nakrátko ostříhané bradce.
Poté, co se mu dostalo uznání od kritiky za jeho Othella, ponořil se do divadla.
Následovala Komedie plná omylů a Ploty Augusta Wilsona.
Je to jiná zkušenost než sitcomy a komedie, které vyplňovaly jeho hektický pracovní život.
Začínal, když mu bylo 16 a pracoval v továrně.
DJ si ho všiml na pódiu, jak někoho paroduje, a napsal o něm do talentové soutěže New Faces.
Jeho televizní kariéra začala v polovině 70. let: „Dlouho jsem byl jediný černošský imitátor/komik v televizi.“
Učil se za pochodu.
Kromě toho, že si mě musela všimnout veřejnost, musel jsem se taky mezi lety 1975 a 1985 naučit, jak vymýšlet fungující vtipy, být hvězda a vystupovat v televizi a to bylo opravdu těžké.
Lenny v New Faces v roce 1975
Vzhledem k tomu, že jeho manažer vlastnil práva k jevištní produkci The Black and White Minstrel Show, zábavnímu programu, ve kterém se herci převlékali za černochy, Henry v něm se svou komedií nakonec vystupoval pět let.
Moje rodina kvůli tomu už byla nesvá.
Trochu si přeju, aby se to nikdy nestalo, ale nelituju toho.
I když to byla zvláštní a trapná pozice, pracoval jsem na velkých scénách a učil se, jak pracovat s davem.
To, co byl „roky a roky oceňovaný hlavní produkt britské televize“, ale byla zároveň také „groteskní parodie černochů.“
V 80. letech Henry pracoval v alternativních komediálních kruzích a představil postavy, které zároveň zesměšňovaly i oslavovaly britskou černošskou kulturu.
První série The Lenny Henry Show se začala vysílat v roce 1984 a v 90. letech byl mimo jiné známý jako šéfkuchař Gareth Blacklock v komediálním seriále Chef!.
Další desetiletí mu zabraly reklamy, dokumenty, televizní seriály a role ve filmech, ale po odvysílání jeho seriálu LennyHenry.tv na BBC v roce 2008, si řekl: „Tak co budeš dělat teď, Lene, trochu to totiž vypadá, že ses zaseknul na jednom místě, nebo trochu scházíš z cesty.“
Další na řadě byl dokumentární pořad na Radio 4 nazvaný What's So Great About...?/Co je tak skvělého na...?
První byl Shakespeare.
Na Shakespeara jsem měl vážně alergii.
Ve škole jsme se ho pořádně neučili a myslel jsem, že je to něco pro bílou střední třídu.
Takže jsem z toho měl strach.
Všichni, s kým jsme v pořadu dělali rozhovor, Peter Hall, Trevor Nunn, Adrian Lester, Judi Denchová, říkali: „Měl bys to zkusit.“
Nenavážej se do toho, když nevíš, o čem mluvíš.
Zkus si pár slov a uvidíš, proč všichni máme Shakespeara tak rádi.
Henry pro dokument přednesl dvacet řádků z Othellovy závěrečné řeči a už v tom jel.
Dalo mi to pocit, že to dokážu.
Jako kdyby mi to dodalo odvahu.
„O tom to je. Je to vážná věc, ber to vážně, nauč se text, něco si o tom zjisti.
Takže zkoušení bylo tvrdé a předtím jsem tu hru četl měsíce a měsíce.
A byl to úspěch.
Vypadalo to, že čekají průšvih, což se nestalo.
Brzy začal hrát v Komedii plné omylů.
Najednou jsem byl v Národním divadle. Nemohl jsem tomu uvěřit.
V jednu chvíli jsem si pomyslel: „Změnil ses.“
Došlo k technické závadě a Henry instinktivně cítil, že musí převzít zodpovědnost za zabavení publika.
„Hlásek v hlavě mi řekl: ‚Než spraví počítač, musíš je teď deset minut bavit.‘“
Místo toho divadelní režisér oznámil, že představení bude pokračovat, jakmile se problém vyřeší.
Odešel jsem z jeviště a něco ve mně říkalo: „Hm, díky bohu.“
Není to moje zodpovědnost.
Může to za mě vyřešit někdo jiný.
„Hraješ, tak zůstaň v roli.“
Henry v Plotech v Duchess Theatre
Naučit se text Plotů byla výzva.
Panika je docela dobrá, dodává odhodlání.
Hra byla také dobře přijata, takže je to jako boží znamení, které říká: „Tohle bys měl dělat.“
Samozřejmě to říká ZVUČNÝM hlasem.
Takže u toho zůstávám.
Mám to fakt rád.
Jsem rád ve zkušebně.
Henrymu přesto zůstává mozek komedianta - celou dobu náš rozhovor přerušuje humornými vystoupeními, kdy vstupuje a vystupuje z role imitátora.
Rozhodl jsem se nedělat stand-upy, protože mít uspokojení z místnosti plné cizinců je trochu nebezpečné, řekl bych.
Když pořád něco hledáte, můžete se dostat do slepé uličky.
Někdy, když chci, dělám Live at the Apollo, ale už mě to netěší jako dřív.
Zeptal jsem se, jestli ještě někdy zorganizuje nějaké stand-up turné.
Radost z toho sedět v jedné místnosti s režisérem, který pomáhá dávat obrysy začátku, prostředku a konci cesty - nemyslím, že bych se toho chtěl někdy vzdát.
Takže vaše nová inkarnace?
Myslím, že ano.
Herectví mě baví.
Je to zábava.
Pořád vyprávíte příběhy, což je skvělé.
Miluju příběhy.
Lidé milují příběhy.
Keňa registruje státní úředníky, aby si posvítila na neexistující zaměstnance
Keňa začala s biometrickou registrací všech svých státních úředníků, aby se pokusila odstranit z výplatní listiny vlády neexistující zaměstnance.
Podle prohlášení vlády přestanou zaměstnanci, kteří se v následujících dvou týdnech neregistrují, dostávat výplatu.
Vláda se domnívá, že tisíce lidí dostávají plat i poté, co státní službu opustily.
Poté, co se v roce 2013 ujal úřadu, přislíbil prezident Uhuru Kenyatta, že zamezí korupci ve státní správě.
Audit provedený v tomto roce ukázal, že stát měsíčně přichází při nejmenším o jeden milion dolarů (700 000 liber) na výplatách neexistujících zaměstnanců a pří dalším zneužití úřední moci.
Vláda má podezření, že platy jsou nadále vkládány na bankovní účty i po úmrtí zaměstnance nebo poté, co zaměstnanec státní správu opustí, uvedl reportér BBC z hlavního města Nairobi, Wanyama Chebusiri.
Všichni státní úředníci se musí během příštích dvou týdnů dostavit do identifikačních center, kde budou jejich údaje biometricky zaznamenány, uvádí se v prohlášení vlády.
Dále říká, že každý, kdo se bez dostatečné omluvy nedostaví, bude vyřazen z výplatní listiny.
„Určením skutečných zaměstnanců veřejné služby toto opatření významně přispěje k jejímu zhospodárnění a také bude použito k pročištění výplatní listiny na obou úrovních vlády, a vyřeší tak problém neexistujících zaměstnanců,“ řekla Anne Waiguru, tajemnice Ministerstva pro rozvoj a plánování.
Desítky tureckých policistů zatčeny kvůli „spiknutí“ proti vládě
Místní média uvádí, že v Turecku bylo zadrženo kvůli podezření ze „spiknutí proti vládě“ celkem 33 policistů.
Policejní úřad zatím případ nekomentoval.
Podle Hurriyet Dail News bylo mezi zadrženými čtrnáct vysoce postavených úředníků.
Někteří z nich byli zapleteni do prosincového vyšetřování korupce, které se zaměřilo na úředníky vlády včetně čtyř ministrů.
V červenci bylo několik tureckých policistů zatčeno pro údajné organizování zločineckého gangu a telefonního odposlouchávání.
Turecký prezident Recep Tayyip Erdogan (v té době předseda vlády) označil jejich jednání za součást působení islámského duchovního Fethullaha Gülena proti němu a dalším lidem u moci.
Ne všechny děti se na Ukrajině vrátily do školy
Většina škol na Ukrajině se v pondělí (1. září) po letních prázdninách znovu otevřela.
Tento den je pro rodiny tradičně důležitý a jako tisíce dalších ukrajinských rodičů i předseda vlády Arsenij Jaceňuk odvedl svou dceru do školy.
Při této příležitosti sdělil přítomným novinářům, že ne všechny školy se znovu otevřely, ale že je rozhodnutý zemi bránit pro příští generace:
Ne na všech školách se uskutečnila tradiční ceremonie k 1.září.
Ne na celé Ukrajině je mír.
Musíme za mír bojovat.
Celá Ukrajina, spojená ukrajinská fronta, musí bojovat za mír.
Alexan Pastukhov, učitel ve škole ve Slavjansku, kterou navštěvuje Jaceňukova dcera, promluvil v ruštině.
Doufáme, že zde bude konečně dosaženo míru a že děti získají vědomosti, které jim budou v budoucnu užitečné.
První den školy se tradičně slaví tak, že děti si oblečou vyšívané košile, přinesou balonky a učitelům dávají květiny.
V Roně Fairheadové možná BBC našla šéfku pro těžké časy
Nese si s sebou oblaka slávy ze světa bankovnictví, media managementu a interní konkláve konzervativní strany.
Sama má zkušenosti z předních linií.
Kariéru začala v konzultantské společnosti Bain and Co, poté pokračovala přes Morgan Stanley, Bombadier, ICI a do mediálního světa Pearsons.
Sedm let byla výkonnou ředitelkou Financial Times. Na funkci rezignovala, když nejvyšší funkci v mateřské společnosti Pearson's obsadil její mladší kolega.
Říká se, že její odstupné se blížilo milionu liber.
Její politické portfolio je také rozsáhlé.
Davidu Cameronovi byla doporučena Lordem Browne, bývalým ředitelem BP, když Cameron ve Whitehallu potřeboval soukromou expertízu: stala se poradkyní úřadu vlády.
Její manžel je bývalý člen městské rady.
V květnu jsem popsal práci ředitele jako kalich s jedem.
Nejen, že je BBC rozsáhlá a spletitá entita v centru veřejného života, ale v její struktuře existuje také vnitřní paradox.
Korporace se obrací dvěma směry: dovnitř na vrchní vrstvu hierarchie vlastního vedení BBC, ale také ven na hlas veřejnosti v dobách neklidu, když věci nefungují.
Jedná se o téměř neudržitelný monopol, který si žádá důkladnou reformu.
Který ředitel by ale riskoval, že přijde do firmy složité jako čínská dynastie, rozloží ji a tím sám sebe připraví o práci.
Je to těžká výzva.
Kdyby to tak těžké nebylo, hodně lidí by rádo vidělo, jak se BBC zmenšuje - její moc, její finance - a jak se reviduje její status.
S tím, jak se rozšiřuje okruh konkurence a nová technologie zpochybňuje staré jistoty, nese s sebou bezprostřední jednání o koncesionářských poplatcích pro BBC velké nebezpečí.
Za skromnou částku 145,50 libry ročně si britská veřejnost kupuje podíl v něčem, co je jistě největší mediální podnik na světě.
BBC vypráví dobrou historku: tvrdí, že její produkce dosahuje 96 % domácností a každou přitom stojí jen 40 pencí denně.
Navíc obliba BBC očividně stoupá: na 53 % příznivců oproti 31 % před deseti lety.
Modely používání služeb BBC se změnily: Dnes se mi novinové titulky zobrazují na mobilním telefonu a na pořady, které jsem prošvihl, se můžu podívat na iPlayeru.
Ale BBC i nadále zůstává velmi milovanou a úžasnou institucí.
Potřebuje úžasného ředitele - doufám, že jednoho našla.
Texaský guvernér Perry tvrdí, že urážlivý tweet neschválil
Tweet z oficiálního twitterového účtu texaského guvernéra Ricka Perryho, který byl zveřejněn v neděli, obsahoval urážlivý obrázek demokratické státní zástupkyně, která iniciovala trestní obvinění Perryho ze zneužití pravomoci.
Tweet byl později smazán a na Perryho účtu byl uveřejněn další, který se od předchozího distancoval.
Z mého účtu odešel tweet, který nebyl autorizován.
„S tweetem nesouhlasím a stáhl jsem ho,“ uvedl v dalším postu.
Perryho asistenti neodpověděli na zprávy s dotazy ihned.
Přestože tweety byly poslány z Perryho oficiálního účtu, není jasné, kdo je ve skutečnosti zodpovědný za jeho správu.
Předchozí tweet zveřejnil nelichotivý, humorný obrázek státní zástupkyně Travis County Rosemary Lehmbergové, která byla v dubnu 2013 odsouzená za řízení v opilosti.
Když odmítla rezignovat, Perry zamítl vyplácení prostředků pro její kancelář, což Perryho, možného kandidáta na prezidenta ve volbách 2016, tento měsíc přivedlo před velkou porotu v Austinu.
Na popisku v tweetu stálo: „Ne vždycky řídím s třikrát vyšší hladinou alkoholu v krvi než je povolený limit... ale když už ano, tak zažaluju guvernéra Perryho, že mě za to vyzývá k odpovědnosti.“
Jsem nejopilejší demokratka v Texasu.
Vyšetřování proti Perrymu nevedl úřad Lehmbergové.
Na starosti ho měl Michael McCrum, zvláštní prokurátor ze San Antonia, který byl určen republikánským soudcem.
Perry byl shledán nevinným a obvinění nazval taktickým, politickým manévrem.
Jeho kvalifikovaný právnický tým požádal soudce dohlížejícího na případ, aby obvinění zamítl, protože využití zákonů k soudnímu stíhání nejdéle sloužícího guvernéra v texaské historii je protiústavní.
Perry přerušil vyplácení 7,5 milionu dolarů ze státního fondu pro oddělení hájení veřejného zájmu, které má sídlo v Travis County a stíhá korupci v Texasu, poté, co Lehmbergová odmítla rezignovat.
Zamítnutí vyvolalo formální stížnost levicově orientované skupiny občanských aktivistů.
Perryho oficiální účet je aktivní - a někdy se i proslaví.
Poté, co v Iowě během své prezidentské kampaně v roce 2012 skončil na pátém místě ve výboru své strany, odpověděl Perry na spekulace o tom, že by už mohl skončit, tweetem s vlastní fotkou, jak běhá poblíž jezera, a se slovy: „Tady jsem, Jižní Karolíno!“
Podle Berkeley se trh s bydlením vrací „do normálu“
Jedna nejprominentnějších londýnských developerských společností varovala, že trh s bydlením se v jihovýchodní Anglii „vrátil“ k normální úrovni činnosti.
Bydlení v hlavním městě bylo předmětem vysoké poptávky a vzrůstajících cen a rozšířené obavy z úvěrové bubliny přiměly v červnu Bank of England k zavedení limitů na hypotéky.
Tony Pidgley, zakladatel a předseda developerské společnosti pro náročné klienty Berkeley, v pondělí řekl: „Od začátku aktuálního rozpočtového roku se trh z vrcholného bodu v roce 2013 vrátil na normální úroveň transakcí.“ Dodává, že to poskytuje „stabilní prostředí pro fungování.“
Londýnskému trhu s bydlením se během poklesu dařilo dobře, protože do hlavní město zaplavili kupci ze zahraničí.
Podle dat katastrálního úřadu jen v minulém roce ceny ve městě vyskočily o 18,5 %, čímž dalece předehnaly průměr 6,7 % v Anglii a v celém Walesu.
Průměrné prodejní ceny soukromého, cenově dostupného a studentského bydlení od Berkeley se minulý rok zvedly asi o pětinu a na konci dubna se vyšplhaly na 423 000 liber.
Nicméně kvůli posilující libře nejsou v posledních měsících pro zahraniční kupce londýnské nemovitosti tak atraktivní - některé z nich také zastrašilo zavedení nových daní z nemovitosti a řeči o možné „sídelní dani“, se kterými přišli politici před parlamentními volbami příštího května.
Londýnská realitní kancelář Foxtons minulý týden varovala, že dubnová revize trhu s hypotékami, která představila přísnější pravidla pro půjčky, zpomalí během druhé poloviny roku také tempo růstu trhu u prodeje nemovitostí i cen.
Nová data Bank of England v pondělí ukázala pokles v množství schválených hypoték za měsíc červenec, což naznačuje, že trh s bydlením se zklidňuje.
Hamptons International, další realitní kancelář, snížila na základě toho, že ceny domů již začaly klesat, svou předpověď růstu cen londýnských nemovitosti na rok 2015 na 3 %.
Objem transakcí se podle realitní kanceláře WA Ellis mezitím v londýnských nejdražších čtvrtích jako Chelsea, Mayfair a Kensington každý rok snížil o čtvrtinu.
Přesto byla poptávka po bydlení v hlavním městě pro Berkeley požehnáním, protože zvýšila hotovost za forwardový prodej na více než 2,2 miliard liber.
Pidgley dodal: „Poptávka po tom správném, dobře vypadajícím bydlení v dobré lokalitě zůstala stejná a díky tomu se forwardový prodej udržel.“
V červnu firma ohlásila, že od začátku roku do konce dubna prodala 3 742 nemovitostí, téměř o třetinu víc než před vrcholem krize v roce 2007.
Roční zisk před zdaněním se zvýšil o 40 % na 380 milionů liber, výnosy o 18 % na 1,6 miliard liber.
V pondělí před výroční schůzí společnosti Pidgley řekl, že se předvídá, že roční výnosy Berkeley budou v souladu se současným tržním očekáváním.
Analytici se shodují, že roční zisk před zdaněním bude 450 milionů liber.
Akcie Berkeley se odpoledne na londýnské burze zastavily na 23,96 librách.
Hacker na internetu zveřejnil fotky nahé Jennifer Lawrencové
Jennifer Lawrencová přijíždí na 85. ročník Cen Akademie.
Fotky držitelky Oscara Jennifer Lawrencové unikly na internet kvůli hackerovi, který tvrdil, že má „seznam“ fotek další stovky začínajících hereček.
Mluvčí hvězdy filmů „Hunger Games“ potvrdil, že fotky Lawrencové jsou pravé a hackera kritizoval za „zjevné porušení soukromí.“
Úřady již byly kontaktovány a budou stíhat každého, kdo ukradené fotky Jennifer Lawrencové zveřejní.
Hacker fotky, které byly původně zveřejněny na serveru pro sdílení obrázků 4chan, údajně získal díky mezeře v systému internetového úložiště Applu iCloud. Údajný seznam fotek hacknutých obětí podle BuzzFeed zahrnuje jména desítek hvězd včetně Rihanny, Kim Kardashianové, Mary Elizabeth Winsteadové a Mary-Kate Olsenové.
Není jasné, kolik fotek je autentických, nicméně hvězda filmu „Scott Pilgrim proti zbytku světa“ Winsteadová na Twitteru také čin kritizovala.
„Doufám, že ti z vás, kteří si prohlíží fotky, které jsme si před lety s manželem pořídili v soukromí domova, jsou se sebou spokojení,“ napsala Winsteadová na Twitteru.
Victoria Justice známá ze seriálů kabelové televize Nickolodeon „iCarly“ a „Victorious“ však popřela, že by fotky byly pravé. Na Twitteru sdělila: „Tyhle mé údajné nahé fotky jsou PODVRH, lidi.“
Lepší utnout to ještě v rozpuku. *záměrná slovní hříčka*.
Buzzfeed v neděli večer oznámil, že mluvčí popové hvězdy Ariany Grande popřel, že by údajné fotografie byly pravé.
Mimořádná ukázka z vychvalovaného nového románu Howarda Jacobsona o lásce a písmenu „J“
Rozpustili se, to je ten nejlepší způsob, jak to popsat, postupně se rozložili jako kartonová krabice, kterou někdo nechal na dešti.
Jenom času od času mu nějaká žena řekla, že je příliš vážný, složitý, prudký, izolovaný a možná trochu popudlivý.
A pak mu potřásla rukou.
Popuzeně si to připustil.
Uměl píchat, jako ježek, ano.
Poslední oběť této jeho schopnosti byla počínající milostná pletka, která více než obvykle slibovala, že mu uleví od osamělé životní nudy a možná mu i poskytne nějaké uspokojení.
Ailinn Solomonsová byla křehká kráska s divokou hřívou vlasů a přelétavým srdcem z vesnice na severním ostrově, která byla ještě odlehlejší a nehostinnější než Port Reuben.
Na jih přišla se starší společnicí, o které se Kevern domníval, že je její teta, která zdědila majetek ve vlhkém, ale nádherném údolí nazývaném, příhodně, Rajské údolí.
V domě několik let nikdo nežil.
Trubky prosakovaly, ve vanách byly mrtví pavouci, slimáci se oslizle podepsali na okna, jako kdyby si mysleli, že jim to místo patří, zahrada byla zarostlá a plevel připomínal obrovské hlávky zelí.
Dům vypadal jako chaloupka z dětských příběhů, děsivá a zároveň okouzlující, se zahradou plnou tajemství.
Profil autora: Howard Jacobson, jehož román „J“ je na předběžném seznamu nominací na Man Booker Prize 2014.
Užší výběr bude oznámen příští týden.
Kevern s Ailinn seděli na rozkládacích křeslech v dlouhé trávě a drželi se za ruce, užívali si nečekaně teplého jarního odpoledne, nepřítomně naladili veřejnou stanici, která kraj zásobovala útěšnou hudbou a uklidňujícími zprávami, když v tom mu pohled na její opálené překřížené nohy připomněl starou písničku dlouho zapomenutého černošského komika, kterého se zataženým roletami rád poslouchal jeho otec.
Máš moc velké nohy.
Kvůli jejich přirozené agresivitě už takové písničky v rádiích nehráli.
Nebyly zakázané - skutečně zakázané nebylo nic - prostě se nehrály.
Pomohli jim dostat se do desuetuda, stejně jako samotné slovo desuetudo.
Lidový vkus dokázal to, co by nikdy nedokázaly předpisy a postavení mimo zákon, a stejně jako si lidi, co týče knih, vybírají memoáry, ve kterých se z chudáka stane boháč, kuchařky a milostné romány, tak v hudbě se vybírají balady.
Kavern se nechal strhnout dnem a začal hrát na imaginární piáno a hrubým, komickým hlasem zpíval serenádu Aillininým velkým chodidlům.
Ailinn nechápala.
„To byla oblíbená písnička od jazzového pianisty Fatse Wallera,“ řekl a automaticky si přiložil dva prsty ke rtům.
To vždycky dělal jeho otec, když chtěl potlačit písmeno j, než mu vyjde z úst.
Začalo to jako hra, když byl ještě malý.
Otec mu řekl, že hru hrál i se svým otcem.
Když jste si u slova, co začínalo na j, nedali před pusu dva prsty, stálo vás to penci.
Už tenkrát to nebylo moc vtipné a vtipné to nebylo ani teď.
Jenom věděl, že se to od něj očekává, to bylo celé.
Musel vysvětlovat, co je to jazz.
Ailinn nikdy žádný neslyšela.
Ani jazz, i když nebyl přímo postaven mimo zákon, nehráli.
Improvizace vyšla z módy.
V životě bylo místo jenom pro jedno „kdyby“.
Když začala hrát melodie, lidi chtěli vědět, kde přesně skončí.
To samé u humoru.
Jeho nepředvidatelnost šla lidem na nervy.
A jazz byl humor vyjádřený písní.
Přestože až do deseti let neslyšel o Sammy Davisu Juniorovi, znal Kevern jazz z otcovy polotajné sbírky starých CD.
Aspoň ale nemusel Aillin říct, že Fats Waller byl černoch.
Vzhledem ke svému věku si nemohla pamatovat dobu, kdy oblíbení zpěváci nebyli černoši.
Taky bez zákonů nebo nátlaku.
Povolná společnost je taková, ve které každá její část s vděčností - s vděčností těch, jež byli šťastnou náhodou ušetření - souhlasí s principem skupinové vděčnosti.
Lidé afro-karibského původu se temperamentem a konstitucí hodili pro bavení a atletiku, a tak zpívali a běhali.
Lidé původem z indického subkontinentu, jakoby přírodou nadaní pro elektroniku, převzali odpovědnost za to, že žádná rodina nebude bez funkčního telefonu.
Poláci, co zůstali, byli instalatéři, Řekové, co zůstali, myli nádobí.
Ti ze států Perského zálivu a Levanta, jejichž prarodiče rychle neopustili zemi, zatímco se dělo TO, CO SE STALO, KDYBY SE TO STALO - báli se, že by je obvinili, že přiložili do ohně, vlastně se báli, že ten oheň příště stráví je - otevřeli si restaurace, kde se prodával labneh a kouřily vodní dýmky, neupozorňovali na sebe a nečinnost je pomalu stravovala.
Každému podle jeho talentu.
Vzhledem k tomu, že poslouchala jenom balady, Ailinn těžko chápala, jak by ze sprostých slov, která jí Kavern právě zazpíval, mohla vzniknout muzika.
Hudba byla vyjádřením lásky.
„Ve skutečnosti nejsou sprostá,“ řekl Kevern.
Možná jenom pro lidi, co mají moc velké nohy.
Můj otec nikdy nikoho neurazil, ale tuhle písničku měl rád.
Mluvil příliš, ale zanedbaná zahrada dodávala iluzi bezpečí.
Zpoza zvukotěsných listů nemohlo uniknout ani slovo.
Ailinn pořád nechápala.
Proč by se tvému otci něco takového líbilo?
Chtěl říct, že to byl vtip, ale zdráhal se dát si v její přítomnosti zase dva prsty k ústům.
Už si myslela, že je divný.
„Zdála se mu vtipná,“ řekl nakonec.
Nevěřícně potřásla hlavou a zastínila Kevernovi výhled.
Na celém širém světě nebylo vidět nic jiného než změť jejích havraních vlasů.
Nic jiného vidět nechtěl.
„Když myslíš,“ řekla pochybovačně.
To ale pořád nevysvětluje, proč mi ji zpíváš.
Vypadala skutečně rozčilená.
Mám moc velké nohy?
Podíval se znova.
Chodidla tak úplně ne.
Možná trochu kotníky...
Tvrdíš, že mě nesnášíš, protože mám moc tlusté kotníky?
Nesnáším?
To není pravda.
Je to jenom hloupá písnička.
Mohl jí říct „miluju tě“, ale na to bylo moc brzo.
„Tvoje tlustý kotníky mě právě přitahují,“ zkusil to.
Jsem tak trochu úchylný.
To se nepovedlo.
Chtěl být vtipný.
Když chtěl být vtipný, často ho to dostalo do potíží, protože, stejně jako jeho otec, postrádal kouzlo nutné k tomu, aby dokázal zkrotit krutost, která ve vtipech číhala.
Možná byl jeho otec krutý úmyslně.
Možná byl úmyslně krutý Kavern.
Navzdory laskavým očím.
Ailinn Solomonsová zrudla a zvedla se z lehátka, shodila rádio a rozlila nedopité víno.
Bezinkové víno, takže pití za to nemohlo.
Vypadala, že se ve svém rozrušení třese jako palmové listy v bouři.
„Mě zvráceně přitahuje, že jsi blbec,“ řekla...
Až na to, že mě to nepřitahuje.
Bylo mu jí líto, jak kvůli svým nelaskavým slovům, tak kvůli strachu, který měla v očích ve chvíli, kdy se proti němu postavila.
Myslela si, že ji uhodí?
Nemluvila s ním o životě na chladném severním poloostrově, kde vyrůstala, ale nepochyboval, že v základech to tam bylo stejné jako tady.
Tříštil se o ně stejný širý a ledový oceán.
Stejní pomatení muži, potom, CO SE STALO, dokonce ještě nedůtklivější a mrzutější než jejich předci, pašeráci a kazisvěti, naštvaně bloumali od hospody k hospodě, připravení vztáhnout ruku na kteroukoliv ženu, která by se opovážila je odmítnout nebo se jim vysmát.
Blbec?
Jestli si nebude dávat pozor, předvedou jí svoje pěsti!
Nejdřív ji pomazlit - pomazlit se stalo nejběžnějším výrazem pro erotické dráždění mezi mužem a ženou: protilátka mdlých balad o lásce, které rádio chrlilo - nejdřív ji pomazli, pak jí jednu vraž.
Podle Kevernova názoru přílišná kultivovanost, protože mazlení bylo samo o sobě aktem násilí.
Ailinn Solomonsová mu neverbálně naznačila, aby odešel.
Zvedl se z lehátka jako stařec.
Sama se cítila rozmrzelá, ale tíha jeho smutku ji překvapila.
Nebyl to přece konec světa.
Skoro se neznali.
Dívala se, jak odchází - jako kdyby ho pozorovala z okna v patře - muže, kterého dohnalo, co sám způsobil.
Adam opouštějící zahradu, pomyslela si.
Srdce se jí sevřelo kvůli němu i kvůli všem mužům obecně bez ohledu na to, že pár jich ji zbilo.
Muž se od ní odvrátil, ramena svěšená, zahanbený, poražený, veškerá bojovnost ho opustila - proč jí připadalo, že tenhle pohled dobře zná, i když si nedokázala vybavit jediný moment, až dnes, že by to už někdy viděla?
Ailinn Solomonsová, zase sama, se podívala na své nohy.
Asi dvacet let po těchto událostech Esme Nussbaumová, inteligentní a nadšená dvaatřicetiletá výzkumnice pracující v Ofnow, nestatutárním monitorovacím systému Veřejné nálady, připravila krátký článek o přetrvávání lehkých a středně těžkých násilných činů v oblastech země, kde se jeho zmírnění nebo přímo zastavení, nejvíce očekávalo, kdyby na jeho odstranění bylo vynaloženo dostatek peněz a energie.
„Udělalo se toho hodně a hodně se toho ještě udělat musí,“ napsala, „aby se uklidnila vrozená agresivita lidí, kteří bojovali v mnoha bitvách a většinu z nich vyhráli, a to především v zasutých, těžko dostupných místech země, kde se i přes špičky kostelních věží vystupujících nad živými ploty nádech lidské laskavosti historicky objevoval jen zřídka.“
Některé věci jsou však nenahraditelné.
Mohlo by se zdát, že čím vyšší je kostelní věž, tím nižší jsou pudy.
Obyvatelé vzdychají nad sentimentálními baladami, hltají nešťastné příběhy a prohlašují, že pevně věří v hodnotu manželství a rodinný život, ale nejen, že v rurálních oblastech se stará brutalita drží stejně tvrdošíjně jako v městských aglomeracích, ale důkazy také ukazují, že doma, na pracovišti, silnicích a dokonce na sportovních hřištích se objevuje nová a útočná nesnášenlivost.
„Bohužel máte tendenci k příliš květnatému stylu,“ řekl její nadřízený.
Navrhoval bych vám, abyste četla méně románů.
Esme Nussbaumová sklonila hlavu.
Také se musím zeptat: Jste ateistka?
„Mám dojem, že na to nemusím odpovídat,“ prohlásila Esme Nussbaumová.
Jste lesba?
Esme se znova ohradila svým právem na soukromí a mlčení.
Feministka?
Další ticho.
„Neptám se proto,“ řekl nakonec Rabinowitz, „že bych měl něco proti ateistům, lesbám nebo feministkám.
Na tomhle pracovišti předsudky nemáme.
Sloužíme nepředpojaté společnosti.
Ale jistý druh přecitlivělosti, který je sám o sobě naprosto přijatelný a chvályhodný, může někdy zkreslovat úsudek tak, jak jste to předvedla vy.
Očividně vy sama jste předpojatá vůči církvi - věci, které nazýváte „kruté“ a „brutální“ by jiní mohli interpretovat také jako vyjádření přirozené síly a energie.
Pořád řešit CO SE STALO, KDYBY SE TO STALO, jako kdyby se to stalo, kdyby se to stalo, včera, připravuje zemi s její základní životní sílu.
Zatímco Rabinowitz mluvil, Esme Nussbaumová se rozhlížela kolem.
Za hlavou mu na světelné tabuli růžově blikalo doporučení, které Ofnow vysílalo do světa poslední čtvrtstoletí nebo víc.
Usmívejte se na souseda, pečujte o svého partnera, poslouchejte balady, choďte na muzikály, používejte svůj telefon, konverzujte, vysvětlujte, dohodněte se, omluvte se.
Mluvit je lepší než mlčet, zpívané slovo je lepší než psané, ale není nic lepšího než láska.
„Naprosto chápu vaše výhrady,“ odpověděla tiše Esme Nussbaumová, když si byla jistá, že její nadřízený skončil, „a už netvrdím, že se rána nezhojila tak, jak si namlouváme, že se zhojila.
Mojí obavou především je, že pokud na to nebudeme s předstihem upozorněni, zopakujeme stejnou chybu, která vedla k tomu, CO SE STALO, KDYBY SE TO STALO.
Tentokrát si ale vztek a nedůvěru nebudeme ventilovat na ostatních.
Luther Rabinowitz spojil konečky prstů.
To mělo značit nekonečnou trpělivost.
„Zacházíte příliš daleko,“ řekl, „když kroky, které možná udělali a možná neudělali vaši prarodiče, popisujete jako chyby.
Příliš daleko zacházíte i v tom, že mluvíte o tom, že si ventilovali svůj „vztek“ a „nedůvěru“ na „ostatních.“
Neměl bych někomu na vašem místě připomínat, že v chápání minulosti a v ochraně přítomnosti nemluvíme o „nás“ a o „nich.“
Nebylo žádné „my“ a nebyli žádní „oni.“
Víme jenom to, že se jednalo o chaotické časy.
„Během kterých, pokud k sobě budeme upřímní,“ sebrala Esme odvahu, „nikdo nejsme bez viny.
Nikoho neobviňuju.
Ať už to bylo spravedlivé nebo ne, co se stalo, stalo se.
To bylo předtím.
K tomu není, co dodat - v tomhle spolu souhlasíme.
A stejně jako neexistuje žádná vina, která by se dala na někoho svést, neexistují ani věci, které by se měly napravit, ani kdyby náprava byla vhodná a možná.
Ale k čemu jinému je minulost, než k tomu, abychom se z ní poučili -
Minulost existuje, abychom na ni zapomněli.
Jestli k tomu můžu něco dodat -
Luther Rabinowitz rozpojil konečky prstů.
„Vaši zprávu vezmu v úvahu,“ řekl a propustil ji.
Den na to, když šla jako obvykle do práce, ji srazil motocyklista, který najel na chodník způsobem, který kolemjdoucí popsali jako „brutální a zuřivý.“
Náhody se dějí.
Armáda Lesothského království tvrdí, že žádný puč neplánuje - předseda vlády zůstává v Jižní Africe
Vojenští důstojníci Lesothského království popřeli, že by organizovali puč za účelem svržení vlády, a tvrdí, že jednali proti policii podezřelé z pokusu o vyzbrojení politických fanatiků.
Předseda vlády Thomas Thabane utekl ze země a říká, že armáda obklíčila jeho oficiální sídlo a obsadila vládní budovy v hlavním městě Maseru.
Poté, co prohlásil, že mu vyhrožují smrtí, odjel premiér se svou rodinou do sousední Jihoafrické republiky.
Mluvčí armády major Ntlele Ntoi k tomu řekl, že ve skutečnosti se nejednalo o puč, ale odpověď armády na výhrůžku „politických fanatiků“, které se policie pokoušela vyzbrojit.
„Dnes ráno velení obranných složek Království Lesotha jednalo poté, co obdrželo několik zpráv informační služby, že v řadách policie se vyskytuje několik skupin, které plánují vyzbrojit některé radikální, politické fanatiky, kteří se chystali nadělat v zemi spoušť,“ řekl Hlasu Ameriky.
Mluvčí jihoafrické vlády Clayson Monyela řekl, že vojenské akce vypadaly jako pokus o svržení vlády.
„Přestože nikdo neprohlásil, že se chopil vládní moci pomocí síly, podle všeho nesou akce lesothských obranných složek známky státního převratu,“ uvedl.
Vojenští představitelé Lesothského království řekli, že vojáci se v neděli vrátili do svých kasárna a v hlavním městě byl klid.
Během Thabanovy nepřítomnosti bude za vládu zodpovědný vicepremiér Mothetjoa Metsing.
Thabane prohlásil, že podle jeho názoru je terčem útoku kvůli svým snahám bojovat proti korupci v zemi.
Od června, kdy Thabane pozastavil zasedání parlamentu kvůli vnitřním sporům, panuje v Lesothu napětí.
Prohlásil, že i přes opačná tvrzení, nepodkopává jeho jednání vládu.
Výroba v eurozóně je na třináctiměsíčním minimu
Růst výroby se podle bedlivě sledovaného průzkumu v srpnu v eurozóně zpomalil na třináctiměsíční minimum.
Závěrečný index nákupních manažerů v eurozóně (PMI) z červnových 51,8 klesl v srpnu na 50,7.
Číslo vyšší než 50 značí expanzi.
Ubylo nových objednávek a továrny poškodilo rostoucí napětí mezi EU a Ruskem kvůli Ukrajině.
Čísla pocházejí ze čtvrtečního setkání Evropské centrální banky (ECB).
Trhy budou chtít od banky jasný plán, jak se vypořádat s oddalovaným ozdravením eurozóny i s hrozbou deflace s inflací stagnující na 0,3 %.
Objevily se spekulace, že ředitel ECB Mario Draghi možná tento týden naznačil, že zvažuje kvantitativní uvolňování eurozóny, podobné tomu, k jakému během finanční krize přistoupily Spojené království a USA.
„Přestože alespoň nějaký růst je lepší než žádný růst, brzdný efekt, který má rostoucí ekonomika a geopolitická nejistota na výrobce, je stále viditelnější,“ řekl Rob Dobson, hlavní ekonom Markit.
Výrobní PMI Německa, největšího obchodního partnera Ruska v EU, spadl na jedenáctiměsíční minimum 51,4.
V druhé největší ekonomice zóny, Francii, spadl PMI na 46,9.
Znepokojení panuje ohledně Francie, Itálie zase přešla z expanze to stagnace.
Známky toho, že hnací síla růstu v nejdůležitějších průmyslových oblastech v Německu, Španělsku a také Nizozemí zmizela, také není příliš uklidňující,“ řekl Dobson.
Zpomalení průmyslu pravděpodobně přilije olej do ohně analytikům očekávajícím implementaci dalších měnových nebo daňových stimulů.
Jedna pozitivní zpráva přišla z Irské republiky, kde PMI vzrostl na 57,3, nejvyšší úroveň od konce roku 1999.
Howard Archer, hlavní ekonom v IHS Global Insight, řekl: „To nejlepší, co se dá o výrobním přehledu nákupních manažerů za srpen říct, je, že ukazuje, že sektor stále roste.“
Dodal: Výrobci v eurozóně mají v současné době život velmi složitý, protože zvyšující se geopolitické napětí - především mezi Ruskem a Ukrajinou - přidává ke stále náročným podmínkám v mnoha zemích ještě více nejistoty.
Tato zvyšující se nejistota obchod prokazatelně zasáhla - a to především důvěru spotřebitelů, což pravděpodobně způsobí, že některé objednávky budou odloženy nebo dokonce zrušeny, hlavně ty nákladné.
Uvedl, že jako „ještě více pravděpodobné“ se jeví, že ECB nakonec bude muset provést nějakou formu kvantitativního uvolňování, „ačkoliv očekáváme, že bude jen omezená.“
Deset let pekla přeživších z Beslanu: Deset let od hrůz z obsazené školy děti stále trpí
Před deseti lety bylo čečenskými radikály ve škole v Beslanu v jižním Rusku jako rukojmí zadrženo tisíc lidí
Během utrpení, které trvalo tři dny a které šokovalo svět, bylo zabito více než 330 lidí, z nichž více než polovina byly děti
Vrátili jsme se do Beslanu, abychom vyhledali některé z obětí, které během zvěrstva ve škole unikly smrti
Přesně deset let po děsivém obsazení školy v Beslanu, při kterém zahynulo 334 lidí včetně 186 dětí, varovali včera večer přeživší hrdinové před novou apokalypsou na Ukrajině.
Když 1. září 2004, na začátku nového školního roku, zajali a zavraždili fanatičtí teroristé děti a rodiče, vypadalo to jako nejhlubší dno pekla.
Odpor nad tragédií spojil východ a západ, což v tomto katastrofálním neštěstí vedlo k jednání a budoucnosti.
Po deseti letech jsme se do Beslanu v jižním Rusku vrátili, abychom vyhledali některé z obětí, které během zvěrstva ve škole unikly smrti.
Našli jsme úžasné mladé lidi, kteří vzdorovali neštěstí, i když vzpomínka na peklo způsobené teroristy v nich bude žít dál.
Jaké je jejich největší přání?
Aby válka, která nyní ničí Ukrajinu - a ve které děti jako byli oni umírají - už skončila.
Dívka pokoušející se vlézt zpátky do zničené školní tělocvičny
Byla zachycena předním ruským fotografem Dimitrijem Beliakovem, jak se pouze ve spodním prádle snaží vlézt zpátky do rozbombardované školní tělocvičny poté, co v ní explodovala bomba.
Zmatená Aida zoufale hledala svou matku Larissu, které je nyní čtyřicet.
Panovaly obavy, že obě jsou mrtvé, ale ve skutečnosti přežily.
„Nějaká žena mi řekla, ať utíkám a zachráním si život, ale nemohla jsem,“ řekla tenkrát Aida.
Nohy jsem měla od krve.
Vstala jsem a vlezla zpátky, abych našla maminku.
Zachránil ji voják.
Po několika operacích si myslela, že se už plně uzdravila, ale včera řekla: „Před třemi měsíci se bolesti vrátily.
Bojím se, že budu muset na další operaci.
V koleni mi zůstaly kousky střepin.
Jejím cílem je stát se zubařkou, aby mohla pomáhat lidem tak, jako lékaři pomohli jí.
„Tahle tragédie mi změnila život, ale rozhodně ho nezničila,“ řekla odhodlaně.
„Prostě se mi to stalo a to se nedá změnit.
Jednou ročně chodím do tělocvičny, abych si připomněla ty, kteří tam zůstali.
Jinak se o tom snažíme s přáteli nemluvit.
Ta bolest je moc velká.
Moji nejlepší kamarádku a budoucí spolužačku ze třídy Džeru Gapoevu tam zabili.
Jako malé jsme si spolu hrály a představovaly jsme si, jak spolu budeme chodit do školy.
„Nechci se vdát, dokud nedokončím školu a nezačnu kariéru.
O rodině budu přemýšlet později.
Říká, že na zajetí nezapomněla, ale vzpomínky každým rokem trochu blednou.
Jsem ráda, že tolik lidí na celém světě si pořád pamatuje, co se stalo, a jsme moc vděční za pomoc, kterou jsme dostali z Británie a z dalších zemí.
Když se na internetu dívám na svoji fotku, jak lezu školním oknem, říkám si, že spousta lidí ji uvidí poprvé, pochopí tu katastrofu a zabrání tomu, aby se opakovala.
Chlapec, který unikl deštěm kulek a věřil, že jeho matka je mrtvá
Byl to jeho první školní den (v Rusku děti školu začínají v sedmi letech) a přežil třídenní obléhání školy v objetí své matky Tamary.
V té době sedmiletý řekl: „Mamka mi řekla, že kdyby nastala exploze, mám si lehnout na zem a držet ji za ruku.“
Po explozi si myslel, že matka umírá.
Řekla mu: „Utíkej.“
Bál se, že je mrtvá, utíkal a cestou uviděl plačící batole, popadl dítě za ruku a utíkali sprškou kulek.
Jeho otec Vladimir, který ho venku chytil, řekl: „Damir mi řekl, že jeho matka je mrtvá.“
Povídá: „Nemohl jsem ji zachránit.“
Ve skutečnosti se Tamara dopotácela na svobodu a ležela v nemocnici se zraněnou nohou a naopak si myslela, že její syn zemřel.
Poté, co se znova setkali, řekla: „Plakala jsem štěstím.
Nemohla jsem tomu uvěřit.
Přiběhl dovnitř a objal mě.
Damir poté odletěl do Londýna (podle zaniklých novin News of the World), kde byl tehdejším premiérem Tony Blairem a jeho ženou Cherie prohlášen vítězem Bernardo's Children.
„Ta hrůza se každý den vrací, ale přál bych si, abych na to mohl přestat myslet,“ řekl včera.
Můžu ale říct, že vzpomínky už blednou.
Pamatuju si, že hned potom jsem zahodil všechny svoje pistole na hraní.
Dneska ale můžu hrát počítačové hry, ve kterých se střílí, a nemám s tím problém.
„Nebojím se jít zpátky do tělocvičny, ale nemyslím na sebe.
Vzpomínám na děti, se kterými jsem si hrál na dvoře a které se ven nedostaly.
Nikdy neřekneme, že je zabili nebo že zemřely.
Říkáme, že zůstaly v tělocvičně.
Na výlet do Londýna si pamatuju dobře, hlavně na to, jak jsem si v hračkářství mohl vybrat cokoliv jsem chtěl, a jak jsem jel kabrioletem.
Teď se ale obává o místa jako je Ukrajina, kde kvůli válce trpí stejně jako trpěl on a jeho přátelé.
Ta hrůza se každý den vrací, ale přál bych si, abych na to mohl přestat myslet
„Je mi hrozně líto každého, kdo si takovou hrůzou musí projít,“ říká Damir, který se minulý týden zúčastnil dobrovolnické činnosti v klášteře.
Chci hrozně moc pomáhat.
Jednou chci pracovat u policie a doufám, že mě příští rok přijmou na akademii.
Jeho matka Tamara, 48, říká: „Zabili 37 dětí z našeho sousedství, dokážete si to představit?
Pamatuju si na to ticho hned po útoku. Nikde nebyly žádné děti, které by tady křičely a běhaly, a to ticho trvalo několik měsíců.
Živě si pamatuje na cestu s Damirem do Londýna.
Když jsem náš příběh v Londýně vyprávěla, lidé plakali.
Pak jsem si uvědomila, jak lidi na druhé straně světa dokáží pochopit naše pocity a jak umí vyjádřit svou podporu.
Byla vděčná Cherie Blairové a její nadaci za udělenou cenu a za možnost jet na podzim 2004 do Londýna.
Přeju si, abych mohla Cherie zavolat a osobně říct, že i když je to už deset let, pořád si pamatuju na setkání s ní a jejím manželem v Londýně a jak mně a Damirovi pomohli.
Vzpomínám si, jak měl Damir chuť na boršč, a tak obvolali všechny ruské restaurace.
Taky si pamatuju, jak si v restauraci hrál s číšníky, Damir na ně střílel z vodní pistole a oni utíkali a hráli si s ním.
A to bylo jen měsíc od té hrůzy.
Byla jsem překvapená, jak se s námi Britové chtěli podělit o naši bolest a jak nás podporovali.
Řekla: „Pořád si myslím, že svět se za těch deset let nezměnil k lepšímu.
Teď je válka na Ukrajině, každý den umírají lidé a myslím, že bylo a ještě bude zabito i hodně dětí.
Jsou to stejné děti jako ty naše.
Myslím, že pro hodně lidí je válka jenom něco ve zprávách, které si poslechnou, když se nudí nebo zatímco dělají něco jiného.
Já vím, co ti lidé prožívají, co je to za hrůzu.
Pořád to cítím.
Nic se nezměnilo, lidé se pořád chtějí navzájem vraždit, je to tak smutné.
Damir vyrostl a je z něj milý a tichý kluk, není vůbec agresivní nebo vzteklý.
Například netouží po pomstě, tohle ho vůbec nezajímá.
Vím, že na to nerad vzpomíná, ale má hodně blízko k šesti spolužákům a čas od času chodí do tělocvičny a zapalují tam svíčky.
Když byl menší, měl s tím problémy - vzpomínám si, jak si někdy lehl na gauč s obličejem odvráceným od nás a někdy tak ležel hodiny.
Nespal, měl otevřené oči.
Taky si pamatuju, že vyhodil všechny svoje pistole nebo jiné zbraně na hraní. Damirovi je dneska 17, je vyšší než já, hezký, chytrý a zdravý.
Stěží můžu uvěřit, že jsem si několik hodin byla jistá, že je mrtvý a že už ho nikdy neuvidím.
Když jsem se po explozi vzpamatovala a zvedla se na nohy, podívala jsem se kolem a uviděla to peklo, všude ležely kusy lidských těl.
Byla jsem si naprosto jistá, že můj chlapeček neměl tohle peklo šanci přežít.
„Pamatuju si, jak jsem křičela ‚Damire, utíkej, utíkej!‘, ale byla jsem přesvědčená, že mě neslyšel.
Ale slyšel ji a utekl.
Takže náš život jde na rozdíl od jiných dál.
Grigorij Ilyin, 17
Chlapec, jehož pořízená fotka po útoku se stala symbolem hrůz v Beslanu
Útěcha: Přeživší z Beslanu Grigorij Ilyin se svou matkou Fatimou po útoku v roce 2004, napravo Grigorij dnes
Když utíkal o život poté, co čečenský terorista zastřelil jeho spolužáky, byl do jeho zakrváceného obličeje vrytý strach.
Jeho fotka byla jedním z nejvíce šokujících symbolů zvěrstva v Beslanu.
Jeho matka Fatima, 54, lékařka, ho jeho první den vysadila u školy a spěchala odvézt svého staršího syna Vladimira na univerzitu.
„Odjela jsem dvě minuty předtím, než teroristé vtrhly na dvůr, takže můj chlapeček tam tři dny zůstal sám,“ vzpomínala.
Ne úplně sám, protože jsme tam měli příbuzné, ale všichni tam zemřeli.
Přežil jenom můj Grigorij.
Jak se to datum blíží, je pořád těžší o tom přemýšlet a mluvit.
Neuplyne ani jediný den, abychom na tu tragédii nevzpomínali.
Nepřipadá nám, že se to stalo už dávno, mám pocit, že to bylo včera, některé okamžiky se mi pořád vrací.
Slibuju, že nikdo nikdy nezapomene.
Stále se vracející vzpomínky: Fotka Grigorije (vlevo) byla jedním z nejvíce šokujících obrázků útoku a byla zvěčněna jako socha (vpravo)
Vzpomínám si, jak se ten den Grigorij hrozně těšil do školy, říkal, že chce obejmout svoji učitelku.
Že je živý, jsem se dozvěděla, když jsem ho viděla v televizi.
V San Marinu je dokonce socha plačícího Grigorije.
Grigorij se na tu fotku dívá nerad a doma ji máme schovanou v knihovničce.
Chápu to, ale taky si myslím, že díky tomu obrázku lidé na celém světě vědí, jakou bolest cítíme.
Dnes Grigorij říká: „Důležité je, aby se tohle už neopakovalo.
„Pochybuju, že se někdy dozvíme pravdu.
Podobné tragédie se pořád vyšetřují, ale pravdu nikdo nikdy nezjistí.
Teď vyšetřují tu havárii boeingu na Ukrajině.
Dozvíme se někdy, co byla příčina?
Tenhle svět čeká něco moc špatného.
„Nechápu, proč se to děje, protože když se lidí zeptáte, tak válku nikdo nechce, tak jak je to možné?
Deset let není pro takovou bolest nic.
Abychom aspoň trochu zapomněli, potřebuje desítky let.
Mělo to vliv na moje zdraví, pořád to cítím.
Tři nebo čtyři roky jsem měl kvůli útoku noční můry, ale pak se to zlepšilo.
Když jsem se pak v roce 2004 vrátil do školy, každý den jsem byl vyděšený.
Myslel jsem na svoje přátele a spolužáky, které zabili.
Proto, když se blíží 1. září, chodím do tělocvičny.
Chci uctít památku přátel z dětství.
Je pro mě těžké do té tělocvičny vstoupit, ale musím.
Necítím se jako oběť, tenhle příběh je minulostí.
Nezapomenu na to, ale nelituju se.
Můj život jde dál.
Letos jsem dokončil školu a začal studovat medicínu na univerzitě ve Vladikavkazu.
Chci být kardiochirurg.
Nejdřív jsem chtěl vstoupit do armády.
Chtěl jsem být voják, ale kvůli zdraví jsem nemohl.
Chtěl jsem bojovat za svou zemi, ale nepůjde to.
Grogorij Farniyev, 20
Chlapec, který přežil, přestože ho drželi u nohou vraždícího teroristy
Zázrak: Gregorij Farniyev byl během útoku držen u nohou vraždícího teroristy, přesto však dokázal přežít
Když byl útok v plném proudu, byl zachycen uvězněný v tělocvičně, jak sedí vedle bomby u nohou vraždícího teroristy.
Je to opravdový zázrak, že přežil.
„Připadá nám to, jako kdyby to bylo včera,“ řekl Gregorij, který se chtěl stát agentem Federální služby bezpečnosti, ale kvůli zraněním, která utrpěl během útoku, nemohl.
Pořád je to se mnou, není to něco, co jsem hodil za hlavu.
Teď už jsem starší a říká se, že děti se se špatnými zážitky dokáží vypořádat líp - musím říct, že to není pravda.
„V roce 2006 jsem chodil k psychologovi a bylo mi pak trochu líp, ale nemůžu zapomenout.
A zapomněl bych rád.
V roce 2005 - rok nato - to bylo poprvé a naposledy, co jsem do tělocvičny znova vstoupil.
Omdlel jsem.
Už tam nikdy znova nepůjdu a nechtějte po mně prosím, abych vám ukázal, kde na tom dobře známém obrázku sedím.
Přeživší: Gregorij Farniev dnes, na notebooku se svou fotografií pořízenou v nemocnici po útoku
Ta bolest je obrovská a nesu si ji s sebou každý den.
Přátelé vědí, že o tom nerad přemýšlím nebo mluvím a nikdy se mě na školu neptají.
Co se týče fyzického zdraví, jsem v pořádku.
Musím být opatrný na svoje koleno, které jsem si poranil, ale už chodím normálně.
Ale i tak jsem kvůli zdraví nemohl nastoupit a studovat na akademii FBS v Petrohradu, jak jsem chtěl.
Poslal jsem jim svoje dokumenty včetně lékařských zpráv a odpověděli mi, že to není možné.
Mojí další zálibou jsou zvířata, tak jsem nastoupil na veterinu.
Dodělal jsem tam druhý rok.
Učí se, jak léčit všechna zvířata od „koček po krávy“.
Řekl: „Vím, že svým dětem o tom nikdy vykládat nebudu.
Není to něco, o čem by děti měly vědět a už vůbec ne něco, co by měly zažít.
Jeho matka Marina, 42, uvedla: „Ta bolest tady bude pořád.
Je uvnitř a zhoršuje se s blížícím se výročím.
Zúčastním se připomínkových ceremonií.
Vím, že Grigorij nepůjde.
Musí to být pro něj ještě silnější, protože tam na rozdíl ode mě byl.
Já jsem na něj čekala doma a nemohla jsem mu pomoct.
Jsem bohu tak vděčná, že mi ho vrátil. Tady v Beslanu jsou stopy všude.
Zůstává to s námi.
Gregorij je dneska dospělý, ale tu hrůzu si nese dál.
Je těžké přijmout, když se vám stane něco tak strašně nespravedlivého.
Je to kluk, má rád sport, ale nemůže ho dělat kvůli svému koleni.
Podstoupil několik operací, může chodit, ale nemůže cvičit.
Řekla bych, že tak z 50% už ten děs překonal, ale překonat to úplně a zapomenout nejde.
Tahle strašná zkušenost s námi bude pořád.
Během útoku zabili hodně našich přátel a sousedů a to bolest jenom zhoršuje.
Ztratila jsem hodně lidí, které jsem měla ráda a kteří mi byli blízcí.
Můj syn je se mnou a to je ten největší dar, jaký mi bůh mohl dát, ale bolí mě ztráta zabitých.
Znám rodiny, ve kterých se narodily další děti, ale také vdovy, které už se znova nevdaly.
Je těžké přijmout, že život jde dál, i když nechcete.
Nikdy nezapomenu, jak mi srdce málem vyskočilo z hrudníku, když jsem ho uviděla v nemocnici.
Teď pozoruju, co se na světě děje - války na jiných místech.
Za co ti lidé bojují?
Proč se navzájem zabíjejí?
Válka se teď blíží k naší zemi, čemuž můžu stěží uvěřit.
V minulosti jsme byli jedna spřátelená země, tak jak jsme se dostali k tomu, že spolu teď bojujeme?
Lidé a děti trpí, jsem si jistá, že mnoho dětí na Ukrajině bylo a ještě bude zabito.
Kdybychom tak mohli všechny ty rebely sebrat a zahodit je - jak nejdál to půjde.
Alyona Tskaeva, 10
Dítě, které odneslo do bezpečí speciální komando
Zachráněna: Alyonu Tskaevu nese do bezpeční ruské speciální komando (vlevo).
Nyní je jí deset (vpravo) a na tragédii si vůbec nevzpomíná
Svět v roce 2004 zalapal po dechu, když malou Alyonu vynesl v náručí z beslanského zajetí ruský policista.
Teroristé ji propustili, v zajetí ve školní tělocvičně si však ponechali její třicetiletou matku, desetiletou sestru Kristinu a bratra Makhara.
Makhar, kterému v tu dobu byly tři roky, unikl, Alyonina matka a sestra však při masakru zemřeli.
Její bratr Ruslan se znovu oženil a se svou novou ženou Světlanou mají holčičku, kterou po mrtvé dceři pojmenovali Kristina.
Sousedé říkají, že Alyona, které je nyní deset, si na útok vůbec nevzpomíná a vyrostla z ní bystrá a šťastná holčička.
Blízký přítel prohlásil, že „je to velká šťastná rodina a Alyona a Makhar jsou skvělé děti.“
Ruslan je výborný otec a chce děti udržet daleko od vzpomínek, které desáté výročí připomíná.
Dokážete pochopit proč.
Muž obviněn ze sražení dívky na přechodu na znamení v obci Fife
Osmasedmdesátiletý muž před soudem za to, že na přechodu na znamení v obci Fife srazil tříletou dívku.
Gordon Stewart údajně dívku srazil na přechodu v Pittenween v East Neuk.
Žalobci tvrdí, že Stewart neřídil své Audi Q3 s dostatečným ohledem a pozorností a dívku zranil.
Stewart (78) z Anstrutheru obvinění u soudu v Dundee popřel.
Soudce Charles Macnair stanovil datum stání na leden.
4 tipy, jak pod vodou pořídit lepší fotky a videa
Pokud se zajímáte o focení nebo natáčení pod vodou, máte k dispozici velký výběr vybavení.
Nejlevnější možností je kompakt jako například Nikon Coolpix AW120 nebo outdoorová kamera typu GoPro Hero3+ Silver Edition, které stojí okolo 300 dolarů.
Tyhle fotky jsem pořídil na rodinné oslavě několika foťáky, všechny stály méně než 350 dolarů.
Je jedno, jaké vybavení používáte, ale pro dosažení nejlepších výsledků platí několik pravidel.
Překontrolujte si vybavení.
I když máte vodotěsný fotoaparát, ujistěte se, že baterie a další části jsou pevně uzavřené.
Dále nastavte fotoaparát podle toho, jaký typ fotek nebo videí budete pořizovat.
Některé fotoaparáty a videokamery mají scénický nebo natáčecí režim, který expozici optimalizuje na tmavé prostředí pod vodou.
A než se do toho pustíte, zjistěte si, jak hluboko se můžete se svým vybavením ponořit.
Některé fotoaparáty jsou určeny jen do 5 stop, další do 50 až 60.
Přečtěte si našeho průvodce nákupem a hodnocení digitálních kamer v běžném i vodotěsném provedení.
Dělejte vždy několik snímků - hodně z nich nevyjde.
Kompaktní fotoaparáty mají LCD, které vám pomůže s kompozicí fotek, ale outdoorové ho nemají.
I když LCD máte, pod vodou bude špatně vidět a kompozice záběru bude nepředvidatelná.
Takže vždy dělejte více snímků.
Pokud má fotoaparát bracketingový režim, který dělá série snímků s mírně odlišným rozptylem expozice, využijte toho.
Držte se blízko u hladiny.
S hlubším ponorem světla výrazně ubývá.
Pokud je to možné, držte se při focení v bazénu, jezeře nebo moři blízko hladiny.
To vám také umožní zachytit na fotkách víc světla - čím hlouběji se potopíte, tím méně barev uvidíte.
Dostaňte se blízko k fotografovanému objektu.
To je výborná rada, pokud fotíte na souši, ale pod vodou je ještě důležitější kvůli tlumenějšímu světlu.
Je to obzvlášť důležité, pokud natáčíte s outdoorovou kamerou: Taková zařízení mají obvykle pevný a široký úhel čočky, což znamená, že pokud chcete zaplnit fotorámeček, musíte se k objektům víc přiblížit.
Andrew Lawson byl člověk, jehož síla osobnosti dokázala měnit věci dokonce i v tak obrovské organizaci jako NHS.
Jako anesteziolog svou kariéru zasvětil tomu, aby nemocným ulevoval od bolesti způsobené nemocí i léčbou.
Jeho žena vzpomíná, že jeden z lidí, kteří vyhledali jeho pomoc, byl důstojník MI6, který musel žít s následky mučení, které ho zmrzačilo.
Lawson pochopil, že zatímco lékaři se soustředí na diagnózy a nemoci, léčené pacienty v drtivé většině zajímá úplně něco jiného: bolest.
Jednoho dne v roce 2007 to však byl on, kdo začal trpět.
„Necítím se ve své kůži,“ napsal v květnu toho roku.
Cítil jsem se bez energie.
Potýkal se s příznaky chřipky a zjistil, že je netrpělivý a svou ženu Juliet zahrnuje výčitkami.
Poznamenal si: „Chci, aby se všechno dělo spíš dřív než později.“
Když Juliet na týden odjela na služební cestu, Lawson byl nezvykle a nevysvětlitelně rozrušený.
Něco nebylo v pořádku.
Kolega mu udělal rentgen hrudníku.
Jednom dva týdny předtím lyžoval ve francouzských Alpách.
Přišly výsledky rentgenu.
Měl mezoteliom, nevyléčitelný nádor, který postihuje pohrudnici nebo-li výstelku plic.
U většiny druhů rakoviny je těžké určit, co bylo jejich příčinou.
Přestože někteří kuřáci dostanou rakovinu plic, ne všichni pacienti s rakovinou plic kouřili.
Mezoteliom je ale jiný.
Téměř ve všech případech je příčinou vystavení azbestu - stavebnímu vláknitému materiálu, který byl dříve označován za „zázračný“, ale dnes se ví, že je smrtelně nebezpečný.
Pro většinu z nás nebylo těžké mezoteliom ignorovat.
Azbest, koneckonců, patří minulosti.
Nejnebezpečnější typ azbestu se v Británii nepoužívá od 60. let, kdy vstoupil v platnost zákaz používání azbestu v průmyslu.
I v době, kdy byl azbest používán, s ním do úzkého kontaktu přišly jen určité skupiny lidí, například pokladači izolace, stavbaři, tesaři a dělníci v loděnicích.
Toxin používaný v průmyslu v jiné éře se dnes těžko jeví jako důvod k obavám.
Taková samolibost ale není na místě.
Jak se ukazuje, v Británii dnes vrcholí mezoteliomová epidemie.
Počet úmrtí na mezoteliom je zde vyšší než v jakékoliv jiné zemi na světě.
2 500 úmrtí na toto onemocnění ročně je dvakrát více než počet obětí automobilových nehod.
Počet úmrtí na následky mezoteliomu ročně od roku 1980 a odhadovaná úmrtí v budoucnu ve Velké Británii
Důvod, proč teprve teď pociťujeme jeho účinky, přestože je použití azbestu již roky nezákonné (všechny druhy azbestu byly nakonec zákonem zakázány v roce 1999), je, že obvykle trvá několik desetiletí, než se mezoteliom rozvine.
Pohroma v podobě mezoteliomu ne netýká jenom veteránů stavebního průmyslu.
Azbest byl, a v mnoha případech stále je, přítomný v domovech, ve kterých žijeme, v kancelářích, kde pracujeme, ve školách, kde se učíme, a v obchodech, ve kterých nakupujeme.
Mezoteliom tedy nerespektuje sociální vrstvu, bohatství, povolání ani věk.
Privilegované bašty od londýnských obchodních domů po veřejné školy nepředstavují úkryt.
I Parlament je plný azbestu.
Dokonce i nemocnice, ve kterých by nás měli léčit, jsou úložiště tohoto smrtelného karcinogenu.
Andrew Lawson nebyl starý.
Ani nepokládal izolaci.
Snažil se zjistit, kde mohl přijít do kontaktu s azbestem.
Pak na to přišel.
„Je možné, že hodně azbestu bylo v suterénních chodbách Guy's Hospital, kde jsem strávil šest let na praxi,“ napsal.
Všichni - studenti, sestry, lékaři a vrátní - chodby používali.
Otázkou je, kolik z mých současníků dostane stejnou nemoc?
Bohužel to byla otázka, na kterou dokázal částečně odpovědět.
„Ze čtyř lékařů, kteří byli na praxi v Guy's Hospital a u kterých se poté v minulých pěti letech projevil mezoteliom,“ poznamenal v dopise v roce 2010, „jsem jediný pořád naživu.“
Kolik z nás onemocní?
Andrew Lawson byl s mezoteliomem diagnostikován, když mu bylo 48.
Když 17. února tohoto roku zemřel, bylo mu 55.
Přežívat s touto diagnózou tak dlouho není obvyklé.
55 procent lidí diagnostikovaných s mezoteliomem zemře do osmi měsíců od diagnózy.
Nemoc je vždy smrtelná.
Nyní tedy můžeme pouze zopakovat Lawsonovu otázku: „Kolik z nás onemocní stejnou nemocí?“
Podle předního britského odborníka na mezoteliom profesora Juliana Peta nejlepší odhad je, že mezi lety 1970 a 2050, kdy se azbestová epidemie v Británii odehrává, zemře asi 90 000 lidí.
Většina z nich v současné době nemá tušení, že zemře tímto způsobem.
Azbestový důl v Quebecu, Kanadě
Při zběžném nahlédnutí do spisů z archivů soudů, na které se postižení často obracejí a vyžadují vyrovnání, ukazuje, jak moc se mezoteliomická pohroma rozšířila.
Například tento červen přiznala společnost Marks & Spencer, že z nedbalosti vystavila azbestu Janice Allenovou.
Pro řetězec pracovala devět let, od roku 1978 do roku1987, kdy dohlížela ve dvou prodejnách na sekci s oblečením - jednou z míst byla vlajková loď společnosti, obchod na Oxford Street.
Allenové bylo pouze 18, když pro M&S začala pracovat.
Dnes má dvě děti, kterým je přes dvacet.
„Předtím, než se to stalo,“ říká, „jsem o mezoteliomu nikdy dřív neslyšela, sotva jsem něco věděla o azbestu.
Nikdy mě ani ve snu nenapadlo, že by se mě mohl nějak týkat.
Není moc lidí, kteří o azbestu něco vědí.
Ve skutečnosti není azbest jedna látka, ale skupina šesti minerálů.
Jméno dostal díky své fibrózní struktuře, která mu dává sílu a ohebnost.
Ze šesti minerálů byly ve stavebnictví používány tři.
Nejčastěji je dnes v budovách možné nalézt chryzotil, běžně známý jako bílý azbest.
Byl používán ve střešních panelech, podlahových dlaždicích, bojlerových těsněních a dokonce v brzdovém obložení.
Není tak smrtelný jako jiné formy azbestu, EU a WHO ho přesto považují za „velké zdravotní riziko“, které může způsobit smrt.
Nebezpečnější ale je hnědý azbest (amosit) a modrý azbest (krokydolit).
Británie byla kdysi největším světovým dovozcem hnědého azbestu a odborníci tvrdí, že „existuje přesvědčivý, ale nepřímý důkaz, že to bylo hlavní příčinou neobvykle vysokého výskytu mezoteliomu [ve Spojeném království].“
Zaměstnankyně Marsk & Spencer byla azbestu vystavena ve vlajkové prodejně v Oxford Street v Londýně
Janice Allenová se možná nepovažuje za typickou oběť mezoteliomu, ale práce Juliana Peta poukazuje na to, že její příběh vůbec není neobvyklý.
Jeho studie pacientů tvrdí, že „podstatná část případů mezoteliomu bez známé expozice azbestu v práci nebo doma byla pravděpodobně způsobena vystavením azbestu v prostředí.“
Značná část této expozice je způsobena „běžným využíváním a zvětráváním“ budov.
Zdá se, že nikdo si nemůže být jistý, že je v bezpečí.
Zpráva Goddard Consulting, která zkoumala Westminsterský palác, ukazuje, že ani lidé ve středu vlády nemusí tušit, že jsou možná vystavováni azbestu.
V roce 2009 zveřejnil Goddard zprávu, podle které jsou služební výtahy a potrubí za místnostmi parlamentního výboru kontaminovány azbestem, jehož smrtelná vlákna by mohla být porušena něčím tak neškodným jako je „silný proud vzduchu.“
Ministři jsou často obviňováni z toho, že se starají jen o své vlastní zájmy, v tomto případě ale může být opak pravdou.
Přestože ředitelství služeb Parlamentu trvalo na tom, aby Westminsterský palác dostal „kladné lékařské osvědčení“, počítá se nyní s tím, že bude zapotřebí jednoho milionu liber a několika let práce, aby byl Parlament důkladně prohlédnut, zmodernizovala se elektřina a odstranil azbest, a že po volbách v roce 2015 budou poslanci spíše než na zelených lavicích ve Westminsteru sedět v prostorách Konferenčního centra královny Alžběty II.
Ve zprávě Goddardu stojí, že „přítomnost azbestu není v souladu s několika předpisy.“
Není možné říct, zda tento nesoulad bude stát životy.
Všichni nyní mohou jen čekat.
Jedna z osob, které nikdy nebyly schopné určit, kdy u nich došlo k expozici azbestu, je Graham Abbott, lékař.
Stejně jako Andrew Lawson má i Abbott (50) podezření, že byl azbestu vystaven při práci v nemocnicích.
„Pracoval jsem v nemocnici, kde byla prokázána přítomnost azbestu,“ říká, „ale ve svém případě to nemůžu prokázat.
Je obtížné pamatovat si všechna místa, kde pracoval, a kdy tam pracoval.
Jasně si ale pamatuje na den na začátku prosince 2009, kdy ho zdolalo něco jako zimnice.
Bylo mu 45, byl večer a zrovna byl uprostřed operace.
Najednou jsem se roztřásl.
Přišlo to naráz.
Bylo mi hrozně.
Myslel jsem, že nedojedu autem domů.
Protože byl doktor, věděl, že bolest vychází z pohrudnice, výstelky okolo plic.
Ale stejně jako Janice Allenová neměl důvod domnívat se, že se jedná o mezoteliom.
Nakonec strávil doma měsíc.
Zmatení doktoři mu udělali rentgen hrudníku a zavedli mu hrudní katetr, aby mu z plic odstranili tekutinu, kterou poslali na rozbor.
Přesto neurčili diagnózu.
Jeho stav se pomalu zlepšil a vrátil se do práce.
Čas od času se mu ale symptomy vrátily, často poté, co si zacvičil a zadýchal se.
V roce 2011 přišel na operační sál jeden z Abbottových pacientů s podobnými příznaky a následně u něj byl diagnostikován mezoteliom.
Ani tehdy si však Abbott nic nespojil se svým vlastním případem.
Konec konců, jeho pacient byl o několik desítek let starší a v práci se dostal do přímého kontaktu s azbestem.
V tomto případě byla spojitost jasná.
V září 2011 se Abbottův stav opět zhoršil a jeho lékař zkonzultoval jeho snímky z CT a rentgenu s panelem odborníků.
V prosinci 2011, přesně dva roky poté, co se Abbott začal cítit špatně, mu byla do prostoru mezi výstelkou hrudní dutiny a výstelkou plic zavedena sonda vybavená kamerou.
Jsem optimista.
Mám tendence nic si moc nebrat,“ říká.
Abych byl upřímný, moc jsem si s tím nedělal starosti.
Ale Rachel, moje žena, si starosti dělala.
Výsledky biopsie dorazily mezi Vánocemi a Novým rokem: „Řekli mi, že je to mezoteliom.“
Graham Abbott: diagnostikován s mezoteliomem
Abbott se začal scházet se sestrami z charitativní organizace Macmillan a jedna mu poradila, aby kontaktoval právníka.
V tu chvíli si uvědomil rozsah epidemie.
„Ukázalo se, že azbest byl hojně používán, především ve velkých veřejných budovách, které mají často azbestovou tepelnou izolaci v potrubí,“ říká.
U lidí, kteří byli v těchto budovách azbestu vystaveni, se nyní začíná nemoc projevovat.
Mezoteliom se tedy nyní začíná týkat mladších lidí, kteří nemají riziková povolání.
Ty nejnebezpečnější trubky tepelně izolované azbestem se v nemocnicích nacházely v suterénu, bylo tedy nepravděpodobné, že by ohrozily pacienty.
Ovšem členové personálu, kteří suterénními chodbami přecházeli mezi budovami (jako Andrew Lawson) nebo jedli v suterénních jídelnách (jako často Graham Abbott) zcela jistě do kontaktu s toxickou látkou přišli.
Jak se nyní ukazuje, byly několik desítek let po válce nemocnice místem, kde mohli pacientům zachránit život, ale také místem, které mohlo ohrozit život doktorů, kteří je léčili.
Azbest se odstraňuje dodnes.
Žáci si Bunsenův kahan stavěli na azbestové podložky
A nejde jenom o nemocnice.
Azbest se často používal v kancelářích, obchodech, knihovnách a radnicích kvůli svým výborným izolačním a nehořlavým vlastnostem.
Ve školách také.
Ve skutečnosti bylo mnoho lidí azbestu vystaveno už ve škole.
Někde si v nesčetných hodinách chemie studenti stavěli Bunsenův kahan na azbestovou podložku.
Vznikly webové stránky zabývající se otázkou azbestu ve školách.
Neškodné věci jako podlahové dlaždice nebo střechy přístřešků na nářadí v našich domovech běžně obsahovaly azbest.
„Jedná se o průmyslový jed zabudovaný do velkého množství domů,“ poznamenává Andrew Morgan, právník, který zastupoval Andrewa Lawsona v jeho žalobě proti Guy's Hospital.
V jednom případě proběhl jediný kontakt s azbestem, na který si žena trpící mezoteliomem dokázala vzpomenout, v 70. letech při boření zahradního domku.
Takže si dávejte pozor, jak boříte zahradní domek.
S vědomím, že nemoc je neléčitelná, je dopad diagnózy obrovský.
„Chvíli trvá, než vám to dojde,“ říká Graham Abbott.
Vrátil jsem se do práce a snažil se pokračovat, ale zjistil jsem, že se nemůžu soustředit na to, co dělám.
Na operačním sále jsem byl dva týdny.
Pak jsem si uvědomil, že budu muset odejít a vypořádat se sám se sebou.
No, dalších Vánoc se nedožiju.
Jedna z nejtěžších věcí byl přechod z pozice lékaře na pozici pacienta.
Jako nesčetné množství pacientů před ním i on si pamatuje, jak se cítil zmatený z množství informací, se kterými se musel vypořádat.
„Bylo těžké tomu všemu porozumět,“ říká.
„Zeptal jsem se svého lékaře: „Kolik času mi zbývá?“
Bylo mi řečeno, že dvanáct měsíců.
Pamatuju si, jak jsem si říkal: „No, dalších Vánoc se nedožiju.
Tak to je.“
Mezoteliom je obzvlášť destruktivní, protože samotný mechanismus toho, co nás udržuje při životě - samotné dýchání - je to, co způsobuje rakovinu, která zabíjí.
Většina případů mezoteliomu je způsobena vystavením azbestu.
Azbest tvoří drobná vlákna.
Když se azbest poruší a vlákna se vdechnou, mohou se usadit v pohrudnici, výstelce plic.
Azbestová vlákna pohrudnici dráždí a mohou vyvolat mutaci buněk.
„Problém představují vdechnutá azbestová vlákna ve tvaru jehliček,“ vysvětluje profesor Tom Treasure, kardiochirurg, který v roce 2001 nastoupil do Guy's Hospital.
Do stejné nemocnice, kde byl Andrew Lawson zřejmě vystaven azbestu a která je paradoxně vedoucím centrem v léčbě mezoteliomu.
Treasure Lawsona zná a léčil i další pacienty, kteří byli azbestu vystaveni pravděpodobně během praxe v nemocnici.
Jehličky azbestu se dostávají do tkáně plic, říká Treasure, a „samotné dýchání je tlačí na okraj tam, kde se nachází výstelka.
Svou povahou je od samého začátku invazivní.
Na mezoteliom běžné léčebné možnosti používané u jiných typů rakoviny tolik nezabírají.
Žhavě se diskutuje například o účinnosti operace.
Podle některých by stála za pokus.
Treasure nesouhlasí.
„Nemůžete odstranit pohrudnici,“ říká.
Nedostanete kolem ní skalpel.
Rakovina „příliš neodpovídá na chemoterapii“, která sice „má nějaký efekt“, ale neléčí.
„Občas se vyskytne někdo, kdo rakovinu plic přežije,“ říká Treasure.
Ale nakonec všichni zemřou.
Naštěstí někteří pacienti žijí mnohem déle, než se očekávalo.
Autor Stephen Jay Gould zemřel 20 let po diagnóze.
Dva a půl roku od své vlastní diagnózy Graham Abbott stále bojuje.
Po zjištění mezoteliomu se Abbott zkontaktoval s Andrew Lawsonem který se, čtyři roky od své diagnózy, stal individuální podporou a poradcem pro stejně postižené lidi.
Když volali, vesele se představil: „Dobrý den, dovolali jste se na centrálu rakoviny.“
„Byl hodně pozitivní,“ říká Abbott.
Nemoc mu diagnostikovali před čtyřmi lety a byl pořád velmi aktivní.
Na začátku Abbottovi nabídli šest cyklů chemoterapie, které by trvaly čtyři měsíce, a pravděpodobně by mu život prodloužily jen o měsíc.
„Byl jsem zoufalý,“ říká.
Chtěl jsem to vzdát.
Lawson ale „dokázal věci ukázat v optimističtějším světle.“
Poté, co navštívil několik lékařů, se Abbott rozhodl pokračovat v léčbě s profesorem Loic Lang-Lazduskim z oddělení hrudní chirurgie v nemocnici Guy's Hospital.
„Měl jsem výhodu, že jsem nemusel čekat, až mě k němu pošlou, ale jenom jsem tam zavolal a oni mě prohlídli,“ přiznává Graham.
Normální pacient by musel dostat žádanku a museli by mu schválit úhradu.
Aby se mohli dostat k nejlepší dostupné léčbě, je pro pacienty s mezoteliomem otázka peněz klíčová.
Ale když různé léčby nakonec nevyhnutelně selžou, mnoho pacientů čelí dalším finančním starostem - o budoucnost rodiny, kterou tu zanechají.
A proto se obrací na soudy a chtějí kompenzaci.
Andrew Lawson kontaktoval Andrew Morgana z Field Fisher Waterhouse LLP.
„Od roku 1898 se vědělo, že azbest je zdraví škodlivý,“ říká Morgan.
V 60. letech se ale zjistilo, že i jeho velmi malé množství může představovat zdravotní riziko.
A zde se setkáváme s nedbalostí firem.
Andrew Lawson a Guy's Hospital se nakonec vyrovnali, ale podle Morgana to nebylo „plnohodnotné vyrovnání“, protože Lawson nemohl definitivně prokázat, že mezoteliom byl následkem expozice azbestu v Guy's Hospital.
Po vyšetřování případu však mluvčí Guy's Hospital potvrdil, že „azbest v inkriminované suterénní části byl odstraněn v 90. letech.“
To bylo pro Andrewa Lawsona příliš pozdě.
Jak odstranit azbest
Svádět expozici smrtelného azbestu na jednu firmu nebo místo výkonu práce - obvykle desítky let poté, co se tak stalo - se pro pacienty s mezoteliomem usilující o kompenzaci ukázalo být obrovským problémem.
Hodně bývalých pracovišť změnilo majitele nebo zkrachovalo.
Evidence pojistek se ztratila.
A ti, kteří se nyní obviněním brání, mají na své straně čas, což jejich žalobci rozhodně ne.
V reakci na tento fakt byla tento rok schválena důležitá nová legislativa, díky které je pro pacienty s mezoteliomem jednodušší domáhat se vyrovnání, i pokud není možné jejich bývalého zaměstnavatele dohledat.
Zákon vytvořil 350 milionovou finanční rezervu, kterou hradí pojišťovny a která je určena lidem diagnostikovaným po červenci 2012, kteří mohou prokázat, že byli vystaveni azbestu, ale nemají koho žalovat.
V takovém případě postižení dostanou 80 % z částky, kterou by jim v normálním případě soud přiřkl jako vyrovnání - přibližně 120 000 liber.
Každý rok se očekává 300 úspěšně vyřízených žádostí.
Andrew Morgan si stejně jako pacienti s mezoteliomem myslí, že 350 milionů liber je „dobrá práce“.
„Je to dohoda sepsaná pojišťovnami pro pojišťovny,“ říká a poukazuje na to, že suma je čtvrtina toho, co by pojišťovny musely zaplatit, kdyby nezasáhl čas a lidé s mezoteliomem by byli schopní dopátrat bývalé zaměstnavatele a normálním způsobem je zažalovat.
Dokonce i Mike Penning, bývalý ministr práce a sociálních věcí, přiznal, že zákon „měl mezery.“
Ale Penning i Morgan připouštějí, že vzhledem k sedmi úmrtím každý rok bylo nutné rychlé jednání.
„Lidé příliš trpí a pomoc potřebují hned,“ řekl Penning v prosinci minulého roku během druhého čtení zákona týkajícího se mezoteliomu.
Graham Abbott byl v péči profesora Loic Lang-Lazdunskiho 19 měsíců.
Po počátečních konzultacích doporučil Lang-Lazdunski operaci, o které si na rozdíl od Toma Treasura myslel, že má pozitivní efekt.
Po operaci následovala radioterapie a chemoterapie - trojitá léčba, u které se Lang-Lazdunski může chlubit mírou přežití pět let až u 40 % pacientů.
Abbotta to posílilo.
„To samozřejmě není ta nejdůležitější věc,“ říká Abbott.
U pacientů to vidíte pořád.
Existuje něco, co vás pohání.
Když se vzdáte, může se váš stav velmi rychle zhoršit.
Graham Abbott podstoupil v březnu 2012 operaci.
Koncem srpna dokončil poslední z šesti cyklů chemoterapie.
Kontrolní prohlídky neukázaly žádné příznaky nemoci.
Na další kontrolu jsem šel v březnu [2014].
V hrudníku jsem měl rozesetých několik skvrn [rakoviny].
Zrovna se blížily moje padesáté narozeniny.
Neohrožuje to život.
Bere ho to.
Abbott znovu podstoupil šest cyklů chemoterapie.
V současné době nejsou v jeho těle žádné stopy nádoru.
Je to ale fyzicky i emočně vyčerpávající proces.
Musíte myslet na praktické věci - na finanční zajištění, až umřu, nebo na to, abych ukázal ženě, jak funguje budík na kotli.
Když se dozvíte špatné zprávy, začnete být negativní.
Musíte se dívat dopředu.
Jako pro otce Ellie (16) a Tamsin (14) to není vždycky jednoduché.
„Pro rodiče je to těžké,“ říká.
Je těžké rozhodnout se, co říct a kolik toho říct.
Po diagnóze jsem holkám řekl, že můj stav znamená, že nikdy nebudu starý.
Jejich reakce byla odlišná.
Tamsin je hodně společenská a divoká.
Řekla to kamarádům a najednou nám začalo volat hodně lidí.
Ellie byla zdrženlivější.
Moc toho neřekla.
Takovým rozhovorům musí čelit všichni pacienti s rakovinou.
U pacientů s mezoteliomem ale takové rozhovory nejsou odlehčeny nadějí nebo jen náznakem šance na přežití.
Nemoc s sebou přináší (a nakonec přinesla i Stephenovi Jay Gouldovi) neradostnou jistotu.
Jak říká Andrew Morgan, „mezoteliom život neohrožuje.“
Těla nabalzamovaných faraonů se balí do azbestového plátna.
Azbestová vlákna se používají ke zpevnění hrnců na vaření a zvyšují odolnost proti žáru.
Plinius Starší popisuje azbest.
Byla vynalezena tkanina, která je nehořlavá.
Viděl jsem z ní vyrobené ubrousky, které zářily v krbech na hostinách
V Itálii se azbest začíná objevovat v komerčním využití, používá se k výrobě papíru (dokonce bankovek) a tkanin.
Velké azbestové doly se otevírají v Kanadě a Jižní Africe, brzy poté pak v Americe, Itálii a Rusku.
Během průmyslové revoluce je to výborná izolační látka v parních motorech a turbínách.
Světová produkce azbestu se zvyšuje na více než 30 000 tun ročně.
Statistici pojišťovny Prudential zjišťují u lidí pracujících s azbestem vyšší úmrtnost a těm jsou potom zamítány životní pojistky.
V Rochdale umírá Nellie Kershawová.
Doktor William Cooke potvrzuje, že částice azbestu v jejích plicích „byly bezpochyby příčinou jejího úmrtí.“
Jedná se o první případ tohoto druhu.
Zaměstnavatelé Kershawové, Turner Bros Asbestos, odmítají odpovědnost.
Nezaplatí žádné vyrovnání.
Během 2. světové války se intenzivně stavějí lodě, práce v loděnicích představuje nejvyšší riziko vystavení azbestu.
Zákaz dovozu modrého azbestu
Odvolací soud potvrzuje první úspěšnou žalobu za újmu na zdraví následkem expozice azbestu v Británii.
Světová produkce azbestu se zvyšuje na více než 4 213 000 tun ročně.
Spojené království dováží 139 000 tun.
Britský Ústav pro zdraví a bezpečnost vyžaduje, aby všichni dodavatelé azbestu měli licenci.
Dovoz a použití modrého a hnědého azbestu jsou v Británii zákonem zakázány.
V Británii je zakázáno použití všech druhů azbestu.
Ve Spojeném království vstupuje v platnost zákon o mezoteliomu.
Je spuštěn 350 milionový kompenzační program.
Azbest je zakázán ve více než 50 zemích, v mnoha částech světa se však bílý azbest nadále používá jako levný stavební materiál.
Světová produkce se drží na dvou milionech tun ročně.
Čína odmítá dát Hongkongu pravomoc zvolit si vedení - demonstranti slibují pomstu
Čínský parlament se navzdory množícím se diskuzím o demokratické reformě v neděli rozhodl neumožnit voličům v Hongkongu nominovat kandidáty do voleb v roce 2017.
Je pravděpodobné, že tento krok vyvolá dlouho slibované protesty v obchodní čtvrti Hongkongu, neboť aktivisté se začali organizovat a chystat jen několik hodin po tomto oznámení.
Čínský lidový kongres v podstatě povoluje komunistickým lídrům vyřadit jakéhokoliv kandidáta, který není loajální k Pekingu.
„Sice nás to nepřekvapilo, ale rozzuřilo nás to,“ řekla zákonodárkyně Emily Lau, předsedkyně Demokratické strany.
To není to, co Peking slíbil.
Lidem v Hongkongu lhali.
A je jasné, že máme co do činění s autoritativním režimem.
Na obranu čínského rozhodnutí řekl náměstek generálního tajemníka Stálého výboru Národního lidového kongresu Li Fei, že umožnit veřejné nominace ve volbách vedení Hongkongu by způsobilo „chaos“.
Od roku 1997, kdy Británie vrátila Číně správu Hongkongu, slibuje Peking, že počínaje rokem 2017 budou moci obyvatelé volit výkonnou moc.
Čínští lídři prezentovali nedělní rozhodnutí jako demokratický průlom, protože Hongkongu umožňuje přímé hlasování, rozhodnutí ale také jasně dává najevo, že čínští vedoucí představitelé drží pevně v rukou proces nominování výboru, který je přísně kontrolován Pekingem.
A podle nové klauzule budou přípustní pouze kandidáti, kteří „milují zemi a Hongkong“.
Rozhodnutí přišlo po letních měsících, které zaznamenaly jedny z největších a nejsledovanějších protestů v Hongkongu za několik let.
Za většinou pro-demokratických protestů v Hongkongu stojí hnutí Okupace Centrálu s láskou a mírem, jehož organizátoři pohrozili uzavřením finanční čtvrti, pokud jim Peking neudělí všeobecné hlasovací právo.
V neděli večer, jen několik hodin po oznámení, se stovky příznivců hnutí Okupace v dešti shromáždily před sídlem vlády Hongkongu.
Na demonstraci organizátoři sdělili, že jejich hnutí vstupuje do nové fáze občanské neposlušnosti a že v nadcházejících týdnech zahájí vlny protestů.
Neposkytli však žádné další detaily, očividně se chtěli vyhnout problémům s úřady.
Ve svém internetovém prohlášení organizátoři řekli, že hnutí „zvážilo okupaci Centrálu jenom jako poslední krok v případě, že se vyčerpají všechny možnosti dialogu a nezbude žádná jiná volba.
Musíme s politováním oznámit, že dnes byly veškeré možnosti dialogu vyčerpány a obsazení Centrálu je nevyhnutelné.
Úřady v Hongkongu se na oznámení Pekingu celé dny připravovaly a v neděli posílily ochranu sídla vlády a rozmístily policisty a barikády.
Podněcování nepokojů je podle mnohých obyvatelů Hongkongu známka toho, že pomalu ztrácí kontrolu nad městem.
Příval lidí z pevniny zvyšuje konkurenci v oblasti výrobků a služeb.
Rostou také obavy, že hodnoty jako demokracie a svoboda slova jsou zvyšujícím se tlakem z Pekingu ohýbány.
Někteří lidé kritizují hnutí Okupace Centrálu a říkají, že jejich demonstrace ohrožují obchod - záchranný člun Hongkongu.
„Protest, o kterém mluví, by mohl způsobit mnohem větší ekonomickou škodu podle toho, kolik lidí se zúčastní a na jak dlouho,“ říká politička Regina Ip, která hnutí dlouhodobě kritizuje.
Nechceme, aby se rozšířily obavy, že Hongkong se dostává mimo kontrolu.
Takové vnímání by mohlo poškodit investice.
Čínská státní média také v posledních dnech přišla se zprávami, které demokratické aktivisty v Hongkongu vykreslují jako podvratné agenty řízené západem.
V létě aktivisté zorganizovali neoficiální referendum o hlasovacích právech, ke kterému přišlo 780 000 účastníků - více než pětina voličů v Hongkongu.
A v červenci se desítky tisíc lidí zúčastnily jedné z největších pro-demokratických demonstrací v historii oblasti.
Předvolební agitka?
Liga v Jihlavě nosí název podle politického hnutí
Malou kopanou hraje v krajském městě Vysočiny přibližně 1 600 amatérských sportovců.
A jejich nejvyšší soutěž se nově jmenuje Společně pro Jihlavu liga.
Název dostala podle jednoho hnutí, které jde do říjnových komunálních voleb.
Desítkou na jeho kandidátce je navíc šéf malé kopané v Jihlavě Jan Mráka.
"Byla valná hromada, kde s tím žádný problém nebyl," uvedl Mráka.
Situací kolem první ligy malé kopané se už zabývali právníci jihlavské radnice a doporučili změnit systém rozdělování dotací.
Malá kopaná získala loni podle webu města okolo milionu korun.
I letos jde o částku ve stovkách tisíc.
Podle právního názoru není postup malé kopané v rozporu se zákonem ani směrnicemi magistrátu.
Situace je ale pro úřad podnětem pro úpravu pravidel přidělování grantů a dotací," uvedl mluvčí magistrátu Radek Tulis.
Čerpat dotace od města a současně vyjádřit jako malá kopaná podporu ve volbách jedné politické straně, to už asi nepůjde.
Na vysočinský "velký" fotbal podobný požadavek od politiků zatím nepřišel.
Že by třeba vznikly ČSSD krajský přebor, ODS divize nebo KDU-ČSL 1.
A třída a podobné soutěže?
Nebyl bych pro.
Naopak bych byl rád, kdyby se na nás obrátili sponzoři z řad firem," poznamenal předseda krajského fotbalového svazu Miroslav Vrzáček.
Šéf malého fotbalu jiné strany a hnutí do názvu ligy nepustí
Podle hráčů malé kopané by si tento sport v Jihlavě zasloužil vlastní areál s šesti hřišti, šatnami a sociálním zařízením.
"Například hřiště Na Stoupách není naše, jsme tam v pronájmu," upozornil Ondřej Lapeš z klubu Starlet Jihlava.
Nejvhodnější lokalitou by byl Český mlýn.
Tam se ale bude stavět například podle mého názoru nesmyslný areál pro skejťáky, kterých je v Jihlavě asi tak padesát," upozornil Mráka.
Primátor Jihlavy Jaroslav Vymazal (ODS) reagoval, že malá kopaná využívá hřiště s umělou trávou v ulicích Rošického a Na Stoupách, která jsou v majetku města.
Chceme budovat taková hřiště, která mají maximální využití.
Chystáme modernizaci či výstavbu sportovišť u škol, která budou v odpoledních hodinách přístupná.
Myslím si, že pro malou kopanou se za poslední roky udělal obrovský pokrok," dodal Vymazal.
Další politické strany v názvech lig se podle Jana Mráky neobjeví.
Máme omezení.
Pokud k nám do partnerství někdo z jednoho oboru vstoupí, tak druhého už tam nedáváme," vysvětlil.
"Politické hnutí v názvu ligy, to považuji minimálně za nešťastný krok," řekl člen radniční komise pro sport Karel Voldán.
"Ať si ale voliči zhodnotí, zda pan Mráka využívá spolek Malá kopaná Jihlava a dotace města pro politické účely, nebo ne," dodal.
Americká tradice proniká do univerzitního života - prváci mohou lítat tryskovým letadlem
Jsme rádi, že na poptávku můžeme odpovědět spuštěním první luxusní cestovní služby pro studenty v Británii.
Za účelem zanechání co nejlepšího dojmu při příjezdu na univerzitu nabízí společnost také možnosti dopravy včetně soukromého tryskáče nebo vozů typu Rolls-Royce Phantom, Aston Martin nebo McLaren P1.
Stewart také prohlásil, že služba má i svou bezpečnostní stránku.
Servis je ideální možností pro studenty, kteří by jinak museli svoje věci vláčet přes celý stát v nebezpečně naloženém autě.
Těšíme se, že s našimi VIF (very important fresher - velmi důležitý prvák) variantami tento rok studentům zajistíme, že na univerzitu dorazí s minimem nervozity a maximem luxusu.
Mluvčí společnosti řekl, že vzhledem k tomu, že se služby teprve spustily, nemají zatím žádné rezervace, ale dodal: „Studenti si začnou dělat rezervace během několika příštích týdnů.“
Společnost také uvedla, že přestože studenti platí roční školné ve výši 9 000 liber, očekává, že služba si na trhu najde své místo.
V porovnání se studenty před deseti, dvaceti, třiceti nebo čtyřiceti lety jsou dnešní studenti jiní, co se týče očekávání a přání - je důležitější než kdy jindy udělat správný první dojem a program VIF je přesně ten vhodný způsob, jak toho docílit.
Národní unie studentů ale službu kritizovala jako nedosažitelnou.
Megan Dunnová, viceprezidentka Unie pro vyšší vzdělávání, poznamenala: „Pro většinu studentů je takový projekt nedosažitelný.
Hodně studentů, kteří tento měsíc nastupují na univerzitu, se musí předtím, než vyhodí tisíce liber za něco tak jednoduchého jako dorazit na kolej, vyrovnat s finanční krizí, protože dostupná finanční podpora v podobě půjček a grantů nedokáže držet krok se stoupajícími náklady na základní potřeby.
Feministky se po událostech ve Fergusonu staví proti rasismu a chování policie
Na začátku měsíce zabil policista ve Fergusonu v Missouri neozbrojeného mladíka.
Přítomní čekající na pohřeb s rukama vzhůru skandují: „Ruce vzhůru, nestřílejte!“
Po dva týdnech protestů ve Fergusonu v Missouri kvůli zastřelení neozbrojeného mladíka Michaela Browna, zaznamenala bloggerka Miriam Zoila Perézová posun v internetových diskuzích bělošských feministek.
Zjistila, že když dojde na prosazování reprodukčních práv a rovnosti příjmů, upřednostňují bělošské feministky pohlaví před rasou.
Se vzrůstajícím napětím na Středozápadě, které přitáhlo pozornost celostátního tisku, si Perézová všimla, že reakce bělošek se ve 100 % soustředí na rasu.
V porovnání s reakcemi černošek brzy po střelbě 9. srpna se osobní články s nadpisy jako „zamyšlení bělošky nad Fergusonem“ nebo „Feminismus není jen o utlačování žen“ objevily relativně pozdě.
Podle Perézové to ale představuje důležitou změnu.
„Myslím, že ve feministickém hnutí není moc lidí, kteří by o rase a výsadách mluvili na takové úrovni,“ prohlásila.
Lidé cítili, že k tomu, co se stalo, se musí vyjádřit.
Pro krizi, které čelíme, je to charakteristické, protože [situace ve Fergusonu] je tak rasově vyhraněná, že na to museli upozornit.
Podle profesorky angličtiny na státní univerzitě v Ohiu Korithy Mitchellové vynesl Ferguson na světlo problémy, kterým Afroameričanky musejí čelit každý den a které v kulturní sféře nejsou vnímány jako „ženské otázky“.
„Můžu na Facebooku zveřejnit vtipné historky ze života se svým partnerem a dostane to 150 liků od lidí z celého světa,“ řekla Mitchellová.
Když napíšu něco o tom, že barevní jsou ve své vlastní zemi v pasti, je to ticho ohlušující.
„Jak je možné, že žena může veřejně mluvit o vztazích, ale ne o bezpečnosti ve veřejném prostoru?“ zeptala se.
Pro černošky jako je Mitchellová, které se zabývaly otázkou rasy, pohlaví a sexuality v americké historii, neexistuje mezi otázkami rasy a pohlaví dichotomie.
Černošky si podle ní nemohly dopřát luxus přehledně si tyto problémy rozdělit: každý den žijí v této smíšené realitě.
Přestože bělošky dnes otázku rasy a pohlaví v mainstreamových feministických kruzích slučují, Angela Hatteryová, profesorka přednášející ženskou otázku a genderová studia na George Mason University, říká, že jejich předchůdkyně dělaly opak.
Mezi lety 1865 a 1890 bylo nejméně 10 000 černochů lynčováno a důvodem bylo téměř ve všech případech znásilnění bělošky,“ řekla Hatteryová.
Ke zdůvodnění lynčování jste potřebovali spolupráci bělošek.
Podle Hatteryové rozkol mezi běloškami a černoškami přišel, když bojovnice za volební právo jako Susan B. Anthonyová prozkoumaly na konci 19. století terén a uvědomily si, že volební právo může mít jenom jedna skupina lidí - ženy nebo černoši.
„Rozhodly se vsadit karty na hlasovací právo pro ženy a na právo pro černochy se zaměřit později,“ vysvětlila Hatteryová.
Když si tohle uvědomíme, získáme důležitý náhled na to, proč barevné ženy běloškám nevěří.
Neodvedly jsme dobrou práci.
Nikdy jsme černoškám nepomohly chránit jejich manžele a děti.
I poté, co ženy v roce 1920 získaly volební právo, trvalo deset let, než se začaly organizovat proti lynčování v Asociaci jižanských žen pro předcházení lynčování.
Skupina vznikla 40 let poté, co si černošky poprvé řekly o pomoc.
Podle Mitchellové vzedmutí reakcí bílých feministek na otázky, které dění ve Fergusonu přineslo - otázka chování policie, rasová diskriminace - odráží dobu, kdy bílé feministky musely „dohánět“ otázky, se kterými se černošky potýkaly generace.
„Nebylo by skvělé, kdyby aktivistky na těchto prostorech [tradičního feminismu] braly právo vychovávat dítě stejně vážně jako braly právo na antikoncepci?“ nadnesla Mitchellová.
Druhá vlna feministek, které udělaly kariéru bojem za reprodukční právo a přístup k antikoncepci, nyní zjišťují, co to znamená.
Významné feministické aktivistky jako Gloria Steinemová vzaly dva týdny po zastřelení Michaela Browna útokem Facebook, kde zveřejnily sloupek Rebeccy Carrollové z Guardianu, která se dožadovala toho, aby bílí Američané razantněji protestovali proti rasismu.
„Doufám, že ženy, které mají různé, ale přesto obdobné důvody pro chápání nebezpečí ve společnosti - a názorů na rasu, které se v průzkumech veřejného mínění výrazně liší - budou usilovat o změnu,“ napsala Steinemová.
Přestože Steinemová zastává intersekcionální feminismus, který zahrnuje otázky rasy i pohlaví, její komentáře na otázku rasy v Americe některé lidi matou.
Odbornice z American Enterprise Institute Christina Sommersová, autorka knihy „Kdo ukradl feminismus?“, řekla pro She The People, že mladí muži ve Spojených státech, především mladí barevní muži, jsou „mnohem zranitelnější než jejich sestry“, ale poznámky Steinemové stran Fergusonu čelí kritice, kterou vyvolala již dříve.
Máme nyní stovky speciálních programů pro dívky a mladé ženy, ale téměř žádné pro chlapce.
Ale když Bílý dům spustil malý program My Brother's Keeper, který měl pomoci zranitelným mladým černochům a Hispáncům, vyvolalo to u mnoha feministek včetně Glorie Steinemové rozzuřené reakce.
Vztah policie k černošské komunitě není jediný problém, který se dostává do popředí zájmu mainstreamového feminismu.
Poté, co americká pohraniční policie zadržela tento rok na jihozápadě země téměř 63 000 mladistvých bez doprovodu, znovu vyvstala otázka reformy imigračním zákonů - tentokrát jako ženská otázka.
Andrea Mercadová, spolupředsedající We Belong Together, organizace mobilizující ženy pro reformu imigračních zákonů, řekla, že aby bylo možné otázku přednést jako pro ženy nezbytnou, jediné, co musela udělat, bylo sdílet příběhy imigrantek.
„Mluví samy za sebe,“ říká Mercadová.
Vzhledem k tomu, že většina pracovních povolení se uděluje mužům, ženy, které s nimi přijdou, se ocitají v pozici, kdy jsou zranitelné, co se týče domácího násilí a zneužívání.
„Tyhle příběhy mají v ženských organizacích ohlas,“ uvedla.
Bydliště prasete v Ipswichi na prodej
Realitní kancelář odstranila obrázek domu na prodej v Suffolku - když ho zveřejnila, odpočívalo na něm v obýváku prase.
Jednopokojový samostatný domek, který je na prodej za 120 000 liber, stojí na soukromé cestě v Ipswichi.
Informační fotografie zahrnovaly obrázek obývacího pokoje, ve kterém odpočívá s hlavou na pohovce prase.
Realitní kancelář Connells uvedla, že prase na fotografii je domácí mazlíček majitelů.
„Fotka se tam ocitla omylem, a proto už byla odstraněna,“ řekl mluvčí kanceláře.
V informacích o nemovitosti popsala realitní kancelář Connells bývalou modlitebnu jako „ojedinělý samostatný jednopokojový domek.“
Přestože kancelář fotku ze svých webových stránek již odstranila, v propagačních materiálech se stále objevuje.
Prodej domu vyvolal zájem na sociálních sítích, kde se někteří ptali, zda je prase zahrnuto v ceně.
Po výhře v loterii má město Harvey na jihozápadě čerstvého milionáře
Hráč loterie v Harvey získá milion.
Probíhá pátrání po novém milionáři na jihovýchodě Perthu, jeden šťastlivec si ze sobotního tažení loterie domů odveze 1,1 milionu dolarů.
Trafiky v Harvey měly při rozdělování štěstí již podruhé během pěti let, naposledy se v listopadu 2009 jednalo o výhru jednoho milionu dolarů.
Štastný výherce se ale teprve musí přihlásit.
Majitel obchodu Steve Forward řekl, že o výhře mluví celé město na jihozápadě Perthu.
Je to hlavní téma a všichni jsou rozrušení.
Mysleli jsme, že podobná výhra je na dotek.
Osm vítězů si v Západní Austrálii minulý měsíc rozdělilo jednu výhru, čímž završilo několik šťastných týdnů.
Minulý víkend se hráč v Canning Vale stal jedním z pěti srpnových milionářů a jen o několik týdnů dříve pár v Belmontu vyhrál neuvěřitelných 7,5 milionu dolarů.
Vítězná dvojice si sázela dvacet let a řekla, že výhra jim umožní procestovat svět a koupit si nový dům.
Milionář z Harvey je 59. jediným výhercem loterie v Západní Austrálii za tento rok, celkem vyhráli 85 milionů dolarů.
Vlaky Deutsche Bahn večer nevyjedou.
Strojvůdci chtějí vyšší mzdy
GDL v tiskovém prohlášení označil protest za varovnou stávku, pro kterou schválně vybral čas mimo dopravní špičku.
Zvoleným časem stávky bere GDL ohled na mnoho lidí, kteří se z víkendu vracejí po železnici až během prvního pracovního dne.
Zároveň myslíme i na lidi dojíždějící za prací během dne," uvedl odborový svaz v pondělí ráno v tiskovém prohlášení k vyhlášení stávky.
"Naše první stávka by měla zasáhnout především nákladní dopravu, méně už cestující," doplnil GDL.
DB zatím oficiální reakci na vyhlášení stávky nezveřejnily.
Není ani jasné, jak se protestní akce dotkne mezinárodních železničních spojení, mimo jiné s Českem.
Odbory požadují zvýšení mezd strojvůdců o pět procent a zkrácení pracovní doby o dvě hodiny týdně.
V současnosti se průměrný plat strojvůdců pohybuje v závislosti na odpracovaných letech mezi 36 tisíci a 46 tisíci eury (998 tisíc a 1,27 milionu korun) ročně.
Strojvůdci u DB pracují 39 hodin týdně.
DB odmítají přistoupit na růst platů při zkrácení pracovní doby.
Zdůrazňují přitom, že se mzdové ohodnocení strojvůdců musí vyvíjet stejně jako u ostatního železničního personálu, u kterého DB se zkracováním pracovního týdne nepočítají.
Hrozilo, že Krestův vůz začne hořet.
Proto na Barum rallye skončil
Co přesně se stalo?
Šlo o vadu materiálu.
Auto bylo úplně nové, takže mě ani nenapadlo, že by se něco takového mohlo stát.
Nešlo výfuk provizorně opravit a pokračovat v pomalejším tempu do servisu, kde by ho mechanici vyměnili?
Kdybychom tam zamířili rovnou, tak ano.
Ale nás ještě čekaly další dvě erzety a to nešlo.
Je v něm vysoká teplota a riziko, že by auto začalo hořet, bylo velké.
To si nemůžu dovolit.
V plném tempu jste zvládl pět rychlostních zkoušek.
Jaký jste z nich měl dojem?
Velmi dobrý.
Cítil jsem se jako zamlada.
Byli jsme rychlí, přitom jsem nejel přes vint.
Všechno bylo způsobené tím, že auto jsme piplali více než půl roku, aby bylo na nějaké úrovni.
Závod ukázal, že se nám to povedlo.
Rozjel jste ho tak, že jste mohl reálně pomýšlet na vítězství.
Sebe i auto jsem připravil tak, že jsme na výhru opravdu měli.
Práce nepřišla vniveč.
Na druhou stranu výsledek, na který jsme mohli pomýšlet, se nedostavil.
Ale to je Barumka.
Technika bohužel řekla ne.
Nebyl jste jediný ze špičky, který předčasně odstoupil z boje o prvenství.
Vypadli z něj i zahraniční favoriti Breen, Abbring či Lappi.
Překvapilo vás, že tolik favoritů odstoupilo?
Ano.
Hlavně pro diváky to byla škoda, protože závod tím předčasně skončil.
Na špici se dlouho pohyboval i Jaromír Tarabus, kterému chystáte vůz.
Jenže doplatil na to, že vylétl z trati a nabral téměř dvouminutové manko.
Jak jste byl s jeho výkonem spokojený?
Je to škoda, protože mohl zopakovat stupně vítězů.
Vždyť zajížděl první druhé časy.
Ale i Mira potvrdil, že auto jsme nachystali dobře.
Jel hodně rychle.
Přesně před rokem jste ohlásil konec kariéry, přesto jste se na startu Barum rally objevil.
Může z vás dobrý pocit z jízdy zase udělat pravidelného účastníka rallyových závodů?
V této chvíli určitě ne.
Loni jsem řekl, že Barumka je můj poslední závod a stejně jsem to nedodržel.
Rozhodl jsem se, že ji pojedu zase.
Byl to můj zdejší devatenáctý start, a když bude za rok zase šance, asi do toho půjdu.
Ale o ničem dalším nepřemýšlím.
Spousta lidí dorazila k trati jen kvůli vám.
Potěšilo vás to?
Do jisté míry jsme startovali právě kvůli nim.
Spousta lidí, známých či neznámých, se neustále ptala, jestli pojedu.
Chtěl jsem jim udělat radost.
Co vás čeká po Barumce?
Tým pokračuje dál.
Příští týden pojedeme do Vyškova, kde bude závodit Robert Adolf.
Doufám, že auto tady moc nepoškodil.
Navíc si na tento závod od nás chce půjčit fabii Honza Sýkora.
S Mirou nás čeká evropský dvojzávod ve Švýcarsku a na Korsice.
K tomu už budeme muset chystat věci na příští rok.
Můžete už něco naznačit?
Ne, nic není rozhodnuto.
Když Korsická rallye patřila do mistrovství světa, pátým místem jste tam dosáhl svého maxima v seriálu.
Neláká vás vyzkoušet si tamní tratě znovu?
Neláká.
Ústní dohoda se zaměstnavatelem může být problém
Bohužel jste si nenechal vystavit od lékaře potvrzení o pracovní neschopnosti, které slouží jako důkaz pro organizaci, že nemůžete ze zdravotních důvodů vykonávat pracovní povinnosti.
Absenci jste navíc ihned neoznámil zaměstnavateli.
Následně sice došlo k dohodě, že dané dny budou evidovány jako dovolená, dohoda ale proběhla pouze ústně.
Přestože zákoník práce neukládá povinnost nechat si písemně potvrdit souhlas zaměstnavatele s čerpáním dovolené, v praxi se tento postup osvědčil.
Pokud dojde pouze k ústní domluvě, nemáte o dohodě potvrzení.
Později může být údajný souhlas s čerpáním dovolené, stejně jako ve Vašem případě, popřen a nepřítomnost v práci posuzována jako dlouhodobá neomluvená absence, tudíž důvod k okamžitému zrušení pracovního poměru dle § 53 Zákoníku práce.
Pro případ soudního sporu o domluvě se zaměstnavatelem Vám tak chybí prokazatelný důkaz.
Pracovní poměr s Vámi ale nebyl zrušen dle § 53, pouze máte dané dny uvedeny v zápočtovém listu jako neomluvenou absenci.
Neomluvená absence v zápočtovém listu nemá stejné důsledky jako § 53 (např. nemožnost pobírat hmotné zabezpečení v nezaměstnanosti), přesto je tím ztížená možnost hledání nového zaměstnání.
Doporučujeme vám znovu navštívit daného lékaře a nechat si písemně potvrdit, že skutečně došlo k úrazu, v důsledku kterého jste byl práce neschopný (nejedná se o tzv. "neschopenku", jde pouze o doklad lékaře).
Při hledání nového zaměstnání můžete zmíněný doklad předložit a situaci vysvětlit.
V praxi je vhodné nepodceňovat jak vystavení písemného lékařského potvrzení o pracovní neschopnosti, tak brzké oznámení zaměstnavateli či vyžádání písemného souhlasu s čerpáním dovolené.
Vyvarujete se tak případných komplikací.
Nehoda Tonyho Stewarta při návratu na trať
Návrat na trať skončil pro Tonyho Stewarta jen kousek za polovinou závodní dráhy Atlanta Motor Speedway.
Stewart podruhé narazil do hrazení poté, co mu v 172. kole praskla pravá přední pneumatika, a závod pro něj skončil.
Stewart dovezl poničené auto do garáže, reportérům se nevyjádřil a odešel.
Šéf jeho týmu Chad Johnston řekl, že tým auta č. 14 je zklamaný, ale bude se nyní soustředit na závod v Richmondu, ve Virginii, který se uskuteční příští víkend.
„Chtěl bych, abychom měli lepší výkon a lepší závěr,“ řekl Johnston.
Pojedeme do Richmondu a budeme doufat, že se nám tam bude dařit víc.
Stewart narazil do hrazení poprvé v nedělním večerním závodě po kolizi s Kylem Buschem, což si vyžádalo opravu pravého boku jeho auta.
„Do dnešního závodu jsme vkládali naděje na dobré zakončení,“ řekl Johnston a dodal: „Prostě to nevyšlo.“
Nedlouho po druhé havárii bylo Stewartovo auto naloženo a tým sbalen a připraven k odjezdu.
Poté, co jeho auto zasáhlo a usmrtilo jiného řidiče na závodě v New Yorku, vynechal Stewart tři závody NASCAR Sprint Cup.
Rozhodl se tento víkend vrátit a k tomu potřeboval vyhrát buď závod v Atlantě nebo následující závod v Richmondu, aby dohnal místo v tabulce.
K závodění se vrátil během vyšetřování tragické nehody, při které zemřel dvacetiletý Kevin Ward Jr., který Stewartovi vjel během závodu do cesty.
Úřady řekly, že prošetřování příčiny nehody potrvá minimálně další dva týdny.
Zatím se nerozhodlo o tom, zda bude Stewart čelit nějakým obviněním.
Trojnásobný šampion se před závodem dočkal vřelého povzbuzování.
Stewart začal na 12. místě, na začátku závodu se propracoval na 10. a potom dokonce na 4.
Poté, na začátku 122. kola, se Buschovo auto č.
18 dostalo mimo kontrolu, vyjelo ze druhé zatáčky a narazilo do Stewartova, čímž oba vozy poslalo do hrazení.
Stewart pokračoval, ale stáhl se na 21. místo.
Praha vybrala nové správce stanovišť taxi, vydělá 12,3 milionu
Praha dokončila výběrová řízení na nové správce stanovišť taxislužby.
Za 103 parkovacích stání získá ročně zhruba 12,3 milionu korun.
Donedávna přitom za stejná místa pro řidiče vozů taxi ročně vybírala 150 tisíc korun.
Informoval o tom radní Lukáš Manhart (TOP 09).
Dříve město při výběru správců používalo losování.
Vítěz pak získal pronájem za paušální částku 1000 korun na rok.
Pravidla se ale změnila.
V současnosti rozhoduje výše nabídky.
"Rok od vypovězení původních nájemních smluv a zahájení výběrových řízení se prokázalo, že nový systém pronájmů je pro Prahu daleko výhodnější a celkově spravedlivější," tvrdí radní.
Nejdražší flek je Na Perštýně
Nejvyšší cenu nabídli zájemci o stanoviště v ulici Na Perštýně.
Ročně zaplatí 2,1 milionu korun.
Přibližně 1,5 milionu korun noví správci zaplatili za místa před Obecním domem nebo na Václavském náměstí.
Nová pravidla pronájmů stanovišť taxislužby radní přijali na podzim roku 2012 a v létě loňského roku vypověděli původní nájemní smlouvy.
Výběrová řízení se konala ve čtyřech vlnách a nového správce našlo 29 stanovišť.
Už podruhé jsme letos museli čistit studnu.
Celou jsme ji pokaždé vypustili, čímž vzniknul prakticky druhý rybník kolem chaty.
Pak jsme tam nalili Savo.
Neuvěřitelný puch!
Naše studna ve sklepě skýtala vždy dostatek nádherné voňavé vody.
A to nebyla kdovíjak odborně udělaná, děda ji vydlabal svépomocí.
Už dávno.
Byla jen tak na tři skruže a celkově svérázná, jako ostatně všechno na chatě, ale jak říkám.
Voda byla skvělá.
Až do letoška.
Když jsme zahajovali sezónu, samozřejmě jsme vodu vyčerpali.
Když tam stála řadu měsíců, zasloužila si to.
Jenže i pak se nám zdálo, že ta voda nějak nevoní.
Napadlo nás, jestli tam něco nespadlo.
V místě, kde procházelo čerpadlo, to při troše smůly bylo možné, tam deska docela nedoléhala, tak byl otvor utěsněný kusem cihly.
Naše inspekce potvrdila, že se cihlou hýbalo.
Jinak ve vodě nebylo nic vidět, a to jsme ji prosvítili až na dno.
Takže jsme ji opět vypustili a přečistili.
Samozřejmě jsme vylepšili improvizované těsnění kolem trubky čerpadla.
Ve sklepě jsme si všimli ale divných věcí.
Na zemi ležel ulepený balíček s nějakými kostičkami.
Tak to aspoň vypadalo.
A o kus dál další.
Teď to vypadalo jako oslintaná myš.
U stropu, v místech, kde jsou průduchy, dědův vynález, byly zbytky ryby!
A těžce jeté!
Náš sklep je taky svérázný.
Někdo by řekl, že děda zkrátka podhrabal chatu.
A nebyl by tak daleko od pravdy.
Stěny i podlaha je jenom udusaný písek, pouze strop je podbitý.
Dávají se tam hlavně lodě.
A kola.
A lehátka na pláž.
Vrata se širokými mezerami byla většinou otevřená, jak tam v jednom kuse někdo chodil.
U stropu několik již zmíněných průduchů.
Bez sítě, takže tam běžně zalétávají ptáci a na trámech si staví hnízda.
O myších je zbytečné se zmiňovat.
Děda chtěl, aby to luftovalo, a to ono zas jo.
Teď ovšem ani luft nepomohl.
Celý sklep páchnul.
Vyčistili jsme tedy i celý sklep.
Zvlášť ta ryba na trámu byla výživná!
Vyhodili jsme i věci, co byly kolem: prkna, heraklitovou desku, a tak.
Naše chata na dálku vítala kolemjdoucí dezinfekčním odérem.
Přemýšleli jsme, kdo nám tam mohl ty nechutné zbytky natahat?
Nejbližší kočka bydlí dva kilometry odsud ve vsi.
Těžko by k nám chodila svačit.
Dědu napadl jeden soused, který není úplně v pořádku.
Jestli on ten Franta nám ty nechutnosti tam nešoupnul průduchem?
Je tu prakticky po celý rok, blbý nápady, to on má.
Rozhodli jsme se sklep i studnu hlídat a pravidelně kontrolovat.
Po několika dnech bylo všechno v pořádku.
Vodu jsme zase začali používat, zatím jenom na mytí a praní, než budou hotové testy, ale už to bylo dobré.
Tahat vodu z lesní studánky není nic, co bych chtěl dělat nějak dlouho.
Jednou jsme zaslechli strašlivý úzkostný štěkot naší feny.
Máma se podívala z balkónu a viděla v trávě vedle verandy dlouhou silnou černou hadici.
Réza nad ní poskakovala a pištěla jak blázen.
Máma jí vynadala, protože myslela, že Réza vyhrabala odpadovou hadici z umyvadla.
Najednou se ale ta hadice částečně smotala do klubka a částečně se napřímila.
Na balkón dolehlo syčení.
Réza dostala hysterický záchvat.
Seběhli jsme dolů.
Užovka, dlouhá hodně přes metr a tlustá jak býkovec, se chystala spolknout obrovskou ropuchu a Réza jí v tom bránila.
Nebylo jasné, jestli chtěla ropuchu zachránit nebo jestli ji chtěla sežrat sama, ale to bylo nepodstatné.
Když užovka uviděla přesilu v podobě celé naší rodiny, asi si řekla, ať si ji teda sežereme, když jsme takoví hladi, a elegantně se protáhla průduchem do sklepa.
Letěli jsme za ní.
Jako blesk skočila za studnu.
Jen tak mimochodem jsme zaznamenali na její desce další páchnoucí balíček.
Podle vůně asi rybka.
Předevčírem tam nebyla!
Naše nové zabezpečení kolem čerpadla bylo trochu šejdrem.
A to jsme sklep zamykali i přes den.
Že by...
Vyšli jsme ven a tam jsme každý zalehl k jednomu průduchu.
Nečekali jsme dlouho.
Za studní to zašramotilo.
Nejdřív se objevila plochá hlavička se žlutými měsíčky na krku.
Pak se vyhoupla na studnu celá užovka.
Omotala se kolem čerpadla a začala se dobývat dovnitř.
Vyhozený zaměstnanec se mstil, nakoupil na firmu notebooky a prodal je
Zhrzený zaměstnanec po propuštění nakoupil na firmu počítače a pak je prodal.
Získané peníze stihl ještě před zadržením policií utratit.
Během krátké doby muž nakoupil ve dvanácti případech celkem šestnáct počítačů za více než dvě stě tisíc korun.
"Notebooky po převzetí odvážel do Olomouce, kde je prodával po bazarech," uvedl vrchní komisař šumperské policie Rostislav Brückner.
Motivem podvodů byla msta zaměstnavateli za propuštění a také zisk peněz.
"Při výslechu nám tvrdil, že peníze použil na splátky úvěrů," sdělil Brückner.
Policie rovněž zjistila, že podvodník je patologický hráč, který se opakovaně léčil na psychiatrii.
Peníze tak mohly skončit také ve výherních přístrojích nebo ve videoloterijních terminálech.
"Faktem je, že jsme u něj žádné peníze nenašli," řekl komisař.
Podvodníkovi, který byl už jednou trestán za krádeže, teď hrozí pobyt ve vězení v délce jednoho roku až pěti let.
Policisté zatím nesdělili, zda hrozí trest také bazarům, které notebooky pod cenou koupily a dál je prodávaly.
"Je pravda, že přebíraly úplně nové zboží, což je minimálně podezřelé," konstatoval komisař.
Žádný z majitelů bazaru však zatím nebyl obviněn.
Pojď, ještě kousek, to zvládneš aneb jak jsem si užil We Run Prague
Letos si na nás pořadatelé připravili několik změn.
Tou největší byla změna trasy, která přivedla cíl na náplavku, místo aby vedla zpět do Žlutých lázní.
Na závod jsem se těšil spolu se zbytkem Rungo.cz týmu, chystal jsem se ho ale prožít tak trochu z druhé strany.
S celým týmem jsme se rozhodli osobně zdravit naše čtenáře na stánku, kde jsme se společně fotili a natáčeli videa.
Abych svůj pohled z druhé strany dotáhl k dokonalosti, přijal jsem roli osobního vodiče.
Spolu s kamarádkou Káťou jsme se těsně před startem poslušně zařadili na konec koridoru 60 až 70 minut.
Pozdravili jsme se s kamarády, kteří kolem nás procházeli do sektoru pro rychlejší běžce.
Už nezbývalo moc času.
Pár poskoků na rozehřátí, zapnout sporttestery, odpočítávání a start!
Výkřiky jásotu, ale místo rychlého startu následovalo cupitání ke startovní čáře.
Po pěti minutách docházíme k bráně, zapínám měření a rozbíháme se tempem na hodinu deset.
Proplétáme se žlutým hadem běžců, kteří podobně jako Káťa běží svůj první závod.
Zatím vypadají všichni svěže, pomalu klesající slunce na obloze dodává výhledu na Vyšehrad skoro až kýčovitý nádech.
Pulzující masa táhnoucí se po nábřeží vypadá, jako by tady běžela celá Praha.
Na nábřeží mezi Vyšehradem a Národním divadlem se tradičně začíná projevovat, kdo má kolik sil.
Lehký kopeček na Palackého náměstí nutí mnoho běžců zpomalit nebo přejít do chůze.
Těsně před přeběhem do Divadelní vidím policejní doprovod a hned za ním letí Vítek Pavlišta neuvěřitelným tempem do cíle.
Slyším obdivné ufuněné vzdychání ostatních běžců.
Přesouvám se k okraji trati, povzbuzuji ho, chystá si se mnou plácnout, ale těsně před tím se mi podvrtne noha a naše ruce se těsně minou.
Seběh Divadelní ulicí dává šanci na krátký odpočinek a rozdýchání.
Je potřeba, před námi jsou místa, na kterých mi výhledy vyrazí dech.
Otočka na Mánesově mostě ukazuje Prahu v celé kráse zapadajícího slunce.
Nedýchám a nohy mě nesou skoro samy.
Za první občerstvovačkou nastává chvíle pravdy.
Při přeběhu silnice Káťa škobrtne o obrubník a předvádí skok plavmo.
Dívám se, jestli nepotřebuje pomoc, a spouštím sérii povzbuzujících slov, aby neměla čas myslet na bolest.
Zvedá se a pokračujeme Kozí uličkou, je to jedno z nejužších míst trati, v této fázi závodu tu už sice není takový nával, přesto je ale potřeba dobře sledovat okolí.
Ještě netuším, že pojem nejužší místo získá svůj pravý význam později.
Za Prašnou bránou nás freneticky povzbuzují turisti i kamarádí ostatních běžců.
Snažím se tlesknout si s každým, kdo nabídne ruku, a radím to i Kátě, protože deset tlesknutí s fanoušky je jako půlka energetické tyčinky.
Fakt to funguje, opět zrychlujeme a byť jsme se dost výrazně propadli, teď začala stíhací jízda.
Předbíháme desítky běžců, když míjím někoho obzvláště unaveného, snažím se ho povzbudit pár slovy: "Pojď, ještě kousek, to zvládneš!"
Za poslední občerstvovačkou už nás nikdo nepředbíhá, zrychlujeme.
Zatím jsme běželi na hodinu a čtvrt, přidáváme, není na co čekat.
Tři kilometry do cíle budou bolet, ale je potřeba opravdu máknout.
Slunce už pomalu zapadlo a končící den symbolicky pomalu ukončuje závod.
Poslední výběh na most, otočka a už jen rovinka do cíle.
Tempo, kterým běžíme, mě udivuje, kde se to v tom děvčeti bere?
"Pojď, jdeme pod hodinu třináct, makáme!" volám.
Zkoušíme to, sprintujeme a je tady cíl.
Hodina třináct a šest sekund.
No, co se dá dělat.
Trenér zadal limit hodinu dvacet.
Takže sedm minut pod plán.
Což je super výsledek.
Těsně za cílem se Kátě podlamují nohy, pomáhám jí k zábradlí, kde chvíli odpočívá.
Je na ní vidět vyčerpání, ale také štěstí z dobře odvedeného výkonu.
Po chvíli ji pomalu odvádím ven z prostoru cíle.
Euforie nám nedává myslet na tlačenici v průchodech k šatnám.
Tady je vidět, že Kozí ulička nebyla tím nejužším místem.
Tím je až tady za cílem náplavka, která je pod náporem téměř deseti tisíc běžců nacpaná k prasknutí.
Pokud někdo nemá rád davy, není to místo pro něj.
I já po chvíli ztrácím hlavu a přemýšlím, jestli ty nádherné výhledy a oproti minulým letům zajímavější trasa stála za to, co se děje v cíli.
Z vlastní zkušenosti vím, že pořádání závodu není žádná legrace.
Pokud se k tomu přidá deset tisíc lidí, bohatý doprovodný program a uzavření celého centra Prahy pro veškerou dopravu, je z toho obrovská výzva.
Letošní změna trasy ukázala běžcům mnoho zajímavých míst, jenže přinesla také několik opravdu nepříjemných překvapení.
Výborná atmosféra rozpumpovaná ve Žlutých lázních se přenesla mezi běžce i v samotném závodu.
Organizátoři kolem trati i náhodní diváci ji stupňovali na každém metru trati.
Při městském běhu historickým centrem se bohužel musí počítat s překážkami, které nelze odstranit, ale cíl masového závodu v místě, které je na jedné straně ohraničeno zdí a na druhé řekou, nepovažuji za nejlepší řešení.
Pokud si řeknu, že závod skončil proběhnutím cílem, hodnotím ho jako velmi povedený.
Za cílem jsem měl trochu strach o zdraví zúčastněných, ale nakonec vše dobře dopadlo.
Napište nám do diskuze, jestli se i vám trasa líbila a co říkáte na situaci v cíli.
Vězeňští dozorci v Bulharsku organizují protesty
Stovky zaměstnanců vězeňské služby v celém Bulharsku se účastnily celonárodního protestního shromáždění před Ministerstvem spravedlnosti v hlavním městě Sofii.
Na pokojné demonstraci zopakovali svůj požadavek na znovuzavedení původních pracovních podmínek, které se v nedávné době změnily.
Na seznamu požadavků, které mají být projednány s prozatímním ministrem spravedlnosti Hristo Ivanovem, jsou i vyšší platy.
Dozorci měsíc symbolicky protestovali proti nové pracovní době a požadovali návrat k původním dvaceti čtyřhodinovým směnám.
Přestože se odbory vězeňských dozorců a představitelé Ministerstva spravedlnosti setkali, nedohodli se, informovalo Bulharské státní rádio (BNR).
„Jednání stále probíhají,“ řekl BNR vedoucí Generálního ředitelství vězeňské služby Rosen Zhelyazkov.
Očekává se, že k protestům zaměstnanců vězeňské služby se připojí také členové Federace odborových organizací zaměstnanců na ministerstvu vnitra.
Proč může mít vesmír více rozměrů a my je nevidíme
Fyzikové obvykle bestsellery nepíší, ale Brianu Greenovi z Kolumbijské univerzity se v roce 1999 podařila trefa do černého.
Jeho kniha Elegantní vesmír se stala pro laiky nejpřístupnější cestou, jak proniknout k houštině problémů, kterou se dnes zabývá řada teoretických fyziků - snaze sjednotit dvě skvěle fungující, ale vzájemně nekompatibilní objevy 20. století: kvantovou teorii a teorii obecné relativity.
Jednou z příčin úspěchu Elegantního vesmíru nepochybně je, že v případě hledání sjednocené fyzikální teorie nejde o nudný příběh.
Fyzikové základní problém mezi dvěma klíčovými teoriemi (vždyť v tuto chvíli je náš vesmír de facto rozdělený na dva světy s odlišnými zákony) řešili a řeší tak nápaditě, že si to stojí za převyprávění i laikům.
Greene si se složitým materiálem navíc poradil natolik svěže a poutavě, že mu nelze vyčítat, kolik zajímavého do své knihy nezahrnul.
Navíc svou "chybu" z větší části napravil v dalších dvou knihách: Struktura vesmíru a Skrytá realita.
Zřejmě ani autor by nic nenamítal proti tomu, kdyby jeho kniha zastarávala rychleji, ale faktem je, že i po 15 letech Elegantní vesmír poskytuje stále téměř vše podstatné, co by informovaný laik s ambicí porozumět světu měl vědět o této důležité části teoretické fyziky.
Je poměrně pravděpodobné, že v příštích letech bude v této oblasti přece jen o něco živěji (třeba kvůli tomu, že urychlovač LHC pojede konečně na "plný plyn"), a tak je dobrá chvíle vstoupit do Greenem nenásilně otevřených dveří světa moderních fyziky.
Kolik rozměrů může mít náš vesmír?
Nápad, že náš vesmír má možná více než tři prostorové rozměry, jistě může znít pošetile, fantasticky, podivně či mysticky.
Přesto je konkrétní a zcela přijatelný.
Abychom to pochopili, odvraťme na chvíli svůj zrak od vesmíru jako celku k něčemu přízemnějšímu, konkrétně k dlouhé a tenké zahradní hadici na zalévání.
Představte si, že stometrovou zahradní hadici natáhnete z jedné strany kaňonu na druhou a celou scenerii sledujete z půlkilometrové vzdálenosti (jako na obrázku a na následující stránce).
Z takové vzdálenosti snadno zaznamenáte dlouhou ve vodorovném směru nataženou hadici, ale pokud právě netrpíte bystrozrakostí, tloušťku hadice rozeznáte stěží.
Vzhledem ke své velké vzdálenosti od hadice byste si pomysleli, že mravenec donucený žít na hadici má jen jeden rozměr, v němž se může procházet: levo-pravý rozměr podél hadice.
Když se vás někdo zeptá, kde byl mravenec v daný okamžik, odpovíte mu jen jedním údajem: vzdáleností mravence od levého (či pravého) konce hadice.
Tím vším chceme říct jen to, že z půlkilometrové vzdálenosti vypadá dlouhý kus hadice jako jednorozměrný objekt.
Ve skutečném světě hadice tloušťku má.
Pokud vše zvětšíme, spatříme náhle druhý rozměr - ve tvaru kružnice ovíjející hadici.
V takto zvětšeném pohledu je zřejmé, že se mravenec ve skutečnosti může pohybovat ve dvou nezávislých rozměrech: v už dobře známém levo-pravém rozměru po délce hadice, ale také v "rozměru ve/proti směru pohybu hodinových ručiček", tedy kolem kruhovéhoprůřezu hadice.
Začínáte chápat, že k určení polohy malého mravenečka musíte zadat dvě čísla: jak daleko je od konce hadice a kde je na kružnici ovíjející hadici.
To odráží fakt, že povrch hadice je dvojrozměrný (pozn. Experti postřehnou, že tato kapitola se soustřeďuje čistě na poruchovou teorii strun.
Neporuchové aspekty probírá 12. a 13. kapitola.).
Povrch hadice je dvojrozměrný: jedna dlouhá podélná dimenze je znázorněna přímou šipkou, dimenze ve směru obvodu, označená kruhovou šipkou, je krátká a svinutá.
Mezi těmito dvěma rozměry je nicméně jasný rozdíl.
Rozměr podél hadice je dlouhý a snadno viditelný.
Rozměr ovíjející obvod hadice je krátký, "svinutý" a hůře znatelný.
Abychom si existenci kruhového rozměru uvědomili, museli jsme hadici zkoumat s výrazně lepším rozlišením.
Zmíněný příklad ilustruje důležitou vlastnost prostorových dimenzí.
To, že se rozdělují do dvou skupin.
Mohou být buď velké, rozlehlé, a proto přímo patrné, nebo naopak malé, svinuté a mnohem hůře pozorovatelné.
Samozřejmě že v uvedeném případě jsme se zrovna nepředřeli, abychom "svinutou" dimenzi ovíjející tloušťku hadice odhalili.
Stačilo si vzít na pomoc dalekohled.
Kdyby ale hadice byla tenčí - jako vlas nebo kapilára -, svinutou dimenzi bychom odhalili jen s velkým úsilím.
Kaluza zaslal v roce 1919 Einsteinovi svůj článek, v němž vyrukoval s ohromující myšlenkou, že by prostorová geometrie vesmíru mohla mít více než tři nám všem známé rozměry.
Svoje radikální tvrzení Kaluza odůvodňoval tím, že dodatečná dimenze poskytuje elegantní a přesvědčivý rámec, v němž lze Einsteinovu obecnou relativitu a Maxwellovu elektromagnetickou teorii vetkat do jediné, sjednocené pojmové struktury.
Okamžitě se vnucuje otázka, jak jde tento Kaluzův postřeh dohromady s očividnou skutečností, že vidíme právě tři rozměry prostoru.
Odpověď, kterou Kaluza tiše předpokládal mezi řádky a kterou jasně vyslovil a upřesnil švédský matematik Oskar Klein v roce 1926, stojí a padá s tvrzením, že prostorová geometrie našeho vesmíru může mít jak velké, tak i svinuté rozměry.
To znamená, že stejně jako dimenze ve směru délky hadice má i náš vesmír velké, rozlehlé a lehce viditelné tři dimenze, jejichž existenci si každým okamžikem uvědomujeme.
Ale analogicky s kruhovým obvodem zahradní hadice může mít vesmír i dodatečné dimenze, pevně svinuté do prostoru tak nepatrného, že doposud zůstaly skryty i před našimi nejdokonalejšími experimentálními aparaturami.
Abychom získali jasnější představu o podstatě Kaluzova pozoruhodného návrhu, zůstaňme ještě chvilku u hadice.
Představte si, že na obvod hadice nakreslíme černou barvou poměrně hustou řadu kružnic.
Zdálky vypadá hadice stále jako tenká jednorozměrná čára.
S dalekohledem teď díky kresbě odhalíme svinutou dimenzi ještě snáze, uvidíme totiž motiv z obrázku 2.
Zřetelně vidíme, že povrch hadice je dvojrozměrný, s jednou dimenzí velkou a téměř neomezenou a s druhou krátkou a kruhovou.
Kaluza a Klein přišli s myšlenkou, že náš vesmír má podobnou strukturu, ale kromě jedné malé kruhové dimenze má tři velké prostorové dimenze, dohromady tedy čtyřiprostorovédimenze.
Je obtížné nakreslit objekt s příliš mnoha rozměry.
Abychom své představivosti trochu pomohli, všimněme si ilustrace na obr.3; ukazuje dvě velké dimenze a jednu malou kruhovou dimenzi.
Na obrázku zvětšujeme pohled na geometrii prostoru podobně, jako jsme zvětšovali povrch hadice.
Každá následující úroveň, představuje obrovské zvětšení geometrie prostoru z úrovně předchozí.
Náš vesmír může mít dodatečné dimenze (vidíme je na čtvrté úrovni zvětšení), pokud jsou svinuty do dostatečně malého prostoru; tím si vysvětlujeme, že jsme je dosud přímo nepozorovali.
Čtvercová síť znázorňuje běžně známé "velké" dimenze, zatímco kružnice novou, malinkou a svinutou dimenzi.
Právě jako smyčky nití v hustě utkaném koberci, i tyto kružnice existují v každém místě obvyklých rozměrů - jen jsme je kvůli názornosti zakreslili pouze do průsečíků ve čtvercové síti.
Pozadí obrázku 4 znázorňuje běžně známou strukturu prostoru - obyčejný svět kolem nás - v takových běžných měřítkách, jako jsou metry,znázorněných stranou malého čtverečku ve čtvercové síti.
Na každém následujícím obrázku se zaměříme na malou oblast obrázku předcházejícího; zvětšíme ji, aby se stala viditelnou.
Zpočátku se nic zvláštního neděje, jak vidíme na několika prvních úrovních zvětšení.
Když však postoupíme na své cestě za mikroskopickými vlastnostmi geometrie prostoru dále - na čtvrtou úroveň zvětšení v obrázku 3 -, spatříme náhle novou, do tvaru kružnice svinutou dimenzi, podobnou smyčkám niti v hustě tkaném kusu koberce.
Kaluza a Klein přišli s myšlenkou, že dodatečný kruhový rozměr existuje na každém místě ve směru velkých dimenzí podobně, jako má i hadice kruhový obvod v každém bodě své délky.
V zájmu názornosti jsme kruhový rozměr zakreslili jen v některých, pravidelně rozmístěných bodech.
Obrázek 4 Kaluzovu a Kleinovu představu o mikroskopické struktuře geometrie prostoru shrnuje.
Podobnost s hadicí je zřejmá, třebaže zaznamenáváme i důležité rozdíly.
Zaprvé, vesmír má tři velké, daleko se rozléhající prostorové rozměry (z nichž jsme nakreslili jen dva), kdežto hadice má velký rozměr jen jeden.
Ještě důležitější rozdíl tkví v tom, že teď mluvíme o prostorové geometrii vesmíru samotného, nikoli jen o nějakém předmětu uvnitř vesmíru, třeba naší hadici.
Základní myšlenka je ale stejná.
Pokud je dodatečná kruhově svinutá dimenze extrémně miniaturní, rozpoznat ji je - stejně jako kruhový obvod hadice - mnohem těžší než pozorovat zjevné, velké a rozlehlé rozměry.
Je-li velikost dodatečné dimenze dostatečně malá, odhalit ji bude ve skutečnosti i nad síly našich nejmodernějších nástrojů na zvětšování.
Nejdůležitější ale je, že dodatečná dimenze není pouhým oblým hrbolkem uvnitř běžných rozměrů, jak dvojrozměrná ilustrace mylně naznačuje.
Kruhová dimenze je novým rozměrem, který existuje v každém bodě tří běžných rozlehlých rozměrů.
Je to rozměr na zbylých třech dimenzích nezávislý stejně, jako jsou rozměry shora-dolů, zleva-vpravo a zepředu-dozadu nezávislé (a kolmé) navzájem.
Dostatečně malý mraveneček by se mohl pohybovat ve všech čtyřech dimenzích a na určení jeho pozice bychom potřebovali čtyři údaje, kromě tří obvyklých ještě pozici v kruhové dimenzi; počítáme-li i čas, pak údajů pět, v každém případě o jeden více, než bychom normálně očekávali.
Zaujalo Vás?
Knihu Elegantní vesmír Briana Greeena můžete zakoupit zde na knihy.idnes.cz.
Cena za e-knihu je 149,- Kč.
K našemu překvapení tedy zjišťujeme, že byť jsme si vědomi existence jen tří rozměrů prostoru, ukazuje Kaluzovo a Kleinovo uvažování, že tím není vyloučena existence dodatečných svinutých rozměrů, jsou-li dostatečně malé.
Vesmír může mít klidně více rozměrů, než kolik jich můžeme spatřit pouhým okem.
Jak malé by měly být?
Nejmodernější technické vybavení dokáže rozpoznat struktury velké miliardtinu miliardtiny metru.
Menší svinuté dimenze sotva můžeme pozorovat.
V roce 1926 zkombinoval Klein původní Kaluzův nápad s několika myšlenkami z právě se rodící kvantové mechaniky.
Jeho výpočty naznačily, že dodatečná kruhová dimenze by mohla mít velikost přibližně jedné Planckovy délky, tedy velikosti daleko za rozlišovací schopností dnešních přístrojů.
Od té doby fyzici nazývají možnost dodatečných drobných prostorových rozměrů Kaluzovou-Kleinovou teorií.
Wohnout Honza Homola radí, jak cvičit na elektrickou kytaru: 5. díl
Celá podstata "dvanáctky" spočívá v dvanáctitaktové harmonické formě, kterou můžete libovolně opakovat.
Kdo tápe v hudební teorii, najde její princip podrobně vysvětlený zde.
Jan Homola neboli Honza Homolka Tobolka (1976)
Vzděláním loutkař a loutkovodič, jehož facebookový profil lze sledovat zde, se od maturity před dvaceti lety živí jako grafik.
Je kytaristou kapely Wohnout, ze které se údajně bohužel nedá odejít.
Kytaristou je po otci, stejně jako bratr Matěj, lídr Wohnoutů.
S trénováním začněte na jedné struně.
"Rytmický model je na jen vás, vymyslet si můžete cokoliv, stačí ho pak aplikovat na harmonický model dvanáctky," radí Honza.
Když přidáte další strunu, můžete figuru zase obměnit.
Stačí si poslechnout a sledovat Honzu, co se dá s dvanáctkovou harmonií na dvou strunách vymýšlet a jak pěkně už to začíná znít.
Přiberete-li třetí strunu, už můžete koketovat s melodií nějaké písničky.
Až konečně přidáte čtvrtou, pozor na změnu ladění, upozorňuje Honza ve videu.
Příště se Honza vrátí k pentatonice a zkusíte si ji dát dohromady právě s dvanáctkou.
Tak ji poctivě cvičte.
Jak nejlépe, to se dočtete v rozhovoru s Janem Homolou u první lekce jeho školy hry na elektrickou kytaru zde.
Další gól bez čekání?
Na velké slavení to není, uznává hradecký Dvořák
Bod bereme a jsme za něj rádi.
První poločas jsme měli víc šancí my, druhý domácí," vypravoval útočník, jenž tentokrát skóroval z pokutového kopu.
Nebyl jste při jeho zahrávání nervózní, přece jen jej doprovázel ohromný pískot?
Nějak zvlášť jsem to nevnímal, i když na druhou branku, kde jsou domácí fanoušci, by to asi bylo horší.
Penaltou jste po půlhodině vyrovnal, ale vy jste gól také z penalty dostali už po necelých čtyřech minutách.
Co se stalo?
Zaspali jsme začátek, byli jsme pasivní, vznikl z toho roh a po něm pak penalta.
Po ní jste se zvedli a první poločas jste byli lepším týmem, který měl víc šancí.
Proč se to po přestávce změnilo?
Těžko říct.
Souhlasím s tím, že jsme po inkasovaném gólu hráli až do přestávky dobře.
V kabině jsme si říkali, že chceme i po ní udržet tempo hry, ale nedokázali jsme to.
Abych pravdu řekl, ani si nedokážu vysvětlit proč.
Je ale asi také pravda, že si domácí o přestávce něco ke své hře řekli, asi s ní nebyli moc spokojení.
Na hřišti soupeře jste teprve poprvé bodovali, zatímco doma jste třeba ještě nedostali ani gól.
Proč je to takový rozdíl?
Neřekl bych, že je to takový rozdíl, spíš záleží na nás, jak se s tím popereme.
V Brně jsme dobře začali, ale pak to bylo od nás špatné, Plzeň, to je jiná kategorie.
Čtyři zápasy jste čekali na gól, neměli jste strach, že to po minulém utkání může být podobné?
To snad ani ne, ale pochopitelně jsme rádi, že od minulého zápasu nemusíme řeči o čekání na gól poslouchat.
Teď jsme bez čekání přidali další, ale stále jsou jen tři v šesti zápasech, což ještě na velké slavení není.
Island - láva přitéká z kilometry vzdáleného kráteru.
Láva vyletující na povrch v oblasti Holuhraun nedaleko ledovce Vatnajökull, přitéká podzemním tunelem z kilometry vzdáleného kráteru.
Ten se nachází pod ledovcem, stejně tak část zmiňovaného podzemního lávového tunelu.
Tato skutečnost nyní vědce znepokojuje nejvíc...
Situace prozatím zůstává neměnná.
Od včerejšího rána (31.8.
2014) stále vyletuje z pukliny přibližně stejné množství lávy.
Oproti původním odhadům je však její množství nižší, ne 1000 m3, ale "pouze" 300-400 m3.
Oproti předchozí erupci z 29.8.
2014 je až 50x větší.
Vědci se však obávají, že by se lávový tunel mohl otevřít i v místech, kde se nachází pod ledem.
Pokud by se tak stalo, navíc s podobnou intenzitou, jakou předvádí současná erupce, znamenalo by to obrovské záplavy, a to jak na řece Jökulsá á Fjöllum, tak na dalších řekách.
V okolí erupce je cítit silný zápach síry, z trhliny stoupají oblaka páry a plynů.
Rozhodně se nejedná o erupci vhodnou pro turistický ruch, jako tomu bylo v případě erupce u Fimmvörðuháls v roce 2010.
Tohle je mnohem větší a také je tu mnohem víc plynů," říká vulkanolog Ármann Höskuldsson.
Počasí se však od včerejška značně zlepšilo, v ranních hodinách panovalo v oblasti téměř bezvětří.
Stopy po písečné bouři byly smyty deštěm.
Vědci mohou pokračovat ve své práci.
Pro letecký provoz platí oranžový stupeň (druhý nejvyšší) pro Bárðarbungu a žlutý (třetí) pro Askju.
Nebe nad Chebem patřilo odvážné Lady Peggy.
Prošla se po křídlech
Letecký den v Chebu.
Na stroji Boeing Stearman PT-17 se představila letecká akrobatka Peggy Walentinová, která za letu vylezla z kokpitu ke hrazdě na horním křídle dvouplošníku a také mezi křídla.
Tam je odkázána pouze na sílu svalů.
Letecký den v Chebu se letos konal už popáté a pořadatelům se opět podařilo připravit několik zajímavých leteckých kousků.
Premiéru si na nejstarším českém letišti odbyla nejen "chůze po křídlech" v podání německé akrobatky Peggy Walentinové, ale také legendární stíhačka P-51 D Mustang nebo letoun Beechcraft 18.
Ten na sebe strhl pozornost svým zářivým potahem.
Akrobacie zvaná Wingwalking má původ v USA.
Po 1. světové válce se tak snažilo prosadit mnoho bývalých válečných pilotů.
Jenže kvůli velkému počtu smrtelných úrazů byl zakázán.
Dnes se ale pomalu vrací do programu leteckých dnů.
Peggy po startu vyleze z kokpitu na horní křídlo.
Tam předvádí různé cviky.
Ke konci vystoupení se přesune do prostoru mezi křídly letounu, kde její show pokračuje," popsal Luděk Matějíček z chebského Ultralight Clubu a organizátor leteckého dne.
Pilotem letounu Boeing Stearman 75 E je její manžel Friedrich.
Jestliže vystoupení Peggy bylo hlavním hřebem programu, pak následující představení stíhačky Mustang bylo pověstnou třešničkou na dortu.
Legendární stíhačka se na plochu přihnala s Grippeny Armády České republiky v závěsu (takzvaně na číslech).
Takovou sestavu mohli letečtí fanoušci v Česku vidět poprvé.
Pilot Miroslav Sázavský pak všem předvedl dech beroucí akrobacii s letounem z roku 1945.
Vyrobený byl ještě za války, ale pravděpodobně se jí nikdy nezúčastnil.
Byl zařazený v armádních rezervách.
Od roku 1963 působil v civilní sféře.
I jako závodní letoun.
Dnes má svůj domovský hangár na letišti v Mnichově Hradišti.
Na stejném místě je také další perla chebského leteckého dne, dvoumotorový Beechcraft C45H Expeditor.
Na letišti nešel mohutný stroj přehlédnout.
Jeho vyleštěný hliníkový potah zářil do dálky.
Obdiv si získal i stroj Max Holste MH 1521M Broussard v barvách francouzského letectva.
Malé dopravní letadlo zaskočilo za odřeknutý Turbolet a z německého Hofu přivezlo část německé delegace na letecký den.
Němečtí sousedé se v Chebu předvedli s rekonstruovanými letadly Jak 18T nebo tříčlennou formací dvouplošníků Bücker Jungmann.
Lucie Borhyová: Dramatický návrat před kameru!
Rodičovské starosti vyměnila Lucie Borhyová alespoň pro dnešní večer za ty pracovní.
Stres nebo nervozita - blonďatá moderátorka nic z toho evidentně nezná.
Moderovaní televizních zpráv jí totiž šlo dobře, jako by s ním na dva měsíce vůbec nepřestala!
Je to teprve přitom dva týdny, co blondýnce skončilo šestinedělí, při kterém zažívají ženy po porodu ten největší stres.
Lucie se však v hlavní zpravodajské relaci TV Nova ještě pravidelně ukazovat nebude.
Regulérní návrat ji čeká podle informací Blesk.cz až za měsíc.
Přece jenom ji její dcera Linda nyní potřebuje víc než televizní diváci.
Lucie Borhyová se vrátila na televizní obrazovku a byla to trefa do černého.
Exhibice za rok v Praze?
Hala by se vyprodala, plánuje rozlučku Jágr
Bylo by důstojné, kdyby se něco takového udělalo během mistrovství světa.
Ale záleží, jak se k tomu postaví svaz," říkal v Jihlavě po exhibici s názvem Zlaté utkání, ve kterém se znovu sešel úchvatný naganský tým.
I hráči, kteří se podíleli na zlatém hattricku.
Hráči by chuť měli, že?
Určitě.
Bylo by zkrátka dobré udělat rozloučení se zlatou generací během mistrovství.
Podle mě se dají během turnaje najít jeden dva dny, kdy je úplné volno a kam by se dalo takové utkání vmísit.
Řekneme to Gumovi (Jiřímu Šlégrovi) nebo Béďovi Ščerbanovi (pořadatel jihlavského zápasu), kteří by si to vzali na starost...
Aréna by se vyprodala.
Jenže co když budete hrát s New Jersey play-off?
Tak když tak přiletím...
Hrát v reprezentaci ale nechcete.
Nebo jihlavské setkání nějak pozměnilo vaše rozhodnutí?
Reprezentace a exhibiční utkání jsou dvě rozdílné věci a v reprezentaci jsou rozhodující výkony.
Jedna věc je, že by mě tam lidi rádi viděli, ale výkony jsou rozhodující, zvlášť na mistrovství světa.
Tam by měli jezdit hráči, kteří na to mají, a ne kvůli tomu, že mají dobré jméno.
Mé rozhodnutí se nijak nezměnilo.
Jak jste si vlastně užil to naganské shledání?
Už jen to setkání s hráči bylo skvělé.
Člověk si oživil historky a zažil spoustu legrace.
Byl to skvělý zážitek nejen pro fanoušky, ale i pro nás hokejisty.
Ovšem nejdůležitější byla pocta Ivanu Hlinkovi.
A je dobré připomínat historii našeho hokeje a to, že odchází jedna generace, která za to opravdu stála.
Slavomír Lener, Vladimír Růžička a Petr Čechmánek na střídačce.
Sám si ještě vybavíte svůj první reprezentační zápas?
Na takové věci se nezapomíná.
Bylo to proti Calgary Flames a tři mladí: já, Robert Holík a Robert Reichel, jsme nastoupili v jedné trojce.
Pro všechny to byl první reprezentační start.
No ale že bychom nějakým způsobem dominovali, tak to se nedá říct.
V Jihlavě po dlouhé době chytal Dominik Hašek.
Co jste říkal na jeho výkon?
Mě Hašan na ledě nikdy nepřekvapí.
Chtěl jsem mu to vrátit s tou kritikou, ale nemůžu (Hašek kritizoval Jágra za důvody, proč se rozhodl skončit v reprezentaci).Zachytal prostě výborně.
I Hnilička se skvěle předvedl.
Přitom si byl se mnou jednou v noci zatrénovat a tam byl děravej.
A teďka chytal famózně.
Nejdřív USA a pak už Nizozemsko, fotbalistům začíná kvalifikace
Ke smíchovskému NH Hotelu se v pondělí dopoledne sjížděli prominentní hosté.
Lidé mohli zahlédnout třeba brankáře Petra Čecha z Chelsea, reprezentačního trenéra Pavla Vrbu...
A tamhle, ta postava v černé kšiltovce, to je Tomáš Rosický!
Záložník Arsenalu a kapitán reprezentace dorazil na sraz kolem půl dvanácté mezi posledními.
Čeká nás krásný zápas proti Nizozemsku.
Kdo by se netěšil?" řekl, když už v reprezentační soupravě předstoupil před novináře.
Program české reprezentace
Pondělí 1. září: začátek srazu, první trénink
Úterý 2. září: Trénink otevřený pro fanoušky (18:30, Letná) Autogramiáda (20:00)
Středa 3. září Česko - USA (20:15, Letná)
Úterý 9. září Česko - Nizozemsko (20:45, Letná) konec srazu
Rosického a spol. můžou fanoušci podpořit ještě před středečním zápasem proti USA (20:15).
Reprezentace pro ně totiž otevřela úterní trénink, který na Letné začíná v 18:30.
A po něm bude následovat autogramiáda, na které Rosický ani Čech nebudou chybět.
Jinak ovšem bude tento sraz národního týmu klidnější.
Což si pochvaluje trenér Vrba, jenž si právě na množství společenských akcí na jaře stěžoval.
Konečně se budeme věnovat tomu, čemu se věnovat chceme.
Teď se budeme soustředit na Nizozemsko.
Je výhoda, když máte hráče pohromadě osm dnů.
Budeme mít čas nacvičovat věci, na které doteď tolik času nebylo," pochvaloval si Vrba, jenž národní tým oficiálně vede od ledna.
Českou fotbalovou reprezentaci bude při vstupu do nového kvalifikačního cyklu provázet mušketýrská image.
Reprezentace má pod Vrbou za sebou tři zápasy, všechny přípravné.
S Norskem a Finskem remizovala 2:2 a s Rakouskem prohrála 1:2.
Tyto výsledky však ještě důležité nebyly.
To až teď.
Zápasem s Nizozemskem totiž odstartuje kvalifikace o postup na mistrovství Evropy 2016.
Českému mužstvu by samozřejmě pomohlo, kdyby zvládlo i generálku proti USA.
První půlrok byl, abychom se poznali.
Teď už jsou důležité výsledky.
Musíme myslet na to, abychom byli úspěšní," souhlasil Vrba.
Jediným hráčem třiadvacetičlenné nominace, který má zdravotní problémy, je útočník David Lafata.
Trápí ho teplota.
Pokud by se nestihl uzdravit do středečního utkání proti USA, trenér Vrba by povolal ještě jednoho útočníka.
Genetické poruchy jsou často špatně diagnostikovány
Žena z Británie popisuje, jak si po špatné diagnóze mnoho let myslela, že zemře.
Poté, co byla diagnostikována s jinou chorobou, strávila Karin Rodgersová většinu dospívání v domnění, že jí zbývá jenom několik let života.
Ve skutečnosti se jednalo o Charcot-Marie-Tooth syndrom (CMT) - skupinu dědičných poruch, které poškozují nervy mimo mozek a páteř.
Charitativní organizace CMT UK uvedla, že špatná diagnóza je mezi lidmi s CMT běžný problém, protože o nemoci se ví jen velmi málo.
Má se za to, že ve Spojeném království trpí CMT přibližně 23 000 lidí, což se může projevovat symptomy v oblasti motoriky jako je svalová slabost, nemotorná chůze a zkroucené prsty na nohou.
U postižených se může vyskytnout také necitlivost nebo bolest, tento stav je neléčitelný a progresivní, což znamená, že postupem času se symptomy zhoršují.
Když bylo Rodgersové třináct, myslela si, že trpí Freidreichovou ataxií (FA) - onemocněním, které má velmi špatnou prognózu.
Věřila, že než oslaví osmnácté narozeniny, bude upoutaná na kolečkové křeslo, a mrtvá, než jí bude třicet.
Matka dvou dětí, které je nyní 51, říká: „Jako dítě jsem věděla, že nemůžu dělat stejné věci jako ostatní.
Každý den jsem upadla a všechno mi trvalo déle.
Nikdy jsem nemohla s ostatními dětmi jezdit na kolečkových bruslích nebo na skateboardu a ve škole mě šikanovali kvůli tomu, jak jsem chodila a běhala.“
Když bylo Rodgersové třináct a byla po několika operacích, které měly uvolnit její Achillovy šlachy a narovnat chodidla, využila toho, že její lékař odešel z místnosti, a nahlédla do své dokumentace, kde se dozvěděla, že trpí FA.
„Cítila jsem se provinile, protože jsem slídila, a tak jsem to nikomu neřekla, ale když jsem se vrátila domů, vyhledala jsem si informace o nemoci v knihovně a napsala jsem do Asociace FA,“ říká.
Když mi odpověděli, byla jsem v šoku, naprosto jsem zpanikařila.
Myslela jsem, že než mi bude osmnáct, skončím na vozíku, a než mi bude pětadvacet, budu mrtvá, a mezitím postupně ztratím veškeré svoje schopnosti.
Byla jsem na to úplně sama a plánovala jsem si pohřeb.“
Když jí bylo sedmnáct, uvědomila si, že její schopnost chůze se nezhoršila tolik, kolik předpokládala, a zeptala se na to svého chirurga.
Jenom se postavil, objal ji a řekl: „Zlatíčko, nemyslím si, že tu nemoc máš, jinak bys už byla na vozíku.
Myslím, že to bude něco mnohem méně životu nebezpečného.“
Po absolvování několika genetických testů se zjistilo, že má CMT.
„Když mi vysvětlil, co CMT je, myslela jsem, že jsem dítě štěstěny,“ prohlásila.
Charitativní organizace CMT UK zahájila měsíc informovanosti o CMT, aby na tuto nemoc upozornila.
Podnikatelé v oblasti Washingtonu: s obratem ekonomiky se zvedají daně
Rostoucí ekonomika znamená více zákazníků, vyšší prodeje a nová pracovní místa.
A taky vyšší daně.
Podle nového průzkumu, který byl zveřejněn minulý týden, státní a místní zdanění firem v zemi s urychlováním ozdravení ekonomiky minulý rok mírně vzrostlo a firmy ve Washingtonu nebyly výjimkou.
Podnikatelé v Marylandu a Virginii dohromady za fiskální rok 2013 do státních a lokálních pokladen odvedli 27,6 miliard dolarů, což je o 3,8 % vyšší částka než 26,6 miliard dolarů vybraných v roce 2012.
Daňové zatížení - státní i místní - se minulý rok zvedlo o 4,3 % na 671 miliard dolarů v porovnání s 3,9 % minulý rok a jednalo se o třetí růstový rok za sebou po letech 2009 a 2010, kdy se daně snižovaly.
Podle studie, kterou provedla profesionální firma Ernst & Young a politické uskupení Center on State Taxation, se státní daně zvyšovaly rychleji, o 4,3 %, než místní odvody, o 3,9 %.
Více než polovina daňových příjmů okrsku, 56 %, je z živnostenské daně, a 36 % příjmů Marylandu je od společností.
Virginia, s 28 %, vykazuje úměrně nejmenší daňové příjmy z podnikání.
Výzkumníci tvrdí, že většinový podíl růstu daňových příjmů pochází ze zvýšení hodnoty nemovitostí patřících firmám, což daně z nemovitosti tento rok po třech po sobě jdoucích letech s růstem -1 % zvýšilo o 3,7 %.
Přestože většina zisku pochází z velkých států jako Kalifornie, New York a Texas, zdá se, že stejná situace je i ve Washingtonu.
Společnosti v D.C., Marylandu a Vriginii minulý rok zaplatily přes deset miliard dolarů na státních i místních daních z nemovitosti, což v porovnání s 9,6 miliardami v roce 2012 představuje roční nárůst o 4,2 %.
Zjevné zvýšení hodnoty nemovitostí však tolik nevyhání nahoru státní a místní daňové příjmy v Marylandu, kde daň z nemovitosti představuje necelou pětinu zdanění společností.
Pro firmy ve Virginii a D.C. představuje daň z nemovitosti téměř polovinu státního a místního zdanění.
„V Marylandu vlastní hodně nemovitostí firem, především základ daně v okolí D.C., vláda nebo nevýdělečné organizace, které neplatí daně,“ vysvětlil Douglas Lindholm, výkonný ředitel Center on State Taxation.
Takže Maryland je nucený se mnohem více spoléhat například na daně z příjmů, aby zaplatil za stejné služby, které jsou v jiných státech.
Nedávné zvýšení daňových příjmů z podnikání nemůže být připsáno pouze uzdravujícímu se trhu s nemovitostmi.
Podle údajů se zdá, že příjmy z podnikání se také zvyšují.
Firmy v tomto regionu zveřejnily daň z příjmu obchodních společností 2,3 miliardy dolarů, které se zvýšily z 2,1 miliardy z roku 2012.
Maryland na daních z příjmů obchodních společností vybral jednu miliardu dolarů, nejvíce v regionu.
Přestože se ubírají stejným směrem, místní daňové zatížení podnikatelů neroste v těchto třech místech stejně rychle.
Míra růstu v D.C. byla na úrovni celostátního průměru, na 4,3 %, zatímco růst Marylandu byl výrazně vyšší, 4,9 %.
Pouze ve Virginii bylo zvýšení zdanění pod průměrem, na 4,1 %.
Virginia má ze všech tří obvodů (z nichž všechny mají stejné zdanění) nejnižší zdanění příjmů obchodních společností, 6 %.
Míra zdanění obchodních společností v Marylandu je 8,25 %, zatímco průměr D.C. zůstává relativně vysoko, na 9,975 %.
Podobná studie, kterou tento rok provedla americká obchodní komora, ukázala, že Virginia má nižší státní a místní zdanění a celkově příznivější daňové klima než Maryland.
D.C. studie nehodnotila.
I přes tuto výhodu čelí Virginia tlaku konkurence z jihu.
Severní Karolína nedávno podepsala zákon snižující daň obchodních společností z 6,9 % na 6 %, stejně jako Virginia, a příští rok se daň sníží na 5 %.
Pokud bude stát v nadcházejícím roce nadále splňovat příjmové cíle, mohla by se v roce 2017 zákonem stanovená míra zdanění příjmů snížit až na 3 %.
Podle nedávné studie se drobným podnikatelům ve Washingtonu vede lépe, a proto platí vyšší státní a místní daně.
Živnostenská daň odváděná drobnými podnikateli jako daň z osobních příjmů - struktura kompenzace zvyšování nákladů zvyšováním cen, podle které je organizována většina firem - v D.C., Marylandu a Virginii vzrostla minulý rok o 20 % na 2,4 miliardy dolarů, mnohem rychleji než jiné daně.
Výzkumníci tvrdí, že trend a celostátní zvyšování živnostenské daně budou pravděpodobně příští rok pokračovat, celkové daňové příjmy z prodeje pro státní i místní vlády se v porovnání za stejné období v minulém roce prvních třech čtvrtletí roku 2014 zvýší na 6,2 %.
Washington však může za ostatními zaostávat, protože snižování státních výdajů si vybírá svou daň na pracovním trhu.
Co vám uniklo: šéfem Evropy bude Tusk, Putinovo Novorusko i Lafatovy nůžky
Vznikne na Ukrajině nový stát?
Putin vyzval k jednání o Novorusku
Ruský prezident Vladimír Putin se zmínil o možnosti vytvoření nového státu na jihovýchodě Ukrajiny, kde se od dubna střetávají vládní jednotky s proruskými povstalci.
Varoval rovněž evropské firmy, že po nynějším režimu protiruských sankcí budou mít obtížný návrat na ruský trh.
Podpora, kterou Západu poskytuje válčení ukrajinské armády na východě Ukrajiny, podle něj odporuje demokratickým hodnotám.
Ukončení konfliktu podle něj závisí na Kyjevu, a tak nedokáže říci, kdy ukrajinská krize skončí.
Další sankce pro Rusko?
Česko si vymohlo právo s částí nesouhlasit
Evropská komise má spolu s diplomaty do týdne navrhnout podobu dalšího přitvrzení protiruských sankcí, rozhodl v noci na dnešek summit EU.
Novinářům to řekl stálý předseda schůzek členských zemí Herman Van Rompuy.
Podle českého premiéra Bohuslava Sobotky mají být konkrétní návrhy na posun podoby sankcí připraveny už v pondělí.
Tusk bude novým unijním "prezidentem".
Van Rompuye nahradí v prosinci
Polský premiér Donald Tusk byl na summitu Evropské unie zvolen do čela Evropské rady, tedy takzvaným unijním prezidentem, který řídí vrcholné schůzky členských zemí.
Od prosince na dva a půl roku nahradí Hermana Van Rompuye.
V čele evropské diplomacie vystřídá Catherine Ashtonovou italská ministryně zahraničí Federica Mogheriniová.
Italku, která se tak stane místopředsedkyní budoucí Evropské komise, ještě musí ve funkci potvrdit Evropský parlament.
Asistovaná smrt je v Česku realita, jen se o ní nemluví
Pomoci nevyléčitelnému a dlouhodobě trpícímu pacientovi s odchodem ze života?
V českých podmínkách, kde zákony nepovolují eutanazii, to legálně nejde.
Přesto z vyjádření lékařů, které LN oslovily, vyplývá, že o takových žádostech slýchávají.
ALS: Nejtěžší kapitola neurologie, říká lékař o skleróze
Česku trpí amyotrofickou laterální sklerózou (ALS) přibližně tři stovky lidí, 21 pacientů podstupuje v pražském Motole experimentální léčbu kmenovými buňkami.
My stoprocentně nevíme, zda bude úspěšná.
Ale když to nezkusíme, tak to nezjistíme," říká Radim Mazanec, motolský neurolog.
Je v tom znát rukopis CIA, potřebovali válku, píše Huml o sestřelení letu MH17
Poslanec za ČSSD Stanislav Huml má jasno v tom, kdo sestřelil malajsijské letadlo nad Ukrajinou.
Podle něj je zřejmé, že "tvrdé sankce, které byly vyhlášeny s ohledem na sestřelení civilního letadla s téměř 300 mrtvými, způsobila úmyslně ukrajinská armáda".
Podle zákonodárce je z toho navíc znát rukopis CIA.
Nesplnitelné sliby.
Blíží se volby a strany opět nabízejí i nemožné
Konec bezdomovců na ulicích, parkování pro každou rodinu i lanovka nad Prahou.
Před každými volbami se to opakuje: strany slibují nemožné.
Také nyní se s blížícími komunálními volbami politici předhánějí, kdo se voličům víc zalíbí.
Server Lidovky.cz vybral nesplnitelné sliby ze současnosti i minulosti.
Před 70 lety se Čechoslováci vylodili u Dunkerque.
Začalo urputné obléhání
Bylo to 30. srpna 1944, kdy se československá samostatná brigáda přesunula do Francie.
Její velitel Alois Liška soustavně žádal o doplnění technického vybavení a odeslání na frontu.
Britská strana nakonec vyhověla a tuto pozemní jednotku zařadila jako jednu ze svých sil při obléhání přístavního města Dunkerque, které zůstávalo v moci německých vojsk.
SOUHRN: Plzeň vede ligu před pražskými "S", Liberec deklasoval Baník
Viktoria Plzeň je novým lídrem fotbalové ligy, kterou vede o bod před oběma pražskými "S".
Změny v čele tabulky způsobila porážka Slavie 1:2 v Mladé Boleslavi.
Po dvou porážkách se v domácí lize vzpamatovala Sparta, díky dvěma Lafatovým zásahům porazila Jablonec.
Rekordní výhru v ročníku si připsal Liberec, který rozstřílel Baník Ostrava 6:0.
62 tisíc diváků na volejbale?
Poláci říkají ano
Úvod MS volejbalistů ve Varšavě přinesl divácký rekord.
Na fotbalovém stadionu pod zataženou střechou sledovalo hladkou výhru domácích nad Srbskem 62 tisíc diváků.
Vstupenky byly přitom vyprodány za 100 minut.
Jak přežít návrat z dovolené?
Nikam nespěchejte a dopřejte si spánek
Poslední dny prázdnin jsou před námi.
Zvyknout si po návratu ze slunečné pláže nebo chalupy na běžné pracovní tempo může být pro mnohé oříšek.
Může jej dokonce doprovázet i deprese.
Naštěstí existují osvědčené tipy, jak se se změněnou situací vyrovnat: nespěchat a dopřát si kvalitní spánek.
Rodina Joan Riversové: „Držíme palce“
Joan Riversová je v bezvědomí tři dny, od chvíle, kdy ji přivezli do nemocnice v New York City, ale její dcera se dnes vyjádřila, že neztrácí naději, že se jednaosmdesátiletá komička uzdraví.
„Děkujeme za vaše pozdravy a podporu,“ uvedla Melissa Riversová v dnešním prohlášení.
Držíme jí palce.
Její matku přivezli do Mount Sinai Hospital ve čtvrtek po telefonátu na záchrannou službu, podle kterého u ní došlo k srdeční zástavě na yorkwillské endoskopii v Upper East Side, jak uvedl zdroj.
Lékaři ji záměrně udržují pod vlivem sedativ a pod přísným dohledem, dokud si nebudou jisti jejím stavem, který zůstává „vážný“.
Reakce na sebe nenechaly dlouho čekat a to včetně neskutečné podpory na internetu od osobností jako Donald Trump, Montel Williams a Kelly Ripa.
Realita je překrucovaná titulky
Že média svými titulky překrucují realitu, není (bohužel) žádná novinka.
Vím, že titulky "prodávají" noviny, ale bohužel také vím, že jsou mnozí takzvaní "čtenáři", kteří nic jiného nečtou.
A to je fakt, který mě poslední dobou velmi trápí, výstižnější je spíš slovo štve.
Týká se to zejména článků o konfliktu Izraele a Hamásu v pásmu Gazy.
Zcela běžné jsou titulky "Izrael zaútočil na Gazu".
Teprve v textu se dočtete, že izraelský "útok" byl reakcí na vypálené rakety z pásma Gazy, a to mnohdy v době vyhlášeného příměří.
To se pak objeví titulek "Obě strany porušily příměří".
Uvědomuje si novinářská obec, že tímto svým postupem se přímo podílí na antisemitských postojích, které po celé Evropě (a nejen tam) narůstají?
Neuplynulo ani šedesát let od konce 2. světové války.
Dosud žijí lidé, kteří přežili Šoa.
Když jsem viděla videa ze Spolkové republiky Německo, kde dav vykřikoval hesla "židovské svině" a podobné zhůvěřilosti, zatrnulo mi.
To chce svět dokončit to, co se nepovedlo Hitlerovi?
Uvědomují si naši novináři fakt, že po Židech byli určeni k likvidaci Slované?
Dámy a pánové novináři, věnujte prosím trochu více péče své práci.
Často jste označováni za "hlídací psy demokracie".
Tak ji obhajujte.
Dokud tu je.
A obhajujte také právo jediného opravdu demokratického státu na Blízkém východě na ochranu svého obyvatelstva.
Jak byste chtěli, aby se zachovala naše vláda, kdyby se některý z našich sousedů rozhodl, že český národ zlikviduje a Českou republiku vymaže z mapy světa?
Možná byste si také měli uvědomit ještě jeden fakt.
Na území státu Izrael bydlí téměř 20% Arabů s izraelským občanstvím.
A je jim tam dobře.
Když se jich zeptáte, proč nejdou mezi "své", třeba do Gazy, odpovědí vám, proč by to dělali?
V Izraeli mají práci, sociální jistoty a špičkovou zdravotní péči (sama jsem na vlastní oči viděla, jak do špičkové soukromé nemocnice Hadassa, která je financována ze sponzorských darů Židů z celého světa, běžně chodí i Arabové a jsou tam pochopitelně ošetřeni).
Hamás svými střelami útočí i na své arabské bratry.
Jediná opravdová pomoc Gaze, a tím i této neklidné oblasti, je zbavit ji Hamásu a odzbrojit ho.
A ne odsuzovat Izrael, byť nepřímo v titulcích.
Informujte o praktikách Hamásu, o jeho zneužívání lidí jako lidských štítů.
Informujte o tom, že Hamás má za cíl zlikvidovat stát Izrael, a to za jakoukoliv cenu.
I za cenu smrti nevinných arabských dětí.
Informujte o tom, že Hamás je na seznamu světových teroristických organizací.
Informujte o tom, že za devět let samosprávy v Gaze mohla být tato oblast vzkvétající díky humanitární pomoci z celého světa.
Dokonce i z Izraele, který tam dodává vodu a elektřinu, za kterou ovšem správci Gazy neplatí a dokonce se rozčilují, že jsou v této době občas dodávky proudu přerušeny.
Kdyby Hamás neinvestoval peníze do výstavby podzemních tunelů, aby jimi mohli pronikat sebevražední útočníci na území Izraele, ale třeba do výstavby bytových domů, nemocnic a škol, žilo by se jeho arabským bratrům z Gazy podstatně lépe.
Amazon kupuje za 1,04 miliard dolarů Twitch
AMAZON právě potvrdil tvrzení Information z pondělního rána: Internetový maloobchodník - producent videí a stovky dalších věcí - kupuje za 1,04 miliardy dolarů (970 milionů amerických dolarů) video streamingovou službu Twitch.
Oznámení vyvolalo překvapení nikoliv proto, že by nikdo neočekával, že Twitch někdo koupí, ale protože se očekávalo, že kupcem bude YouTube.
Před třemi měsíci vypadal prodej Twitche Googlu za jednu miliardu jistý, a toto spojení vypadalo jako přirozené.
Twitch, který teprve před třemi lety založila Justin.tv, měl našlápnuto k tomu, aby se stal všeobecně používanou video streamingovou službou - živá verze YouTube.
Místo toho se z něj rychle stala platforma pro hráče, kteří na ni vysílali online přenosy z her - slovy Business Insider „YouTube pro živě přenášené hraní“.
Interaface Twitche.
Na YouTube jsou již populární videa „Let's play“, druh, kde mudrlanti (většinou starší) dávají hrám zpracování Mystery Science Theater.
Faktem je, že YouTube při popisuTwitche přichází na přetřes hodně, takže zprávy, že YouTube kupujeTwitch, nikoho moc nevzrušily, byl to učebnicový příklad toho, jak zavedená společnost vyplatí možnou konkurenci.
Záhadou je, proč dohoda s YouTube nevyšla, přestože společnost byla ochotná zaplatit stejnou částku jako Amazon.
Vše, co v současné době máme k dispozici, je vyjádření CEO Twitche Emmeta Sheara: „Vybrali jsme si Amazon, protože věří v naši společnost, má stejné hodnoty a dlouhodobou vizi a chce nám pomoci splnit ji rychleji.“
Další záhadou je - upřímně - neuvěřitelný úspěch Twitche.
Pro snoby jako jsem já, kteří tvrdí, že sport radši dělají než sledují, je těžké pochopit, co je tak úžasného na tom, hry místo skutečného hraní jenom pozorovat.
Jedna věc je dívat se ve tři ráno kamarádce přes rameno, jak hraje Resident Evil, a úplně jiná věc je pozorovat někoho cizího, jak dostane dvacet zásahů do hlavy v Call of Duty.
Všechny hry, na které byste se právě mohli dívat.
Další problém je, že spousta dnešních, nejvíc populárních her jsou z perspektivy hráče, takže dívat se na jejich záznam, aniž byste mohli sami perspektivu kontrolovat, je docela dobrý recept, jak si pořídit bolehlav.
Připouštím, že hry typu speed run, ve kterých Rogeři Bannisteři naší elektronické doby dokončí hru v rekordním čase, je zábavné.
Pokud ale někdo není mistr hraní nebo humoru, jeho kanál na Twitchi pravděpodobně nebude moc zajímavý.
Ale co o tom skeptici jako já vědí?
Twitch má měsíčně 55 milionů návštěv a je čtvrtý na vrcholu internetového provozu.
Jak přesně toho Amazon využije?
Je těžké si představit, že se Twitch vmíchá do Amazon Instant Video stejně elegantně, jako by ho bývalo mohlo spolknout YouTube.
Twitch ale má něco, co by chtěla přitáhnout každá firma: hordy mladých mužů, které inzerenti chtějí.
Jak řekl ředitel Twitche Shear, Amazon i Twitch „věří v budoucnost her“ a média nevypadají, že by se zdráhala, ani jako - polknutí - diváci.
Druhá základní lež kreacionismu.
Další český překlad amerického ateistického vloggera Arona Ra.
Tentokrát na téma "Svatá písma jsou boží slovo."
Přiloženo původní video.
Druhou základní lží kreacionismu je víra, že posvátné texty byly sepsány bohem a nikoliv skutečnými lidskými autory.
Když věřící debatují o jedné z mnoha věcí, které jsou v rozporu s jejich náboženstvím, často nás postaví před otázku: Komu budete věřit?
Údajnému božímu slovu, nebo slovu člověka?
Jako kdyby lidské zkoumání bylo zcela nicotné ve srovnání s autoritou jakou si představují, že má jejich doktrína.
Jenomže když říkají "člověk", hovoří o vědě.
A když referují ke "slovu Božímu", referují k mýtům o bohu zapsaným lidmi.
Jestliže skutečně existuje inteligentní s tvořitel s nějakým účelem, pak je to on, kdo vytvořil fosilní záznam, který odhaluje evoluční historii, a musí to být on, kdo vymyslel genetické vzorce, které jí odpovídají, a musí to být on, kdo dodal další řady důkazů, které ukazují výlučně k evolučnímu závěru do posledního detailu.
Proč by jinak všechny tyto věci existovaly?
Zdá se, jako kdyby se nám snažil něco říct!
Lidé nemohli vytvořit žádnou z těch věcí.
Ale lidé dovedou vyprávět příběhy, fabulovat.
A byli to lidé, kdo napsali všechny ty texty, které předstírají, že jsou slovem božím.
Každé údajně svaté učení kteréhokoliv náboženství na světě popisuje samo sebe jako sepsané lidmi, nikoliv bohy.
Lidmi, kteří byli "pohnuti" či "inspirováni" svými oblíbenými bohy, nebo třeba naslouchali diktátu andělů, ale ty texty nebyly sepsány nikým jiným než pouhými smrtelníky s určitou mírou představivosti, nikoliv anděly a už vůbec ne bohy.
Kdyby skutečně existoval jeden skutečný bůh, byl by integrální součástí všech bohů všech náboženství, über-galaktický supergénius, ultimátní entita celého kosmu.
Kdyby bytost takové velikosti někdy napsala knihu, existovala by jen jedna taková kniha, jediné písmo svaté.
Byla by známá všude na světě, bez předchůdců, paralel či alternativ v jakémkoliv jazyce, protože pouzí lidští autoři by se s takovým dílem nemohli měřit.
A lidé by jí nemuseli naslepo věřit, protože by byla konsistentní, podložena ověřitelnými a pravdivými důkazy, a zjevovala by hlubokou mravnost a moudrost dalece přesahující veškeré lidské limity.
Trvale by inspirovala každého čtenáře k jednotě společné víry.
Pokud by ji napsal bůh, nečekali bychom nic menšího.
Jenomže to, co vidíme místo toho, je přesným opakem.
Místo jediného náboženství vedoucího ke konečné pravdě máme mnoho různých náboženství bez společného původu a všechna se neustále rozpadají na čím dál více oddělené denominace, hledající sporné pravdy a každá si nějakým způsobem nárokuje boží vedení, bez ohledu na pokračující rozbíhavost a oddělování v každém směru.
Židovská Tóra, křesťanská evangelia, islámský Korán, Bahá'u'lláhův Kitáb-i-Akdás, Zarathuštrovy Avesty, sikhský Adí-Granth, Mahabharátská Bhagavad-Gita, Kniha Mormonova, či kniha Urantia jsou všechny považovány za "absolutní pravdu" a "zjevené slovo jediného pravého boha" a příslušní věřící každé z nich říkají, že ti ostatní jsou na scestí.
Jediné logické vysvětlení pravděpodobně je, že na scestí jsou do určité míry všichni.
Žádná z výše zmíněných knih nemá oproti ostatním žádnou výhodu.
Žádná z nich nemá důkazní oporu a žádná se nedá historicky potvrdit.
Jmenuji se Dr. Paul Maier, a jsem profesor starověké historie na Západní michiganské univerzitě.
Neříkám, že jsem dokázal, že Bible je spolehlivá a historický přesná.
Samozřejmě, že není.
Pořád musíte mít víru.
Všechny z nich vyžadují víru a také apologie (obhajoby), protože obsahují nesrovnalosti, absurdity a primitivní představy kdysi považované za pravdivé, které už byly překonány.
Takže nelze tvrdit, že jsou důkazem božské moudrosti.
Mnoho z nich prosazuje ohavná zvěrstva namísto mravnosti a o mnoha z nich se tvrdí, že byly potvrzeny naplněním proroctví - s tím, že každá taky může obsahovat proroctví která naplněna nebyla.
Přední teologové připouštějí, že všechny posvátné texty jakéhokoliv náboženství byly napsány lidskýma rukama a tudíž jsou předmětem interpretací, dojmů a pohledů jejich primitivních a často předsudky svázaných politicky motivovaných autorů, čímž vysvětlují mnohé z protimluvů a nesrovnalostí v těchto knihách, zvláště pak těch v Bibli.
Já bych to nenazýval protiřečení, spíš vzájemné komentáře.
Musíme znovu poukázat na to, že zde máme dva různé autory, jejichž práce byla nějak smíchána dohromady během nějaké redaktorské revize.
Má pravdu, že Genesis má více než jednoho autora a rozhodně není vyprávěním očitého svědka!
Někteří experti nyní rozlišují čtyři různé zdroje jen pro Pentateuch, tj. pět Knih "Mojžíšových" a Mojžíšovi nepřipisují autorství žádné z nich, protože téměř jistě neexistoval tak, jak je v Bibli popisován.
Odborníci se shodnou na tom, že Genesis byla složena (pravděpodobně Ezdrášem) z několika vzájemně nepříbuzných ústních tradic před méně než 2500 lety.
Ostatní dokumenty byly přefiltrovány v tom samém čase a všechny jsou připisovány lidským autorům.
Bible není ani náhodou tak stará, jak si její věřící myslí.
Svitky od Mrtvého moře jsou nejstaršími archeologickými nálezy textů známé pro svůj nedokončený základ všech západních monoteistických věr, a přesto jsou o mnoho století mladší než kořeny zoroastriánství, buddhismu, hinduismu, helénismu, druidských kultů, čínského či egyptského náboženství.
Křesťanství začalo jako gnostická víra, následovali docéti a ebionité a jejich úplně jiné náhledy na Ježíše, které se nakonec zkombinovaly v jakémsi kompromisu nazvaném ortodoxie.
Ostatní křesťanské skupiny jako luciferiáni byli rozehnáni a zdiskreditováni dalšími revizemi Bible.
Jedna z těchto uprav se vztahuje ke králi Ugaritu, který vládl před 3500 lety.
Protože jeho následovníci představovali zásadní ohrožení pro mladé mojžíšké náboženství, autoři Nového zákona se rozhodli zesměšnit a Ba'al Zebula, "Pána na hoře" změnili na Belzebuba "Pána much".
Takže Bible byla záměrně a podvodně pozměňována jak z náboženských, tak z politických důvodů.
Zbývající část toho, co se stalo Novým zákonem byla kanonizována ve 4. století n.l. v sérii komisních rozhodnutí na sněmu v Nikaji.
Čtyři evangelia byla přijata a šestnáct dalších bylo odmítnuto prostým zvednutím ruky, jako kdyby se skutečnost nějaké věci dala přijmout nebo odmítnout hlasováním.
Způsob, jakým se kánon vyvinul závisel na tom, co se četlo o nedělích v tehdejších křesťanských centrech.
Co se četlo na druhou neděli po velikonocích v Jeruzalemské církvi?
A co v římské církvi v tom samém čase?
A postupně zjišťovali, že se blíží k těm samým evangelijním příběhům.
A tak se jádro kánonu takto vyvinulo z úzu prvotní církve.
Takže koncil prostě přijal jako evangelium jakékoliv relevantní příběhy které kolovaly mezi nevzdělanými masami v tom čase.
Ale stejně tak vědomě odebrali více než deset knih z Bible, i když k nim referovaly knihy, které byly schváleny.
Mezi odmítnutými položkami najdeme spisy jak apoštolů, tak proroků.
Proč by nás boží slovo mělo odkazovat na knihy, které jsou jen slovy nějakých lidí a/nebo už ani nejsou k dispozici?
Kdo tady byl skutečným editorem?
Bible často zmiňuje lidské autory.
Ale jak by mohla být takto schválena, kdyby byl bůh skutečným autorem této nahodilé míchanice pověstí, podobenství a žalmové lyriky?
Bible byla zcela určitě napsána lidmi a rozhodně ne příliš osvíceními, spíše naopak!
To je ten důvod proč je tak velká část jejího obsahu historicky a vědecky zcela na omylu, ať už jde o téměř cokoliv od začátku až do konce.
Hovoříme o lidech, kteří věřili, že hadi a osli mohou mluvit, věřili v zaklínadla, krvavé oběti, rituální kouzla, očarované předměty, ohnivé lektvary, astrologii a pět živlů magie.
Mysleli si, že když použijí kouzelný prut, kterým někoho postříkají krví, vyléčí ho to z lepry.
Hovoříme o lidech, kteří si mysleli, že králíci jsou přežvýkavci a netopýři jsou ptáci a velryby jsou ryby a pí že je celé číslo.
Tihle lidé věřili, že když ukáží těhotné krávě pruhované vzory, porodí pruhovaná telata.
Jak by tohle mohl říct někdo, kdo ví něco o genetice?
Autoři této knihy to samozřejmě nevěděli.
Kdyby Bible byla sepsána nějakou vyšší bytostí, pak by neobsahovala takové chyby, jaké obsahuje.
Kdyby pocházela z pera skutečně nadřazené bytosti a byla zamýšlena jako doslovná historie, potom by neobsahovala vůbec nic z toho, co obsahuje.
Jako morální průvodce totálně selhává protože, většina z původních hebrejských spisů byla sepsána nevzdělanými a bigotními divochy, kteří přehlíželi nebo podporovali krutost vůči zvířatům, incest, otroctví, zneužívání otroků, zneužívání rodinných příslušníků, zneužívání dětí, násilí na dětech, potraty, plenění, vraždění, kanibalismus, genocidu a předsudky vůči rase, národu, náboženství, pohlaví a sexuální orientaci.
Aby obhájili svou nelidskost tvrzením, že konají boží vůli.
Avšak kreacionisté tohle všechno stále ignorují.
Některé z jejich webových stránek připouštějí, že pokud je jakákoliv skutečnost v rozporu s Biblí, pak musí být skutečnost ignorována!
A proč?
Protože kdyby kreacionisté neměli své milované knihy, neměli by ani boha.
V jejich světě je jedno a druhé totéž.
Je ironické, že odmítají boží "dílo" jako "uctívání stvoření namísto stvořitele".
Ale sami považují slovo člověka za slovo boží a boha samotného a dokonce trvají na tom, že vyvrácení jejich údajně "svatých" knih nějak vyvrací boha jako takového.
Nikoliv jejich verzi boha ale všechny verze boha.
Kreacionističtí křesťané si myslí, že pokud se Bible mýlí, pak bůh lže.
Nemohou přijmout, že by bůh mohl existovat a Bible by se současně mohla mýlit, protože nedokáží oddělit doktrínu od božstva.
Takže jde o druh modlářství, kde věřící uctívají člověkem vyrobené kompilace, jako kdyby tyto knihy byly samotný bůh, protože si myslí že jsou JEHO slovem.
Jenomže bůh nikdy nenapsal ani nediktoval žádný ze spisů jakéhokoliv náboženství.
Všechno, co lidé schválili či odmítli do svého údajně "neměnného slova" jakéhokoliv boha, bylo vymýšleno, sestavováno, seskupeno, překládáno, interpretováno, upravováno a často také záměrně pozměňováno a překrucováno pouhými chybujícími lidmi.
Originál zde:
Účastnice kbelíkové výzvy si vykloubila čelist
Když si lila na hlavu ledovou vodu, křičela Isabelle Robertsová ze Spojeného království tak, že si poškodila strukturu obličejových kostí.
Tahle kbelíková výzva se nepovedla.
Žena byla hospitalizována poté, co při kbelíkové výzvě křičela tak, že si vykloubila čelist.
Zatímco si na hlavu lila ledovou vodu, křičela Isabelle Robertsová tak intenzivně, že si poškodila strukturu kostí v obličeji.
„Voda byla tak studená, že jsem musela křičet, ale přitom mi začala tuhnout čelist,“ řekla pro The Mirror.
Dvacetiletá dívka na sebe vylévá vodu.
Isabelle Robertsová chvíli před nehodou
Zkoušela jsem zavřít pusu, ale nešlo to, byl zaseknutá, a uvědomila jsem si, že se něco děje.
Potom to došlo máme a sestře, ty se mohly potrhat smíchy, ale já jsem musela rychle na pohotovost.“
Dvacetiletá dívka musela být hospitalizována, aby jí vrátili čelist na původní místo poté, co se v úterý zúčastnila módní virální vlny.
Video se stalo internetovou senzací, na Facebooku a twitteru ho sdílely tisíce lidí.
Útočník v čínské škole pobodal devět lidí, tři z nich zemřeli
Muž jménem Čchen podle agentury Nová Čína ráno násilně vnikl do budovy základní školy a kolem půl jedenácté místního času zaútočil.
Tři z devíti lidí, které pobodal, později zemřeli v nemocnici.
Čchen se posléze zabil skokem z výšky, uvedla Nová Čína s odkazem na regionální vládu.
V posledních letech Čína zažila sérii podobných útoků ve školách a proti dětem.
Veřejnost proto volá po větších bezpečnostních opatřeních a lepší ochraně dětí v zemi, kde má mnoho manželských párů v souladu s vládní politikou jen jednoho potomka.
Zeman prvňáčkům v Lánech ukázal, jak musel ve škole sedávat
Nejmenší školáky odvedli deváťáci do jejich třídy, kde s paní učitelkou vyčkávali na příchod prezidenta.
Ten pak dětem předvedl, jak musel sám sedět ve škole.
"My jsme museli sedět s rukama za zády, to vás už naštěstí nečeká, vy už jste svobodní lidé," řekl dětem Zeman.
Jeho manželka pak prvňáčkům předala jako dárek hlavolam.
Prezident Miloš Zeman s chotí v první třídě základní školy v Lánech.
Ministr školství Marcel Chládek zahájil nový školní rok v soukromé sportovní škole v Litvínově.
"Tento rok chci více propojit české školství s českým sportem," přiblížil jeden z důvodů, proč se první školní den vydal na sever Čech.
Vedení školy ho před časem oslovilo na hokejovém utkání v Litvínově.
"Byli první, tak jsem pozvání k účasti na zahájení školního roku přijal," dodal ministr.
Ministr školství Marcel Chládek (ČSSD) zahájil školní rok v soukromé sportovní škole v Litvínově.
Do prvních tříd letos nastoupilo 115 tisíc prvňáčků.
Na základní školy bude chodit celkem přes 850 tisíc dětí a na středních školách se bude vzdělávat přes 405 tisíc studentů, odhaduje ministerstvo školství.
Novým art directorem zpravodajství Novy je David Fiala
Novým art directorem zpravodajství a publicistiky televize Nova se od 1. září stal David Fiala.
Ve funkci vystřídá Alana Zárubu, který vedl od 1. června kreativní oddělení celé skupiny Nova.
David Fiala dříve působil v grafickém oddělení zpravodajské televize Z1.
Poslední dva roky se pod vedením Alana Záruby podílel na realizaci kompletní vizuální proměny zpravodajských relací Televizní noviny, Střepiny, Prásk! a dalších publicistických pořadů televize Nova.
David Fiala ovládá velmi dobře synergii komunikace mezi redakcí, studiovým řízením a grafickým oddělením, což je podstata práce art directora zpravodajství.
Má cit pro typografii a čistý elegantní design, což je cesta, po které se chceme ve vizuálu zpravodajství Novy dále ubírat," říká kreativní ředitel Novy Alan Záruba.
Apple iCloud údajně podlehl hackerům, na veřejnost se dostaly nahé snímky celebrit
Snímek obrazovky s výpisem uniklých souborů
Zatím anonymní uživatel na serveru 4chan zveřejňuje nahé i pornografické snímky amerických celebrit, upozornil na to americký server Mashable.com.
Údajně je získal neoprávněným přístupem k uživatelským účtům na serverech Applu, kam je postižení uživatelé nahráli prostřednictvím automatického zálohování obrázků z iPhonů a iPadů.
Apple se k problému zatím nevyjádřil.
Část celebrit odmítá snímky jako zfalšované, ale již několik dotčených pravost snímků přiznalo.
Patří mezi ně i herečka Jennifer Lawrenceová známá z titulní role Katniss ve filmové sérii Hunger Games nebo Mary Elizabeth Winsteadová, která hrála například ve Smrtonosné pasti 4.0.
Cílem hackera je využít získané obrázky a videa k obohacení.
O záběry údajně projevily zájem americké časopisy, podle zpráv na serveru 4chan ale chce hacker raději peníze od komunity.
Podle serveru The Next Web jde velmi pravděpodobně opravdu o slabinu v zabezpečení iCloudu.
Na serveru GitHub se totiž před dvěma dny objevil nástroj, který umožňoval získat hesla k uživatelským účtům prostřednictvím hrubé síly, tedy automatickým opakováním pokusů o přihlášení s různými hesly.
Tento nástroj prokazatelně fungoval, ale Apple po dvou dnech bezpečnostní díru zavřel.
Jisté však je, že potenciální útočníci měli spoustu času na získání přístupu k různým účtům před zveřejněním tohoto nástroje.
Uživatelé iCloudu by tak měli z preventivních důvodů změnit své heslo spojené s Apple ID.
Důležitá je přitom délka hesla, ne jeho složitost.
Vhodný je délka alespoň 12 znaků.
Únik nahých snímků celebrit považovat za připomínku bezpečného využívání on-line služeb.
Přestože jsou servery firem, jako je Apple, Google nebo Microsoft, zabezpečené mnohonásobně lépe než počítače v domácnostech nebo menších firmách, je upload citlivých fotografií v nechráněné formě zbytečné riziko.
Pokud chcete on-line zálohovat explicitní fotografie nebo jakýkoliv jiný citlivý obsah, soubory před uploadem nejprve zašifrujte.
Rozumné je také nastavit automatické zálohování fotografií z telefonu tak, aby probíhalo pouze na wi-fi a po připojení k nabíječce.
Tak budete mít možnost včas citlivé snímky přesunout "do bezpečí", a hlavně budete mít prostor smazat nepovedené snímky, takže nebudou zbytečně zabírat prostor v on-line úložišti.
Návod na to, jak šifrovat soubory i komunikaci na internetu, nabízíme čtenářům HN a IHNED.cz v podobě elektronické knihy od Michala Altaira Valáška ve formátu PDF.
Chytrý způsob, jak ušetřit za vysokoškolská skripta
Vzhledem k tomu, že cena za vysokoškolská skripta pro mnoho studentů přesahuje 1 000 dolarů ročně, přišel nastávající student druhého ročníku s chytrým způsobem, jak snížit náklady.
Vymyslel systém půjčování knížek od spolužáků z vyšších ročníků s nabídkou nominální kompenzace, aby pozdrželi jejich odprodej zpátky.
„Knížku na výpočty, která běžně stojí 180 dolarů, jsem na semestr získal za deset a za kuřecí nugety,“ říká Schroeder, 19, který studuje na Covenant College v Georgii.
Knížky vyžadované v jeho posledním semestru by stály 430 dolarů, říká.
Utratil 120.
Podle univerzitní rady utratí průměrný student za učebnice a pomůcky více než 1 200 dolarů ročně, ale studenti mají různé možnosti, jak tyto výdaje zvládat.
Preferovanou volbou studentů se stávají internetové obchody a kreativní řešení jako je to Schroederovo.
Na vzestupu je půjčování učebnic, což studentům umožňuje semestr knížku používat a to často s výraznou slevou, než kdyby si ji koupili.
Neebo Inc provozující více než 250 knihkupectví v areálech kampusů říká, že půjčování knížek se od roku 2011 zdvojnásobilo.
Průzkum v odvětí ukazuje, že okolo čtvrtiny knih v univerzitních knihkupectvích bylo v minulém jarním semestru půjčených, říká viceprezident Neebo Trevor Meyer.
Méně než polovina učebních textů se podle Národní asociace univerzitních obchodů v univerzitních knihkupectvích kupuje.
Tady je 101 nejlepších způsobů jak uspět.
Nakupování online
Ceny některých nových knížek mohou být na internetu až o třetinu nižší než v univerzitním knihkupectví.
Doporučená cena devátého vydání knížky „Calculus“ Rona Larsona, Bruce Edwardse a Roberta Hostetlera je téměř 290 dolarů, ale na internetu je možné ji na Chegg.com, v maloobchodě specializovaném na učebnice, zakoupit novou za 239,99 dolarů.
Kupovat použité
Pokud vám nevadí poznámky jiných lidí nebo opotřebení a poničení, vhodnou možností jsou použité učební texty.
Na Chegg.com se „Calculus“ prodává za 93,49 dolarů.
Matt Casaday, 25, student vyššího ročníku na Brigham Young University, říká, že na Amazon.com zaplatil za použitý výtisk „Strategic Media Decisions: Understanding The Business End Of The Advertising Business“ 42 centů.
Nový se prodával za 48 dolarů.
Univerzitní vyučující Ingrid Braceyová, vedoucí University of Massachusetts Amherst's College Without Walls navrhuje, aby si studenti u svých vyučujících ověřili, zda jsou starší vydání akceptovatelná.
Někdy nejsou změny pro práci v seminářích podstatné.
Pokud ano, mohou se starší vydání prodávat za zlomek ceny poslední verze.
Kromě Chegg a Amazonu, jsou oblíbenou alternativou pro nákup použitých knih také eBay Inc's Half.com.
Půjčování
Za zvážení stojí také půjčovaní učebnic, pokud s nimi dobře zacházíte, nezapomínáte je vracet a nepotřebujete je mít i po skončení semináře.
Můžete ušetřit až 80 % nákladů za novou knížku.
Student by si například mohl na celý semestr půjčit „Calculus“ za asi dvacet dolarů.
Seznamte se s podmínkami obchodu, ve kterém si knížku půjčujete, a to včetně postihu za poznámky, zvýraznění nebo opotřebení a poškození.
Mějte na paměti: Pokud knihu včas nevrátíte, pokuta může být vyšší než cena nové knížky.
E-knihy
Další možností je opatřit si místo normální knížky e-knihu.
Někdy se tyto knížky v podstatě půjčují v podobě elektronické licence platné po určitou dobu od distributorů jako Amazon.com, Chegg a Barnes & Noble Inc.
Chegg půjčuje „Calculus“ na šest měsíců za přibližně 61 dolarů.
Podle Braceyové tak mohou ty nejvýhodnější nabídky najít studenti literárních kurzů, protože mnoho klasiků je nyní k dispozici ke stažení zdarma, zatímco přírodovědné a technické texty mohou být velmi drahé.
V každém případě choďte po obchodech.
Joe Gault, 29, který brzy nastoupí na Pepperdine Law School, doporučuje řídit se podle ISBN, protože to zaručuje, že kupujete správnou knihu.
Předtím, než si knížku objednáte přes internet, ujistěte se, že je opravdu skladem, radí Gault.
Přesvědčil se o tom na vlastní kůži.
Knížka, kterou si koupil, byla vyprodána na čtyři týdny, a musel zaplatit plnou cenu za knížku z univerzitního knihkupectví.
Bahno, samé bahno.
A pak našli ve studni torzo pušky z konce války
Ta studna stojí kousek od kostela sv. Jiří.
Odkryli jsme porost okolo a začali jsme vytahovat letitý nános - zhruba metr a půl bahna a shnilého listí.
Když jsme se blížili k jílovitému dnu, narazili jsme na hlaveň," líčil Radomil Novák.
Vytáhli jsme ji, očistili a zjistili, že je to torzo útočné německé pušky, kterou používaly jednotky SS.
Nález je údajně neobvyklý.
Podle mých informací se takové pušky vyráběly až ke konci války.
A bylo jich asi tři sta tisíc," dodal Novák.
Všechny dřevěné konstrukční věci se časem rozložily, proto je nepoužitelná.
Její tělo je ovšem zachovalé - drží svůj tvar.
Jak se ve studni ocitlo?
Jedno vysvětlení existuje.
Možná ji tam hodili lidé, kteří se potřebovali zbavit zbraně používané jednotkami SS, pravděpodobně ze strachu, aby nebyli odsunuti.
Fašisté na útěku by to zřejmě neudělali.
Ti odhazovali zbraně v lese," myslí si nálezce.
Puška bylo to jediné, co nadšenci z Hnutí Duha Jeseníky ve studni našli.
"Mohly tam být i ruční granáty, těch tu kdysi byla všude kolem spousta, proto jsme zpomalili výkopové práce, pečlivě jsme prohmatávali bahno, aby se nestalo nějaké neštěstí, ale nic jiného tam dole nebylo," přiblížil Novák.
Nález skončí v depozitáři muzea na zámku v nedalekých Slezských Rudolticích.
Ukrajinský generál: Zajatého Čecha jsem zatím neosvobozoval
Exkluzivní rozhovor Aktuálně.cz s generálplukovníkem Volodymyrem Rubanem, který osvobozuje ukrajinské vojáky ze zajetí proruských separatistů.
Kyjev/Praha - "Promiňte, musím to vzít... volají mně z Doněcka," omluvil se snad osmkrát při exkluzivním rozhovoru s Aktuálně.cz ukrajinský generálplukovník Volodymyr Ruban, jinak také ředitel tamního Centra osvobozování válečných zajatců.
Generálplukovník Volodymyr Ruban v televizní debatě.
Při každém takovém přerušení nebylo možné neslyšet jména lidí, jejich počty či místa, kde jsou - anebo by měli být -, které si Ruban upřesňuje se svým protějškem na druhém konci telefonu.
"To bude ono - jeď tam," zakončil jednu z bleskových diskusí s Doněckem a opět se věnoval té naší.
Volodymyr Ruban je generálem v záloze, někdejší pilot stíhačky a aktivní účastník protivládních protestů na Majdanu.
Ještě včera - když jsme si domlouvali rozhovor - byl v Doněcku.
Osvobozování ukrajinských vojáků ze zajetí proruských separatistů se věnuje čtyřiadvacet hodin denně.
Aktuálně.cz: Možná víte, že na straně proruských separatistů bojují i Češi.
Naše kontrarozvědka odhaduje jejich počet do třiceti.
Může jich být ovšem i mnohem víc.
Už jste se s nějakým českým zajatcem při vašich vyjednáváních setkal?
Volodymyr Ruban: Osvobozoval jsem už zajaté Srby, Dagestánce, Čečence, jednoho Švéda, Gruzínce... ale Čecha zatím ještě ne.
Ale vím, na koho se v Praze obrátit, pokud bychom narazili na vašeho zajatého krajana a mohli ho vysvobodit.
Ukrajinský voják zajatý separatisty
A.cz: Co radíte Čechům, kteří se přidávají k proruským separatistům a ukrajinští vojáci je zajmou?
Měli by pochopit, že pokud jako Češi bojují v ukrajinských praporech dobrovolníků a separatisté je zajmou, tak je po výslechu bez milosti zastřelí, stejně jako kteréhokoliv jiného cizince.
Separatisté považují tyto muže za nájemné žoldnéře a ti si podle nich nic nezaslouží nic jiného než smrt.
Pokud ale například ukrajinští vojáci zajmou skupinu doněckých separatistů - a mezi nimi tedy třeba i Čecha -, tak ho posadí za mříže a jednají s ním jako s válečným zajatcem.
Ten chlap zkrátka přežije.
Ukrajinská strana se chová i ve válce jako stát.
A.cz: A kolik se vám už podařilo zachránit ukrajinských zajatců?
Jestli tomu dobře rozumím, tak výměnou.
Některé zdroje uvádějí, že už to dávno překročilo stovku mužů.
Dávno už jsme přestali počítat, kolika lidem jsme pomohli.
Jenom jsme je ale osvobodili... před válkou nezachránili, pokud se rozhodnou v bojích pokračovat.
Zachránci jsou ve válce lékaři, chirurgové, ale my rozhodně ne.
Tak to je.
A každý den přibývají další a další.
Každý den někoho zachráníme.
Někdy jednoho, jindy čtveřici či pětici.
A nemusí jít vždy o výměnu.
Někdy stačí k propuštění zajatců i pouhá lidská prosba.
A.cz: Proslýchá se, že jste si za několik měsíců získal u proruských separatistů velkou autoritu a dokonce i důvěru... stejně jako v ukrajinské společnosti.
Jak se vám podařilo vybudovat respekt obou válčících stran?
Těžká otázka.
Jeden z důstojníků v Kyjevě mně dal přezdívku "šílený generál s ocelovými koulemi".
Neuráží mě to.
A možná to i vystihuje podstatu naší práce.
Jako šéf ukrajinského Důstojnického sboru jsem si nějakou tu autoritu získal už dříve.
Nikdy nechytračím, nepodvádím a držím vždy slovo.
Ať se děje cokoliv, tak jednám čestně a mluvím pravdu.
Dokonce i tehdy, když je to ukrajinské vládě, anebo té doněcké či luhanské velmi nepříjemné.
Pokud mučí a zabíjejí lidi?
Tak jim jednoduše říkám, že je mučí a zabíjejí.
A že jsou to zločiny.
Často přitom riskuji život, dokonce mě při výměně zajatců i zajali... tahle práce pro mě může kdykoliv znamenat konec... nemusím se vrátit.
A.cz: O kolika popravách a mučení zajatců víte?
... (dlouhá pomlka)... k mučení zajatců se při výsleších uchylují Ukrajinci i separatisté.
Bohužel.
A popravy?
Ty se odehrávají jen na doněcké straně.
O tom, že rovněž ukrajinská armáda popravuje zajatce, nemám informace.
Ani náznaky o tom, že se ukrajinská armáda něčeho podobného dopouští.
O množství poprav máme představu, ale čísla uvádět nemohu a ani nechci.
A.cz: Popište mi charaktery a motivy proruských separatistů.
Jsou mezi nimi důstojníci, ale i veteráni z Afghánistánu.
Snaží se o samostatnost a možná i demokracii v Doněcku či Luhansku - tak to alespoň říkají.
Nechtějí už více hrát hry s ukrajinskými oligarchy.
Separatisté mají už oligarchů plné zuby a jsou jejich nesmiřitelnými odpůrci - na život a na smrt.
Jak my říkáme - přejedli se jich až po hrdlo.
Stejné sny a tužby lidé dávali mimochodem najevo i na Majdanu.
A teď si trochu zaspekuluji: Rusko podporuje separatisty a Západ naopak ukrajinský stát.
Jednu spekulaci považuji za velkou a tu druhou naopak za malou.
Už tahle moje věta ale v sobě skrývá nesmiřitelný rozpor.
A.cz: Jak se vám například jeví jeden z nejtvrdších vůdců proruských separatistů Igor Bezler?
Vždy když překračuji linii válečné fronty, jsem beze zbraně a ukazuji vojákům či ozbrojencům rozpřažené holé ruce.
A vždy mě mají obě strany těch dvě stě či tři sta metrů na mušce či v optickém zaměřovači.
Ty obličeje lidí, kteří na mě míří, pokaždé dobře vidím... a oni mohou kdykoliv zmáčknout spoušť svých zbraní.
Výsadkář, zkušený plukovník s německými i ukrajinskými předky.
Považuje se za ruského důstojníka, avšak jeho rodina - matka - žije na Ukrajině.
Věří, že Ukrajina by neměla existovat.
A jestli ano, tak jen jako malá gubernie ve velkém ruském impériu.
V každém případě o tom neustále hovoří a Ukrajinu považuje za jakési vzniklé nedorozumění.
Takový stát by podle něj ani neměl existovat.
Zároveň je nesmiřitelným nepřítelem všech ukrajinských oligarchů.
A.cz: Když už hovoříme o charakterech - v diskusní show ukrajinské televize jste vašeho premiéra Arsenije Jaceňuka označil za slabého, bezradného a unaveného "vůdce", jenž by udělal nejlépe, pokud by rychle odešel.
Za těch tři sta metrů chůze dostanu vždy alespoň pětkrát strach.
Proč bych se měl tedy tajit s názorem, že Jaceňuk je velmi slabým premiérem a že škodí naší zemi?
A.cz: Má podle vás podíl na válce v Ukrajině?
Možná víte, že Ukrajinci Jaceňuka přezdívají "králíkem".
A králík není v očích Ukrajinců zvířetem, z něhož by šel strach či by mělo u ostatních respekt a autoritu.
Jeho chování přímo kopíruje chování králíka.
Možná je dobrý ekonom, ale jako premiér nemá ve válce právo plakat v parlamentu, prosit ho, hrát s ním jeho intriky, vyhrožovat, že položí funkci... on musí zemi řídit, spravovat ji a v době války i chránit.
Při ohrožení země nemá premiér nárok na rodinu, kamarády, odpočinek na plačtivé emoce.
On je přece prvním z ministrů Ukrajiny.
A Jaceňuk?
Chová se jako pubertální dívka.
Ano, je unaven, ale také slabý, protože nebyl nikdy silný... nebojuje za Ukrajinu, jen si neustále na vše stěžuje.
Měl by proto odejít.
Čím dříve, tím pro Ukrajinu lépe.
Proč Strážci galaxie nedokázali zachránit tržby
Postradatelní 3 Sylvestera Stallonea vrátili z devadesátimilionového rozpočtu v USA méně než 30 milionů dolarů a Sin City: Ženská, pro kterou bych vraždil vrátil ze sedmdesátimilionového rozpočtu jenom 12 milionů.
Film Sex Tape s Cameron Diaz během prvního víkendu vydělal pouze 14,6 milionu dolarů a také filmy pro děti jako Jak vycvičit draka 2 byly pro kina zklamáním.
Podle článku filmového kritika Robbieho Collina v Telegraphu je, co se dětských filmů týče, na vině jejich samotná kvalita.
Collin označil rok 2014 jako „nejhorší“ rok dětských filmů a Jak vycvičit draka 2 nazval pouhým „funkčním“ pokračováním.
Když přijde na filmy nasazené na trochu starší cílovou skupinu, zdá se, že problém nutně nemusí být v kvalitě samotných filmů.
V červenci porovnal Entertainment Weekly servery CinemaScore a Metacritic a jejich průměrné hodnocení letních filmových premiér vysílaných alespoň ve 2 000 kinech v období mezi Dnem obětí války a 20. červencem v roce 2013 a v tomto roce.
Výsledky, které berou v úvahu názor diváků i filmových kritiků, naznačují, že letošní filmová úroda je podobné kvality jako loňské hity.
Podle některých komentátorů může být na vině změna v přístupu diváků a vyšší popularita internetových serverů jako Netflix.
Režisér Jon Favreau, který v současné době pracuje na Disneyho zpracování Knihy džunglí, webové stránce Hollywood Reporter sdělil: „Myslím, že časy se mění.“
Musíme si to připustit a nesnažit se honit se za tím, co už bylo.
Na rozdíl od současné krize hollywoodských kasovních trháků dosáhl zisk Netflixu díky internetovým službám 1,2 miliard dolarů, což je téměř dvakrát víc než loňských 837 milionů dolarů.
Minulé léto kritizoval režisér Steven Spielberg studia za to, že se příliš spoléhají na práva ke komiksům, a předpověděl „zhroucení“ Hollywoodu.
Ve světle současného propadu prohlašují někteří komentátoři, že na jeho katastrofické věštbě může něco být.
S uvedením možných velkých kasovních trháků v létě 2015 včetně Avengers: Age of Ultron, Mimoňů a Jurského světa, jsou ve filmovém průmyslu jiná čísla optimističtější.
Producent X-Men Simon Kinberg nedávno označil pokles v tržbách za jednoduše „cyklický“. Pro Hollywood Reporter řekl: „Příští léto bude létem největších kasovních trháků v historii a nikdo si nebude dělat starosti s prodejem.“
KLDR opět hrozí Soulu, odpálila další raketu krátkého doletu
Severní Korea odpálila do moře další raketu krátkého doletu, oznámil Soul.
Údajný test rakety se uskutečnil krátce po ukončení společných vojenských manévrů Spojených států a Jižní Koreje, které Pchjongjang vnímá jako přípravu na invazi.
Provincie Čagang leží na severozápadě KDLR při hranicích s Čínou.
Mluvčí jihokorejského ministerstva obrany podle agentury DPA uvedl, že střely byly odpáleny z místa na severozápadě KLDR a doletěly do vzdálenosti zhruba 200 kilometrů.
Severní Korea tak zřejmě poprvé odpálila raketu z provincie Čagang, uvedla jihokorejská média s odvoláním na armádní kruhy.
V provincii se prý nachází podzemní odpalovací rampa pro rakety typu Scud.
Jde o další ze série podobných zkoušek, které izolovaný severokorejský režim provedl v posledních týdnech.
Severní Korea letos uskutečnila nezvykle velké množství testů raket a dělostřelectva.
Summit NATO: První protesty v Newportu a Cardiffu
Během víkendu proběhly protesty odpůrců summitu NATO v Newportu.
V sobotu se stovky lidí shromáždily v centru Newportu, aby se zúčastnily pochodu proti NATO.
A v neděli asi 150 lidí přišlo na radnici v Cardiffu na setkání, které bylo popsáno jako proti-summit.
Stephen Fairclough sledoval během víkendu situaci a mluvil s protestujícími, kteří přicestovali z Bridgend do Belgie.
Teenageři museli být letecky přepraveni z Blue Mountains
DVA mladiství turisté byli vyzvednuti letadlem a převezeni do bezpečí poté, co strávili noc v Blue Mountains v Novém Jižním Walesu.
Šestnáctiletá dívka a osmnáctiletý muž se po nedělním poledni vydali na túru do Govetts Leap v Blackheathu.
Když se nevrátili domů, znepokojení příbuzní zavolali kolem osmé hodiny večer policii.
Byla vyslána pátrací četa včetně místní policie a záchranný tým a pár byl okolo jedenácté hodiny večer nalezen poblíž Bridal Veil Falls.
Dívka si poranila koleno a muž spadl a přitom se uhodil do hlavy.
Policisté s nimi zůstali přes noc a v pondělí ráno byli vyzvednuti.
Ve stabilizovaném stavu byli sanitkou převezeni do Blue Mountains Hospital.
Olomouc přivezla z Opavy jen bod, výhru měl na noze Vašíček
Právě 23letý forvard mohl rozhodnout, ve dvou největších šancích ale neuspěl.
Po gólu volala hlavně střela zblízka tři minuty před koncem, místo v síti ale skončila na brankáři Opavy Josefu Květoňovi.
Měl jsem to na noze, takové šance musím dávat.
Sám na sebe jsem naštvaný," sypal si Vašíček popel na hlavu.
"Asi jsem to měl dávat výš pod víko, trochu mi to sjelo," přemítal.
Defenzíva Sigmy toho Opavě moc nedovolila, výjimkou byl Mikulův nájezd z 11. minuty, který však pokryl gólman Reichl.
Pak už začali tlačit Hanáci, do šancí je ale v bloku bránící domácí nepouštěli a střely z dálky pochytal Květoň.
Patnáct minut jsme se srovnávali, pak jsme převzali iniciativu.
Ve druhém poločase jsme už byli lepší, měli jsme více ze hry a Opava nás ohrožovala jen ze standardních situací.
Ale vyloženou šanci Vašíček neproměnil, a tak to skončilo 0:0," mrzelo trenéra Hanáků Leoše Kalvodu.
Opava bod brala i kvůli absencím v sestavě, kde kromě dvojice zraněných chyběli i Petr Vavřík s třígólovým střelcem Petrem Ševčíkem, kteří ve Slezsku hostují ze Sigmy.
Ta jim na rozdíl od své dřívější politiky neumožnila nastoupit.
Náhradníci si zaslouží absolutorium.
Sigma působila fotbalověji, ale až na jednu standardku jsme ji k ničemu nepustili," mínil trenér Slezanů Petr Baránek.
Bylo k vidění hodně důrazu, agresivity a bojovnosti.
Remíza je asi zasloužená, bod je pro nás slušný zisk," dodal.
Sigma se remízou dostala na čtyři body, což znamená třinácté místo.
Nic, co by mohlo uspokojit šéfa klubu Josefa Lébra, který po porážce se Znojmem podmínil svůj milionový vklad do pokladny diametrálně rozdílnými výkony v dalších zápasech.
"Uvědomovali jsme si varování pana Lébra, takže nemůže být řeč o tom, že by kluci nechtěli bojovat," všiml si Kalvoda a na adresu spícího střelce Vašíčka dodal: "Věřím, že to přijde a až dá gól, tak mu to tam začne padat.
Ale po první trefě ho hned vystřídám, aby si góly šetřil i na další zápasy," smál se Kalvoda.
Al Pacino dvakrát nadchl Benátky.
Filmový festival jinak prožívá krizi
Po obrovském nadšení nad zahajovacím filmem Birdman, jehož režisér Alejandro González Iňárritu se rázem zařadil mezi vážné kandidáty na Zlatého lva, další dny nasvědčovaly dojmu, že zájem o 71. ročník festivalu v Benátkách poněkud opadl.
Ať už proto, že počet míst v největším sále se zvýšil na čtrnáct set, nebo proto, že po Birdmanovi následovaly kritiky uznávané, ale pro diváky méně přitažlivé snímky jako dokument o genocidě v Indonésii 60. let Pohledem ticha a jiné filmy se sociální tematikou od amerických 99 domovů po íránské Povídky, v kinech zkrátka zůstávala prázdná sedadla.
Hrdinové z komiksů
Dokonce ani červený koberec před festivalovým palácem neobléhaly zatím takové davy jako v minulosti a údajně přestalo být problémem sehnat na poslední chvíli místo v hotelu.
O krizi se v Itálii mluví více než jinde a není divu, že postihla i tak vážené instituce jako Biennale a nejstarší filmový festival na světě.
Naštěstí se krize neprojevuje nedostatkem osobností, přítomných však výhradně v souvislosti s filmy.
Zatímco mladší fanoušci toužili po autogramech představitelů komiksových superhrdinů Michaela Shannona a Andrewa Garfielda, kteří se v 99 domovech vcelku úspěšně zhostili dramatických rolí, pro všechny generace bez rozdílu se stala hlavní událostí návštěva legendárního herce Ala Pacina.
Zazářil tu navíc hned ve dvou filmech.
V příběhu Prozření uváděném mimo soutěž, který natočil oscarový Barry Levison podle románu Philipa Rotha, má čtyřiasedmdesátiletý Pacino roli, jež je mu blízká: herce na vrcholu slávy, který trpí depresemi z konce kariéry i osobního života.
Ale vidět ho hned druhý den jako podivínského majitele železářství z venkovského městečka ve filmu Manglehorn, jejž natočil David Gordon Green, to byl opravdu nezapomenutelný zážitek.
Volpiho pohár za nejlepší herecký výkon by ho neměl minout - ale má ještě umělec Pacinova formátu zapotřebí cen?
Možná je pro něj největší satisfakcí láska publika, a toho italského zvláště, neboť ačkoli se narodil v New Yorku, hlásí se Al Pacino hrdě k zemi, ze které pocházejí jeho prarodiče.
Body pro Italy
Ostatně právě italský film si letos vede v Benátkách velice dobře.
Černé duše, které režíroval Francesco Munzi, se staly po Birdmanovi prvním snímkem odměněným dlouhým potleskem vstoje.
Kalábrijská odnož mafie je v něm nahlížena pohledem na rodinné vztahy mezi klany, které vzájemně bojují o moc i peníze, a režisér dokázal sladit všechny předpoklady pro dobrý film: kvalitní scénář, kameru, hudbu a herce.
Zaujal také komorní psychothriller Hladová srdce, který natočil Saverio Costanzo s Albou Rohrwacherovou v úloze ženy, jež svou scestnou úzkostlivostí málem zahubí vlastní dítě.
Naopak z francouzských soutěžních filmů se nedočkaly vřelého přijetí ani Výkupné za slávu, ani 3 srdce, obě díla ulpívající na tradičním modelu konzumních filmů, které se opírají o popularitu hereckých představitelů.
Ale koneckonců, dva opravdu výtečné filmy, tedy Birdman a Černé duše, nejsou na první polovinu festivalu tak málo.
A třebaže festivalové snímky mají vesměs depresivní náměty, nový snímek Petera Bogdanoviche s názvem She's Funny That Way, vtipná komedie uvedená v Benátkách mimo soutěž a natočená ve stylu amerických veseloher 40. let, dokázala pozvednout náladu na víc než jeden den.
Policisté chytili v Praze čtyři výrobce pervitinu, léky vozili z Polska
"Detektivové zadrželi v uplynulých dnech tři muže ve věku 42, 42 a 37 let a pětadvacetiletou ženu, kteří od loňského listopadu až do letošního srpna vyrobili a prodávali drogu pervitin na Praze 9," uvedla policejní mluvčí Jana Rösslerová.
Nejprve v úterý 12. srpna zásahová jednotka v Cihlářské ulici chytila dvaačtyřicetiletého organizátora a dealera v jedné osobě a mladou ženu, která ve skupině figurovala jako nákupčí léků v Polsku a prodejkyně dávek.
Následující den detektivové zadrželi na základě předchozího souhlasu státního zástupce dalšího člena skupiny, a to sedmatřicetiletého muže.
Posledního ze čtveřice policisté dopadli ve středečních ranních hodinách 20. srpna v areálu malešické spalovny," popsala mluvčí.
Za převoz léků z Polska dostávala žena třetinu drogy
Hlavní organizátor měl široké pole působnosi.
V dílně letenského areálu, v zahradním domku v Horoměřicích, v bytě v Koněvově ulici a na dalších místech na Praze 9 vyráběl pervitin, opatřoval různé pomůcky a chemikálie potřebné k jeho výrobě a zajišťoval převoz léků s pseudoefedrinem z Polské republiky.
Dále vyrobenou drogu vážil, rozděloval do plastových sáčků a pervitin následně prodával.
S převozem léků z Polska nebo prodejem narkomanům mu vypomáhala pětadvacetiletá, dosud netrestaná žena.
Za to dostávala od organizátora odměnu v podobě třetiny vyrobené drogy," dodala Rösslerová.
Kriminalisté provedli na základě příkazu soudce také několik domovních prohlídek, kde zajistili drogu, průmyslové chemikálie, digitální váhy, platové sáčky, injekční stříkačky, hadičky a další pomůcky a předměty, které lze podle expertiz považovat za kompletní výbavu pro výrobu metamfetaminu.
Dealer byl od roku 1995 trestán už sedmkrát
"Z dostupných evidencí pak policisté zjistili, že hlavní organizátor byl od roku 1995 celkem sedmkrát soudně trestaný za majetkovou trestnou činnost, žena soudně trestaná nebyla," doplnila policejní mluvčí.
Poslední zadržený byl v roce 2006 podmíněně odsouzený za trestný čin pohlavní zneužití a sedmatřicetiletý automechanik, který je stíhaný na svobodě, byl od roku 2009 devětkrát soudně trestaný.
I u něj to to bylo převážně za majetkovou trestnou činnost.
Vyšetřovatel obvinil tři muže a ženu ze spáchání trestného činu nedovolená výroba a jiné nakládání s omamnými a psychotropními látkami a jedy, za což jim hrozí až desetileté vězení.
U tří osob nakonec podal vyšetřovatel státnímu zástupci i podnět k návrhu na uvalení vazby, kam je nakonec soudce umístil," řekla mluvčí.
Čtvrtý obviněný, sedmatřicetiletý recidivista, skončil na svobodě.
Jeho postavení a úloha v tomto případě nebyla až tolik zásadní jako u ostatních obviněných.
Policisté s tímto mužem i tak nadále pracují.
Ferrari nabízí šachy ze dřeva a karbonu.
Ferrari nabízí v rámci svých dalších produktů velmi zajímavé věci za hodně "zajímavé" ceny.
Jako dobrý příklad poslouží třeba v Itálii ručně vyrobené šachy s hrací deskou o velikosti 42 x 42 cm.
Pokud se vám líbí, připravte si více než 40 000 Kč.
Přesná cena činí 43 405 Kč.
Zákazník získá sadu dřevěných černě a červeně lakovaných figurek uložených v dřevěné krabici potažené karbonovými vlákny.
Asi nikoho nepřekvapí, že místo klasického jezdce mají hráči k dispozici figurku vzpínajícího se koníka.
Pokud se vám šachy nezdají jako dostatečně hodnotný dárek, je k dispozici také třeba model Ferrari 500 F2 vyrobený (samozřejmě ručně) v měřítku 1:1,8.
Cena této hračky činí 318 305 Kč.
Rušení gymnázií a středních škol nedává smysl.
Česko má málo všeobecně vzdělaných lidí a statistiky navíc ukazují, že gymnazisté mají dobré uplatnění.
Začátek školního roku je tu.
Ve školách v posledních čtrnácti dnech probíhaly velké přípravy.
Většinou jde o rutinní záležitosti, jako třeba přenést květináče z letního úložiště zpět do tříd a nafasovat křídy.
Na hořickém gymnáziu budou mít trochu větší frmol.
Pár dní před začátkem sezony shánějí nábytek, počítače a další technické vybavení i literaturu do knihovny.
Nedošlo k loupeži ani zpronevěře, čtyřleté gymnázium v Hořicích po třech letech otevírá a obnovuje svoji činnost.
Nikoliv na veřejné, ale na soukromé platformě.
Nedostatek materiálního vybavení není způsoben tím, že by zakladatelé byli tak neschopní.
Museli čekat na to, zda bude existence školy potvrzena zanesením do rejstříku škol spravovaného MŠMT.
„Francouzští socialisté by měli sklapnout a dát Francii do pořádku,“ říká klíčový spojenec Francoise Hollanda
Valls vyzývá silně roztříštěnou levici, aby „ukázala svou podporu“ bojovně naladěnému socialistickému prezidentovi, jehož nové rozdělení funkcí se nesetkalo se souhlasem většiny Francouzů.
Prezident si zaslouží všeobecný respekt, zaslouží si loajalitu, zaslouží si naši podporu.
„Naše povinnost je zůstat mu po boku,“ řekl a sklidil potlesk.
Jako smířlivé gesto trval předseda vlády na tom, že jeho vláda nebude zpochybňovat kontroverzní francouzský třicetipětihodinový pracovní týden a to navzdory vášnivým dohadům ze strany Emmanuela Macrona, nového ministra financí, který na začátku týdne navrhl, aby se pravidla uvolnila.
V sobotu Hollande žádal socialisty, aby zůstali „soudržní“ s vládou.
Christiane Taubirová, ministryně spravedlnosti, mu ale udělala čáru přes rozpočet, když se objevila na setkání rebelujících socialistických poslanců, kde Socialistickou stranu kritizovala za to, že kvůli ní „Francouzi ztratili víru v budoucnost.“
Marine Le Penová, lídryně extrémně konzervativní pravice, se neustálým vnitřním sporům mezi socialisty vysmála, když prohlásila, že nepředpokládá, že nová Vallsova vláda vydrží déle než pár měsíců.
Císař Francois Hollande je nahý a princ Manuel Valls také. Byli donuceni sestavit novou vládu, když ta předchozí nevydržela ani do konce léta.
„A nová nevydrží do konce podzimu nebo zimy,“ řekla Le Penová svým příznivcům.
Znovu zopakovala výzvu své strany k rozpuštění Parlamentu a prohlásila, že je přesvědčená, že by to straně mohlo vyhrát předčasné volby a že je připravena řídit zemi.
Francouzská vládnoucí strana utrpěla v březnových komunálních volbách porážku a v květnu extrémně konzervativní pravice uspěla ve volbách do Evropského parlamentu.
Podle průzkumu veřejného mínění týdeníku Journal du Dimanche si 76 procent Francouzů myslí, že Socialistická strana se vystavuje riziku, že se rozdělí na několik soupeřících frakcí ještě před koncem Hollandova funkčního období v roce 2017.
Pascal Perrineau, politolog Univerzity Sciences Po, varoval, že Francouzům brzy dojde trpělivost, pokud se nové socialistické vládě nepodaří zlepšit ekonomiku a snížit rekordní nezaměstnanost.
„Je to omezený prostor pro příležitost, ale veřejné mínění si musí myslet, že v situaci dochází ke změnám,“ varoval.
Jinak by se situace mohla ještě zhoršit.
Hazard a pouliční umění už Praha do voleb neomezí
Změny příslušných vyhlášek by mělo připravit a schválit až nové vedení hlavního města.
Z ulic Prahy nezmizí před komunálními volbami další herny a město nebude omezovat pouliční umění.
Omezeno nebude ani venčení psů.
Praha nestihne do říjnových voleb připravit a schválit v zastupitelstvu změny příslušných vyhlášek.
"Rozhodnutí o změnách by navíc nemělo dělat současné vedení města, kterému končí za několik týdnů mandát," řekl radní Lukáš Manhart (TOP 09).
Zrušit plošně hazard na svém území se v uplynulých týdnech rozhodlo hned několik radnic, například Prahy 5 a 7.
Herny ale nezmizí, vyhláška o hazardu se měnit zatím nebude.
Je to úkol nového vedení města po volbách.
Nyní bychom to ani technicky nestihli vzhledem například k lhůtám na podání připomínek a podobně," vysvětlil Manhart.
Dodal, že poslední jednání současného zastupitelstva, které musí změnu vyhlášky schválit, se uskuteční 11. září.
Referendum o plošném zákazu hazardu chystají v den komunálních voleb městské části Praha 1 a Praha 8.
V současné době platí zákaz hazardu například v Praze 2 či Praze 12.
Vyhláška se ze stejných důvodů nebude měnit ani v případě pouličního umění, takzvaného buskingu.
Na ten si stěžuje zejména Praha 1, která již poslala magistrátu návrh míst, o která by chtěla současný seznam zakázaných míst rozšířit.
Hudebníky nechce rovněž Praha 5 v okolí Anděla.
Vyhlášku regulující venčení psů město chystá několik měsíců, zatím není dokončena.
Umístění heren i problematiku buskingu řeší městské vyhlášky.
Může je vydávat či upravovat pouze zastupitelstvo hlavního města.
Radnice mají jen poradní hlas, samy vydávat vyhlášky nesmějí.
Minulý týden umístil vítězství proponentům skotské nezávislosti na dosah ruky
Kampaň za skotskou nezávislost byla v nebezpečí, že tuto chybu udělá napotřetí, když málem umístila na billboardy po celém Skotsku otázku, zda chtějí Skoti být bohatí.
Jenže k srdcím skotských voličů se nedostanete tím, že budete apelovat na jejich peněženku, ani si nezískáte jejich respekt, když jim začnete vyhrožovat.
Morálka Nového zákona je ve Skotsku stále živá, i když jen málo Skotů ještě chodí i dnes do kostela.
Skoti mají daleko větší tendenci vyhnat směnárníky z chrámu, než aby si nechali od nich diktovat, jak mají hlasovat.
Šéf skotských nacionalistů Alex Salmond tohle dobře ví, a proto se v televizní diskusi opakovaně dotazoval svého soupeře, unionistického Darlinga, zda je ochoten respektovat "suverénní vůli skotského lidu", pokud by skotští voliči hlasovali pro nezávislost, a začít podporovat jednotnou měnu pro Skotsko i pro Anglii.
To Darlinga donutilo, aby volil mezi skotskou občanskou společností a londýnskými finančníky, a s grimasou padl do této pasti.
Samozřejmě, že Darling nepodpoří mandát skotských voličů.
Avšak ta diskuse o tom, jakou bude mít Skotsko měnu, byla už víceméně neutralizována.
Co opravdu motivuje skotské voliče je férovost, pracovní příležitosti a obrana státního zdravotnictví, které mají občané zadarmo.
Darling ve věci měny podpořil londýnské bankéře a vyvolal také dojem, že nebude protestovat proti privatizaci zdravotnictví.
Tím, jak to řekl Salmond, "vlezl do postele s konzervativci".
To je pro každého skotského politika velmi nebezpečné postavení.
Každý skotský volič ví, že skotští podnikatelé jsou v posteli s konzervativci.
To potvrdil David Cameron, který ve Skotsku promluvil nikoliv k voličům, ale k asociaci "bossů", ke Konfederaci britského průmyslu.
Začíná být jasné, že Cameronovo odmítnutí debatovat o nezávislosti se skotským premiérem Salmondem bylo pro unionistickou kampaň vážným omylem.
Cameron tak vypadá jako zbabělý absentující domácí.
Skoti by ho respektovali, kdyby přijel na debatu se skotským premiérem.
Cameron aspoň dokázal říct, že Skotsko může být "úspěšnou nezávislou zemí".
Alistair Darling nedokáže nic takového říct, působí mu to téměř fyzickou bolest.
To, co sděluje, je jasné: Skoti si nemají vyskakovat a musejí přijmout to, co je.
Nejdelší rok má 10 měsíců.
Pesimistický začátek školy podle Miloše Urbana
Ilustrace k povídce Nejdelší rok
Miloš Urban Nejdelší rok
Konec byl z prázdnin vůbec nejlepší, ten poslední týden, co se už nikam nejelo a jenom jsme se povalovali a povlávali s babím létem, ticho před bouří, klid před stresem.
Nové oblečení, když se dalo sehnat z Tuzexu, botky z východního Německa.
Čtení Rychlých šípů, už popadesáté, svištění na kole horem kolem Imperialu až dozadu za Vary, někam k tenisovým kurtům, už nebylo vedro, slunce hladilo záda a ramena, poklepalo paprsky na rozloučenou.
Večer mírná nervozita, pořád ještě prázdninový režim, spát až v půl jedenácté, za týden bude hůř, chvíle před usnutím se protáhnou z pár minut na dvě hodiny, ráno pak vstávat v půl sedmé.
Přijde pondělí.
Většinou neprší, naopak, léto se zlomyslně pošklebuje před školou.
Připloužit se v přízračném světle na plácek a připadat si jako plastová postavička ve skleněném těžítku, je tam ta škola, ZDŠ A.
Zápotockého s obludně růžovou omítkou, a před ní staré známé obličeje i pár nových, kluci vytáhlejší, holky prsatější.
Tamhle jsou grázlové, těm se vyhnout, stejně je zajímavé, jak neomylně drží pospolu a jak jsou tady brzo.
A tyhle dospěle vypadající holky, jež přišly zakřiknuté, se teď něčemu hystericky smějí, asi se v jejich životě přes prázdniny něco změnilo, zatímco u mě je všechno při starém.
A zas noví prvňáci, někteří nervní a jiní natěšení, proč sem vůbec lezou?
Protože musí, vzdělávací vojnou povinní.
Tak tedy dovnitř, chladná vlhkost podlahy a lehký pach dezinfekce, otrávený školník s mopem, bohužel pořád ten samý, co prý zapůjčí žáku klíček od plechové skřínky, kde se dají nechávat učebnice a kterých je pořád tak málo.
Za flašku.
Smrad šaten zůstává v paměti, nyní se nekoná, je pěkně vyvětráno, ale za týden bude hůř.
Už jenom z té představy se svírá žaludek a začíná bolet hlava.
Hlava, která ještě hůř pojme učivo z matematiky, té ďábelské hry pro vyvolené, mezi něž nepatřím a nikdy nebudu.
Zase ty trojky a čtyřky, nedejbůh pětky, schovat se před zkoušením, zapadnout do lavice a nejlépe vysublimovat, být tam i nebýt, existovat jen jako jméno v třídnici a snít si zatím příběhy o milejších holkách a hezčích budovách, o anténách do vesmíru, kde nikdo s nikým nesoutěží, nikoho neponižuje a nikomu nepodráží nohu.
Nejdelší rok má deset měsíců.
A je teprve den prvý, teď jako před lety.
Narozené dcery nechala zemřít.
Hrozí jí až výjimečný trest - Novinky.cz
K prvnímu porodu došlo v březnu 2012 v kabince veřejných toalet na autobusovém nádraží v Jihlavě.
Bez cizí pomoci se jí narodila holčička, kterou po přestřižení pupečníku zabalila do připravené deky, schovala pod bundou a odnesla k silničnímu přivaděči, kde ji odložila do keřů nacházejících se několik desítek metrů od silnice.
Rodila cestou do školy
Přišlo to na mne asi trochu dřív.
Byla jsem na cestě do školy.
V autobuse jsem měla potřebu jít na záchod, tam jsem porodila.
Narodila se živá, koukala na mne.
Pupečníkovou šňůru jsem přestřihla nůžkami, které jsem nosila do školy," popsala obžalovaná a uvedla, že se za těhotenství prý styděla.
"Následujícího dne se na místo vrátila, tělo dítěte vložila do batohu a odvezla, tělo vyjmula z batohu, zabalila do černého igelitového pytle a ukryla a zanechala pod schodištěm v domě své babičky v Havlíčkově Brodě," stojí v žalobě s tím, že není zcela zřejmé, kdy došlo k smrti novorozence.
Mohlo to být za desítky minut, ale i několik hodin po porodu, udušením při zakrytí dekou nebo při vložení pod bundu, podchlazením či vykrvácením z nepodvázaného pupečníku.
Obdobný scénář se opakoval příští rok na jaře.
Žena v blíže nezjištěné době od února do 12. dubna, kdy byla mrtvolka dítěte nalezena náhodnými svědky pod křoviskem u rybníka na Havlíčkobrodsku, zase sama tajně porodila.
Tentokrát v koupelně podkrovního bytu v rodinném domě.
Aniž si ověřila, zda se narodilo živé, aniž přestřihla a podvázala pupečník, který byl obtočený okolo krku, vložila dítě do několika plastových obalů včetně igelitové tašky a nechala ho v koupelně.
Následně v odpoledních hodinách ho spolu s tehdejším partnerem odvezli k rybníku.
Nakonec ji udal přítel
Otcem obou dětí byl právě přítel obžalované, který ale údajně o těhotenstvích partnerky nevěděl.
I z toho důvodu nestojí nyní před soudem, pouze byl potrestán za prohřešek proti zákonu o pohřebnictví.
Byl to také on, kdo se později obrátil na policii.
Nelíbí se mi, že není potrestán jako spoluviník.
S dítětem manipuloval proti mému přání.
Vím, že moje řešení nebylo správné, ale přišlo mi v tu chvíli jako lidské," neskrývala rozhořčení obžalovaná, která údajně ve vztahu muži podléhala a bála se ho.
V průběhu své výpovědi hovořila mladá žena poměrně vyrovnaně.
Slzy do očí jí vehnal až okamžik, kdy hovořila o vztahu k rodičům, od nichž po dosažení plnoletosti sama odešla.
Nechtěla prý zabíjet
"Jezdí za mnou každých 14 dní na návštěvu, dělají pro mne úplně všechno, i když vím, že si to nezasloužím," vzlykla.
Nepořizovala jsem si výbavičku, protože jsem děti nechtěla, připadala jsem si mladá.
Furt jsem ho chtěla dát do babyboxu, ale nevím, co se stalo, že jsem tak neudělala.
To vám vysvětlit nedokážu," odpověděla na dotaz soudci.
Odmítla však, že by jednala s rozmyslem a úmyslem novorozence zabít.
Druhé dítě se podle jejího tvrzení navíc narodilo mrtvé.
Ani v těhotenství ale nepřestala pít alkohol.
Omezila jsem to však.
A nepila tvrdý.
I kouření jsem omezila," uvedla.
Ačkoliv na ní těhotenství bylo v obou případech vidět, všem i na opakované dotazy tvrdila, že má zdravotní potíže, že je zavodněná.
A to i příteli.
Hlavní líčení bude u hradeckého soudu pokračovat v úterý výpověďmi soudních znalců.
Ve středu by již mohl být vynesen rozsudek.
Žena je ohrožena trestní sazbou až 18 let vězení, případně i trestem výjimečným.
Norwegian Cruise se blíží třímiliardovému odkoupení společnosti Prestige Cruise
Podle zdrojů seznámených s celou záležitostí, pokročila společnost Norwegian Cruise Line Holdings s.r.o. (NCHL.O), třetí největší provozovatel výletních plaveb lodí na světě, ve vyjednávání o koupi Prestige Cruises International Inc. přibližně za tři miliardy dolarů.
Obchod by Norwegian Cruise, společnosti s tržní hodnotou 6,8 miliard dolarů, která soupeří s větší konkurencí Royal Carrebian Cruises s.r.o. (RCL.N) a Carnival Corp (CCL.N), umožnil přístup k luxusním výletním lodím Prestige Cruises a bohaté klientele.
Dohoda může být zveřejněna již tento týden, prozradil v neděli zdroj, ale upozornil, že jednání stále nemusí skončit úspěšně.
Majitel Prestige Cruises, soukromé investiční společnosti Apollo Global Management LLC (APO.N), vlastní také dvacetiprocentní podíl v Norwegian Cruise.
Zdroje si nepřály být jmenovány, protože jednání nejsou veřejná.
Představitelé Norwegian Cruise a Prestige Cruises na žádosti o komentář neodpověděli, mluvčí Apollo odmítl situaci komentovat.
Norwegian Cruise se sídlem v Miami provozuje třináct výletních lodí na plavbách v Severní Americe, Středozemním moři a Baltském moři, Střední Americe a Karibiku.
Příjem firmy v roce 2013 byl 2,57 miliard dolarů, o 13 % více než v roce 2012.
Prestige Cruises působí pod značkami Oceania a Regent, které dohromady vlastní osm výletních lodí plujících do Skandinávie, Ruska, Středozemí, Severní Ameriky, Asie, Afriky a Jižní Ameriky.
Společnost v roce 2013 oznámila tržby ve výši 1,2 miliardy dolarů, o 6 % více než v předchozím roce.
Očekává se, že devětadvaceti miliardový segment výletních plaveb bude v nadcházejícím roce profitovat ze vzestupu střední třídy v rostoucích ekonomikách jako je Čína a Indie.
Společnosti soutěží o to, aby se u těchto zákazníků staly preferovanou možností při výběru výletních plaveb.
Společnost Prestige Cruises u amerických regulačních úřadů registrovala první veřejnou nabídku v lednu 2014.
Apollo má ve společnosti většinový podíl od roku 2007 od uzavření obchodu v hodnotě 850 milionů dolarů.
Norwegian Cruise existuje ve své současné podobě od roku 2000, kdy došlo ke sloučení s provozovatelem výletních plaveb vlastněným Genting Bhd (GENT.KL), konsorciem podniků zabývajících se trávením volného času a kasiny, které kontroluje malajsijský miliardář Lim Kok Thay.
V roce 2008 investovalo Apollo do Norwegian Cruise jednu miliardu dolarů.
Společnost Norwegian Cruise uvedla akcie na burzu v lednu 2013.
Podle registrace u regulačních úřadů ke konci června vlastnil Genting kapitálový podíl 28 %, Apollo 20 % a soukromá investiční společnost TPG Capital LP 8 %.
Podle registrační dokumentace první veřejné nabídky zahrnují Carnival, Royal Caribbean Cruises a Norwegian Cruise dohromady 82 % objemu severoamerických pasažérů.
Prodemokratičtí aktivisté v Hongkongu den po rozhodnutí o hlasování provokují čínské úřady
Poblíž postávala skupina lidí loajálních k Pekingu, kteří mávali čínskou vlajkou.
Stálá komise Národního lidového kongresu v neděli schválila, aby se voleb v roce 2017 v Hongkongu zúčastnili pouze dva ze tří kandidátů.
Všichni kandidáti musí nejdříve získat podporu jmenovací komise, která se bude pravděpodobně skládat ze členů věrných Pekingu.
Kvůli tomuto rozhodnutí je pro opoziční demokraty téměř nemožné dostat se na volební lístky a přimět pro-demokratické aktivisty obnovit slib a ochromit finanční centrum Hongkongu protesty hnutí „Okupace Centrálu“.
V Hongkongu je politická reforma hlavním důvodem napětí, čínští vedoucí představitelé se obávají, že požadavek na demokratizaci se rozšíří do dalších měst.
Poté, co Peking v červnu zveřejnil podrobnou zprávu nastiňující čínskou úřední pravomoc v Hongkongu, demokratičtí aktivisté uspořádali neoficiální referendum o volbách ve zvláštním úředním obvodu a stovky tisíc lidí vpochodovaly do městské obchodní čtvrti a obsadily ji.
Tiskovou konferenci, na které vystoupí premiér Li, organizuje vláda v Hongkongu a čínský styčný úřad v Hongkongu.
Během dne měli na několik tiskových konferencích promluvit také místopředseda Stálého výboru Legislativní komise Zhang Ronghsun a náměstek ředitele Státní rady Úřadu pro záležitosti Hongkongu a Macau Feng Wei.
Studenští aktivisté prohlásili, že se odpoledne shromáždí před kanceláří vlády Hongkongu.
Do posledních dní koloniální vlády před 150 lety se Británie nikdy o demokracii v Hongkongu nezmínila.
Putin žádá Kyjev, aby s východní Ukrajinou zahájil jednání o „státní suverenitě“
Podle popisu událostí ruskými novinami požádal v neděli ruský prezident Vladimír Putin, aby ukrajinská vláda zastavila boje se separatisty na východě země a okamžitě zahájila jednání o „státní suverenitě“ odtržených oblastí.
Jeho mluvčí Dmitrij Peskov později vysvětlil, že Putin svou poznámkou neměl v úmyslu naznačit, že oblasti východní Ukrajiny pod kontrolou separatistů se stanou součástí Ruska, ale že jejich status v rámci Ukrajiny by měl být přehodnocen, aby rusky hovořící oblast dostala pravomoc k ochraně svých práv a zájmů.
Putinova výzva kyjevské vládě, aby jednala s proruskými povstalci jako se sobě rovnými, odpovídá zjevné strategii, podle které se řídí od vypuknutí nepokojů před pěti měsíci: Pomozte separatistům obsadit území a donuťte ukrajinskou vládu udělit nově vyhlášenému Novorusku faktickou nezávislost, aby se místo se Západem mohl spojit s Ruskem.
V rozhovoru pro první kanál státní televize Putin odsoudil ukrajinské vojenské akce, které mají znovu získat východní oblasti Doněcka a Luhansku, které v březnu a dubnu ovládli separatisté poté, co Moskva 18. března anektovala Krymský poloostrov patřící Ukrajině.
Kreml a separatisté nedávno obsazené území označili jako „Novorusko“ nebo „Nové Rusko“, termínem, který odkazuje na slavné předrevoluční dny ruského impéria.
Ruská tisková agentura Itar-Tass zveřejnila Putinova slova, podle kterých je „vězeň iluzí“ každý, kdo věří, že na obzoru jsou mírová jednání, protože ukrajinští politikové zahájili před parlamentními volbami 26. října kampaně, zatímco vládní jednotky napadají civilní obyvatelstvo v oblastech ovládaných separatisty.
„V zájmu lidí žijících v těchto oblastech musíme neprodleně zahájit smysluplná jednání a to ne pouze o právních záležitostech, ale také o politické organizaci společnosti a o statutu státní suverenity jihovýchodu Ukrajiny,“ prohlásil.
Peskov řekl, že Putinova narážka na státní suverenitu byla myšlena v kontextu širší autonomie, o které se s vedením Kyjeva jedná již několik měsíců a která má zmírnit obavy rusky hovořících oblastí z ohrožení kulturních a jazykových práv.
Peskov uvedl, že potřebnou autonomii může východním oblastem udělit pouze ukrajinská vláda.
Nejedná se o záležitost k projednání mezi Ukrajinou a Ruskem, řekl Peskov, „protože se nejedná o konflikt mezi Ruskem a Ukrajinou, ale o vnitřní ukrajinský konflikt.“
Zakročení mluvčího Kremlu, které mělo korigovat „nesprávnou interpretaci“ Putinových poznámek, zdůraznilo přístup vedení Ruska k řešení povstání separatistů na východě, který je odlišný od otevřeného obsazení Krymu, kde se většina z dvoumilionové populace původem řadí k etnickým Rusům.
Moskva by měla mnohem větší potíže anektovat i Doněck a Luhansk na východě Ukrajiny, neboť většina z 6,5 milionu obyvatel nejsou Rusové a průzkumy veřejného mínění, které proběhly ještě před konfliktem, ukázaly širokou podporu setrvání na Ukrajině.
Autonomie, o které ruští diplomaté jednali na mezinárodních fórech, by regionálním vládám na Ukrajině dala pravomoc určovat své vlastní obchodní dohody a mezinárodní vztahy, a v podstatě tak dát Kremlu faktickou kontrolu nad územím, které by spojilo ruskou pevninu s Krymem.
Černomořský poloostrov anektovaný před pěti měsíci je sídlem hlavní ruské námořní flotily, námořního obchodního zázemí i historických pobřežních resortů.
Oblasti mezi ruským Rostovem a Krymem jsou také střediskem dolů, továren a sléváren, které vyrábějí důležité komponenty pro ruskou armádu.
Ukrajinský prezident Petro Porošenko během svého inauguračního projevu ze 7. června navrhl, aby ukrajinští zákonodárci - po nových volbách - zvážili změny v ústavě, které by různorodým regionům daly více kontroly nad jejich financemi a jazykovým statutem.
Tato vize autonomie se ale značně liší od vize Kremlu a separatistů. Moskva je obviňována z vyzbrojování a podněcování násilí.
Putinova poslední výzva, aby Kyjev jednal se separatisty jako se sobě rovnými následovala po dalším postupu povstalců minulý týden poté, co na východní Ukrajinu pronikly ruské jednotky a tanky z dříve klidné oblasti podél Azovského moře.
Separatisté posíleni Rusy převzali kontrolu nad Novoazovskem takovou silou, že se ukrajinské bezpečnostní orgány obávají, že se jedná o tažení s cílem obsadit strategické pobřežní území až na Krym.
To uspíšilo obrovskou civilní i vojenskou snahu opevnit Mariupol, přístav s metalurgickými kombináty o 500 000 obyvatelích, který leží mezi Novoazovskem a úzkou vstupní branou na Krymský poloostrov.
Porošenko v sobotu vystoupil na meetingu čelních představitelů Evropské unie v Bruselu a vybízel k akci, která by zabránila další ruské agresi proti Ukrajině, bývalé sovětské republice, která je posledních 23 let nezávislá.
„Blížíme se k bodu, ze kterého není návratu,“ varoval Porošenko.
Na území Ukrajiny se nyní nachází tisíce cizích vojenských jednotek a stovky cizích tanků.
Summit EU nepodnikl žádné definitivní kroky - lídři vyzývají k přijetí dalších sankcí proti Rusku v případě blíže nespecifikované eskalace ukrajinské krize.
Plukovník Andrij Lysenko, mluvčí ukrajinské Národní bezpečnostní a obranné rady v sobotu reportérům v Kyjevě řekl, že ukrajinští vojáci se museli stáhnout ze svých pozic v Ilovajsku poté, co minulý týden dvě kolony ruských obrněných vozidel a 1 000 vojenských jednotek proniklo do Doněcké oblasti, aby podpořily obléhané separatisty.
První ze 63 nahlášených ukrajinských vojáků, kteří byli zajati v Ilovajsku při ruské invazi, byli v neděli vyměněni za 10 ruských výsadkářů zajatých před týdnem ve vnitrozemí Ukrajiny, uvedl v neděli Lysenko.
Ve skandálu s odhalenými fotkami jsou zapleteny i australské celebrity a Gabi Grecko
Geoffrey Edelsten vyjádřil své znechucení nad hackery, kteří pravděpodobně ukradli intimní fotky jeho snoubenky Gabi Grecko a dalších vlivných hollywoodských hvězd.
Tinseltown je v šoku poté, co se v největším skandálu s hacknutými fotografiemi celebrit dostala na internet série explicitních fotek nahé Jennifer Lawrencové.
Hacker tvrdí, že má šedesát fotek s nahou hvězdou Hunger Games Lawrencovou a dalších hvězd včetně Kate Uptonové a Cary Delevingne, zpěvaček Rihanny, Ariany Grande a Ley Michellové a herečky Kirsten Dunstové.
Kvůli úniku z iCloud se na veřejnost údajně dostaly i osobní snímky australských hereček Teresy Palmerové, Emily Browningové, Yvonne Strahovski a melbournské herečky Grecko.
Na seznamu je 101 celebrit.
Edelsten, který Grecko požádal o ruku minulý měsíc, magazínu Confidential řekl: „Je to nechutné.“
Všechna soukromá korespondence a všechny soukromé obrázky by soukromé měly zůstat.
Je ostuda, že se osobní informace dají ukrást a rozšířit na veřejnost.
Grecko, která je nyní v New Yorku, podle zpravodajů online novinám sdělila, že hacknutí je „nestydaté“ a ti, kteří se stali jeho terčem, si „připadají ponížení“.
Má se za to, že hacker získal třicet fotek Palmerové s bývalým přítelem Scottem Speedmanem včetně dvou snímků, na kterých se nahoře bez rozvaluje u bazénu.
Palmerová účinkovala například ve filmu Láska a čest, kde byl jejím protějškem Liam Hemsworth.
Palmerová, hvězda televizní série Chuck Strahovski a herečka z thrilleru Sucker Punch Browningová včera ukradené snímky nekomentovaly.
Zástupce Lawrencové TMZ řekl: „Jde o jasné porušení soukromí.“
Herec Seth Rogen hackera na svém twitteru kritizoval: „Zveřejňovat fotky z hacknutých telefonů je úplně stejné jako prodávat ukradené zboží.“
Z právního hlediska by se zveřejňování ukradených snímků nemělo tolerovat.
Fotbalisté Sigmy si Lébra udobřili, i bez výhry
Olomouc - Hromy a blesky, které spolumajitel olomoucké Sigmy Josef Lébr sesílal na své podřízené minulý týden, jsou, zdá se, minulostí.
Byť z Opavy přivezli nakonec jenom bod za bezbrankovou remízu.
Nasazením a bojovností si klubového bosse přece jen trochu udobřili.
Peníze na výplaty by do klubu brzy mohly přijít.
"Nechám si ještě jeden zápas, jak jsem o tom mluvil minulý týden, ale jsem už daleko optimističtější," potvrdil Lébr, že navzdory tomu, že Sigma nevyhrála, jej hráči zlepšeným výkonem přesvědčili.
Bojovnost a nasazení, se kterým jsme hráli hlavně ve druhém poločase, bylo přesně to, co chci od hráčů vidět.
V takovém případě jsem schopen odpustit, že se nevyhraje.
Kdybychom tak hráli od začátku sezony, tak jsem přesvědčen, že jsme ještě neprohráli," myslí si Lébr.
Sigma v Opavě přestála úvodní tlak domácích, pak hru vyrovnala a ve druhé půli už byla lepší.
Po vítězství Kalvodovi svěřenci sahali, ale své možnosti nedotáhli ke gólu, a tak vyhrát nemohli.
Výsledek sice není podle našich představ.
K úplné spokojenosti nám chyběla ale jen jedna proměněná šance," prohlásil Lébr, který si ale nemyslí, že změnu v přístupu fotbalistů způsobila jen jeho výhrůžka.
Bylo tam určitě více aspektů.
Ať už z mojí strany, ze strany trenéra, nebo fanoušků," řekl Lébr.
S tlakem musí Sigma počítat
Hráčům se po zápase v Opavě události z minulého týdne moc komentovat nechtělo.
Tyhle věci se snažím dát úplně pryč.
Snažil jsem si to nepřipouštět," kroutil hlavou mladý brankář Michal Reichl.
Úplně bez komentáře pak nechal otázku na Lébrova prohlášení z minulého týdne útočník Václav Vašíček, který neproměnil největší příležitost Sigmy v sobotním zápase.
Posléze se ale přece jen trošičku o tlaku rozpovídal.
Pod tlakem budeme pořád.
Všichni se na nás chtějí vytáhnout.
Dnes jsme ukázali, že když budeme bojovat a jezdit všichni po prdeli, tak to půjde," řekl.
Varování si vzali k srdci
Ani kouč Leoš Kalvoda nezastíral, že příprava na zápas nebyla nejjednodušší vzhledem k atmosféře, která v Olomouci v minulém týdnu panovala.
Bylo to dost těžké.
Ale myslím, že kluci si to uvědomili, a dnes bylo vidět, že si to varování pana Lébra vzali k srdci.
I když ani předtím to nebylo o tom, že by nechtěli bojovat a odflákli to," mínil olomoucký trenér.
Bylo to podobné jako dnes prvních patnáct minut.
Trvalo, než jsme se srovnali s tvrdostí a uvědomili si, o čem druhá liga je.
Že to není jen o fotbalovosti, ale hlavně o té bojovnosti," řekl Kalvoda.
Nezbývá než doufat, že v příštích zápasech už to Sigmě bude fungovat od začátku.
"Hrozně rád bych tomu věřil," dodal.
